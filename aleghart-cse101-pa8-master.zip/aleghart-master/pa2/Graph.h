/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA2
* Graph.h
* Graph ADT headerfile
*********************************************************************************/
#pragma once
#include <stdio.h>
#include <stdbool.h>

#include "List.h"

//exportable types
typedef struct GraphObj* Graph;
#define BLACK -666 //BFS discovered and all neighbors discovered
#define WHITE -333 //BFS undiscovered
#define GRAY -420 //BFS discovered but not all neighbors discovered
#define INF -69420
#define NIL -12345

/*** Constructors-Destructors ***/
Graph newGraph(int n);
// returns a Graph pointing to a newly created GraphObj representing a graph having n vertices and no edges.
void freeGraph(Graph* pG);
//frees all heap memory associated with the Graph *pG then sets the handle *pG to NULL


/*** Access functions ***/
int getOrder(Graph G);                  //returns the order (number of vertices) of graph G
int getSize(Graph G);                   //returns the size (number of edges) of graph G
int getSource(Graph G);
//returns the source vertex most recently used in function BFS(), or NIL if
 //BFS() has not yet been called
int getParent(Graph G, int u);
//returns the parent of vertex u in the BFS tree
  //created by BFS(), or NIL if BFS() has not yet been called
int getDist(Graph G, int u);            //returns the distance from
  //the most recent BFS source to vertex u, or INF if BFS() has not yet been called.
void getPath(List L, Graph G, int u);
// appends to the List L the vertices of a shortest path
  //in G from source to u, or appends to L the value NIL if no such path exists


/*** Manipulation procedures ***/
void makeNull(Graph G); //deletes all edges of G, restoring it to its original (no edge) state.
void addEdge(Graph G, int u, int v);
void addArc(Graph G, int u, int v);
void BFS(Graph G, int s);
/*** Other operations ***/
void printGraph(FILE* out, Graph G);
