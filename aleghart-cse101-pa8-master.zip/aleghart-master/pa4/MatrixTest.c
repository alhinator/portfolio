/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA4
* MatrixTest.c
* Matrix ADT test harness
*********************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "Matrix.h"
#include "List.h"


int main(int argc, char* argv[]) {


  Matrix M = newMatrix(4);
  changeEntry(M, 1, 4, 6.67);
  assert(NNZ(M) == 1);
  changeEntry(M, 1, 4, 6.68);
  assert(NNZ(M) == 1);
  changeEntry(M, 1, 4, 0);
  assert(NNZ(M) == 0);
  changeEntry(M, 3, 3, 1.2);
  changeEntry(M, 2, 4, 0);
  changeEntry(M, 4, 1, 1.8);
  assert(NNZ(M) == 2);

  //fprintf(stderr, "done asserting\n");

  Matrix A = newMatrix(4);
  Matrix B = newMatrix(4);

  changeEntry(A, 4, 4, 1.0);
  changeEntry(A, 1, 1, 1.0);
  changeEntry(A, 2, 2, 1.0);
  changeEntry(A, 3, 3, 1.0);

  changeEntry(B, 4, 4, 1.0);
  changeEntry(B, 1, 1, 1.0);
  changeEntry(B, 2, 2, 1.0);
  changeEntry(B, 3, 3, 1.0);

  assert(equals(A, B) == 1);
  // changeEntry(B, 2, 2, 1.1);
  // assert(equals(A, B) == 0);

  Matrix C = newMatrix(4);
  //assert(equals(C, D) == 1); //empty copy works
  changeEntry(C, 4, 4, 1.0);
  changeEntry(C, 2, 4, 1.0);
  changeEntry(C, 1, 1, 1.0);
  changeEntry(C, 1, 1, 0);
  fprintf(stderr, "done with C\n");
  Matrix D = copy(C);
  assert(equals(C, D) == 1); //filled copy?

  //printMatrix(stdout, M);
  //fprintf(stdout, "-------\n");
  M = transpose(M);
  //printMatrix(stdout, M);
  //print and transpose tests
  fprintf(stdout, "-------\n");


  // printMatrix(stdout, M);
  // fprintf(stdout, "-------\n");
  // printMatrix(stdout, A);
  // fprintf(stdout, "-------\n");
  // printMatrix(stdout, B);
  // fprintf(stdout, "-------\n");
  // printMatrix(stdout, C);
  // fprintf(stdout, "-------\n");
  // printMatrix(stdout, D);
  // fprintf(stdout, "-------\n");

  Matrix X = newMatrix(4);
  Matrix Y = newMatrix(4);

  // changeEntry(X, 4, 4, 1.0);
  // changeEntry(X, 1, 1, 1.0);
  // changeEntry(X, 2, 2, 1.0);
  // changeEntry(X, 3, 3, 1.0);
  // changeEntry(X, 1, 2, 1.0);
  // changeEntry(X, 1, 3, 1.0);
  // changeEntry(X, 1, 4, 1.0);
  // changeEntry(X, 2, 3, 1.0);
  //
  //
  //
  // changeEntry(Y, 4, 4, 1.0);
  // changeEntry(Y, 1, 1, 1.0);
  // changeEntry(Y, 2, 2, 1.0);
  // changeEntry(Y, 3, 3, 1.0);
  printMatrix(stdout, X);
  printMatrix(stdout, Y);

  changeEntry(X, 1, 1, 4);
  changeEntry(X, 1, 2, 2);
  changeEntry(X, 1, 3, 0);
  changeEntry(X, 2, 1, 2);
  changeEntry(X, 3, 1, 0);
  changeEntry(X, 2, 2, 2);
  changeEntry(X, 3, 3, 0);
  printMatrix(stdout, X);


  Matrix SUM = sum(X, X);
  fprintf(stderr, "X + X:\n");
  printMatrix(stdout, SUM);
  assert(NNZ(SUM) == 4);
  SUM = diff(X, X);
  fprintf(stderr, "X - X:\n");
  printMatrix(stdout, SUM);
  assert(NNZ(SUM) == 0);
  assert(NNZ(X) == 4);
  assert(NNZ(Y) == 0);


  Matrix SC = scalarMult(30, SUM);
  assert(NNZ(SC) == 0);


  exit(EXIT_FAILURE);

  SUM = sum(SUM, B);
  //fprintf(stderr, "M + A + B:\n");
  //printMatrix(stdout, SUM);

  SUM = sum(SUM, C);
  SUM = sum(SUM, D);

  //fprintf(stderr, "M + A + B + C + D:\n");

  //printMatrix(stdout, SUM);

  Matrix M1 = newMatrix(4);
  Matrix M2 = newMatrix(4);

  changeEntry(M1, 1, 1, 1);
  changeEntry(M2, 1, 1, 1);

  Matrix P = product(M1,M2);
  printMatrix(stdout, P);


  freeMatrix(&M);
  freeMatrix(&A);
  freeMatrix(&B);
  freeMatrix(&C);
  freeMatrix(&D);
  freeMatrix(&SUM);
  freeMatrix(&P);

  // List L = newList();
  // freeList(&L);

  return 0;
}
