# PURPOSE
*./keygen* generates a public / private key pair, placing the keys into the
public and private key files as specified below. The keys have a modulus (n)
whose length is specified in the program options.

*./decrypt* decrypts an input file using the specified private key file,
writing the result to the specified output file."

*./encrypt* encrypts an input file using the specified public key file,
writing the result to the specified output file.

In combination, these three programs constitute an RSA encryption system:
RSA keypair Generation, Encryption, and Decryption. These are powered by
various number theory functions, including Miller-Rabin primality testing for
generation of large primes,

# DEPENDENCIES

libgmp, the GNU Multiple Precision Library, which can be installed via
`$ sudo apt install pkg -config libgmp -dev`

build-essential, which can be installed via `$ apt install build-essential`

clang, which can be installed via `$ apt install clang`

# OPTIONAL MODULES
clang-format is required for some arguments of Makefile, but is not used by default. It can be installed via `$apt install clang-format`

# I/O & USAGE
All Files must be in the same directory as the provided files and Makefile as it compiles the c program during runtime.

Usage: ./keygen [options]
 ./keygen generates a public / private key pair, placing the keys into the public and private
 key files as specified below. The keys have a modulus (n) whose length is specified in
 the program options.
    -s <seed>    : Use <seed> as the random number seed. Default: time()
    -b <bits>    : Public modulus n must have at least <bits> bits. Default: 1024
    -i <iters>   : Run <iters> Miller-Rabin iterations for primality testing. Default: 50
    -n <pbfile>  : Public key file is <pbfile>. Default: rsa.pub
    -d <pvfile>  : Private key file is <pvfile>. Default: rsa.priv
    -v           : Enable verbose output.
    -h           : Display program synopsis and usage.

Usage: ./encrypt [options]
  ./encrypt encrypts an input file using the specified public key file,
  writing the result to the specified output file.
    -i <infile> : Read input from <infile>. Default: standard input.
    -o <outfile>: Write output to <outfile>. Default: standard output.
    -n <keyfile>: Public key is in <keyfile>. Default: rsa.pub
    -v          : Enable verbose output.
    -h          : Display program synopsis and usage.

Usage: ./decrypt [options]
  ./decrypt decrypts an input file using the specified private key file,
  writing the result to the specified output file.
    -i <infile> : Read input from <infile>. Default: standard input.
    -o <outfile>: Write output to <outfile>. Default: standard output.
    -n <keyfile>: Private key is in <keyfile>. Default: rsa.priv
    -v          : Enable verbose output.
    -h          : Display program synopsis and usage.


# Makefile
*Makefile* can be run by itself to compile all the included *.c* and *.h* files in the directory.

*Makefile* can be run via `$ make` assuming build-essential is installed. It accepts the following arguments:

`all`
---
All, which is also the default none argument, will compile all necessary
 *.c* and *.h* files: *decrypt.c*, *encrypt.c*, *keygen.c*, *numtheory.c*,
  *randstate.c*, *rsa.c*, *decrypt.h*, *encrypt.h*, *keygen.h*, *numtheory.h*, *randstate.h*, and *rsa.h*.

`<filename>`
---
`make <filename>` will compile only the specified file.

`clean`
---
Removes all compiled executables and PDFs from the directory Makefile is in.

`format`
---
Formats all .c and .h files in the working directory in accordance with a .clang-format file. File not included, however, my code was formatted using a *clang-format* file provided by tutor Ben G.
