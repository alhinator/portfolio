/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA4
* List.c
* List ADT implementation -- vptr version
*********************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "List.h"

// structs -------------

// private node type
typedef struct NodeObj* Node;

//private NodeObj type
typedef struct NodeObj{
  void* data; //the data contained within a node.
  int index; //index position associated with this node.
  Node prev; //the previous node! if null, this is the start.
  Node next; //the next node! if null, this is the end.
} NodeObj;

//private ListObj type
typedef struct ListObj{
  int length; //length of list
  Node cursor; //cursor
  int cursorPos;
  Node front; // node at the front of the List
  Node back; //node at the back of the list
} ListObj;





// ------------ Constructors, Destructors ----------
List newList(){
  List retList = malloc(sizeof(ListObj));
  assert(retList != NULL);
  retList->length = 0;
  retList->cursor = NULL;
  retList->cursorPos = -1;
  retList->front = NULL;
  retList->back = NULL;
  return retList;
}
void freeList(List* pL){
  if (pL != NULL && *pL != NULL) {
    clear(*pL); //empty the list
    (*pL)->front = NULL;
    (*pL)->back = NULL;
    free(*pL); //then free the list.
    *pL = NULL;
  }
}
//
Node newNode(){
  Node retNode = malloc(sizeof(NodeObj));
  assert(retNode != NULL);
  retNode->data = NULL;
  retNode->index = -1;
  retNode->prev = NULL;
  retNode->next = NULL;
  return retNode;
}
void freeNode(Node* pN){
  if( pN != NULL && *pN != NULL ){
      free((*pN)->data);
      free(*pN);
      *pN = NULL;
   }
}

// -----------------   access operations. ----------
bool isEmpty(List L){ // returns true if length of L is 0.
  if (L == NULL) {
    fprintf(stderr, "List ADT | isEmpty() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return L->length == 0;
}
int length(List L){ // Returns the number of elements in L.
  if (L == NULL) {
    fprintf(stderr, "List ADT | length() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return L->length;
}
int index(List L){ // Returns index of cursor element if defined, -1 otherwise.
  if (L == NULL) {
    fprintf(stderr, "List ADT | index() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  ////////////////////////////
  return L->cursor ? L->cursorPos : -1;
}
void* front(List L){ // Returns front element of L. Pre: length()>0
  if (L == NULL) {
    fprintf(stderr, "List ADT | front() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | front() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  ///////////////////////////
  return L->front->data;
}
void* back(List L){ // Returns back element of L. Pre: length()>0
  if (L == NULL) {
    fprintf(stderr, "List ADT | back() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | back() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  //////////////////////////
  return L->back->data;
}
void* get(List L){ // Returns cursor element of L. Pre: length()>0, index()>=0
  if (L == NULL) {
    fprintf(stderr, "List ADT | get() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | get() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  if (L->cursor == NULL || L->cursorPos == -1) {
    fprintf(stderr, "List ADT | get() reports that this list has no valid cursor. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  ///////////////////////////
  return L->cursor->data;
}

// ---------------- helper functions ----------------
void fixIndexes(List L){ //look, this is really time-inefficient, but it works. I think.
//update every "index" of all list items.
//works on empty or full list.
if (L == NULL) {
  fprintf(stderr, "List ADT | fixIndexes() was called on a NULL pointer.\n");
  exit(EXIT_FAILURE);
}
if (isEmpty(L)) {
  //fprintf(stderr, "List ADT | fixIndexes() reports that this list is empty. Exiting...\n");
  //exit(EXIT_FAILURE);
  return; //don't need to crash the program.
}
///////////////////////////////
 int index = 0;
 Node curr = L->front;
 while (curr != NULL) {
   curr->index = index;
   //printf("curr: %i  @ index:%i\n", curr->data, curr->index);
   //FIGURED IT OUT! THIS FUNCTION ALSO NEEDS TO UPDATE THE CURSOR POSITION!
   if (L->cursor == curr ) {
     L->cursorPos = index;
   }
   curr = curr->next;
   index++;
 }
}

// ---------------- manipulation operations ------------
void clear(List L){ // Resets L to its original empty state.
  if (L == NULL) {
    fprintf(stderr, "List ADT | clear() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  //////////////////////////
  //loop through each element in the list, delete it.
  while (!isEmpty(L)) {
    deleteFront(L);
  }
  // null the cursor and pos
  L->cursor = NULL;
  L->cursorPos = -1;
}
void set(List L, void* x){ // Overwrites the cursor element’s data with x. Pre: length()>0, index()>=0
  if (L == NULL) {
    fprintf(stderr, "List ADT | set() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | set() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  if (L->cursor == NULL || L->cursorPos == -1) {
    fprintf(stderr, "List ADT | set() reports that this list has no valid cursor. Exiting...\n");
    exit(EXIT_FAILURE);
  }
///////////////////////////////
  free((L->cursor->data));
  //fprintf(stderr, "in set\n");
  L->cursor->data = x;
  //fprintf(stderr, "out of set\n");


}
void moveFront(List L){ // If L is non-empty, sets cursor under the front element, // otherwise does nothing.
  if (L == NULL) {
    fprintf(stderr, "List ADT | moveFront() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    //fprintf(stderr, "List ADT | get() reports that this list is empty. Exiting...\n");
    //exit(EXIT_FAILURE);
    //just do nothing
    return;
  }
  ////////////////////////////
  L->cursor = L->front;
  L->cursorPos = L->front->index; //should always be zero.
  assert(L->cursorPos == 0 && L->cursor->index == 0);

}
void moveBack(List L){ // If L is non-empty, sets cursor under the back element, otherwise does nothing.
  if (L == NULL) {
    fprintf(stderr, "List ADT | moveBack() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    //fprintf(stderr, "List ADT | get() reports that this list is empty. Exiting...\n");
    //exit(EXIT_FAILURE);
    //just do nothing
    return;
  }
  ////////////////////////////
  L->cursor = L->back;
  L->cursorPos = L->back->index; //should always be L->length -1 (starts at 0 position).
  assert(L->cursorPos == L->length -1);
}
void movePrev(List L){ // If cursor is defined and not at front, move cursor one
 // step toward the front of L; if cursor is defined and at
 // front, cursor becomes undefined; if cursor is undefined
 // do nothing
 if (L == NULL) {
   fprintf(stderr, "List ADT | movePrev() was called on a NULL pointer.\n");
   exit(EXIT_FAILURE);
 }
 if (isEmpty(L) || !L->cursor || L->cursorPos == -1) { // empty or undefined
   //fprintf(stderr, "List ADT | get() reports that this list is empty. Exiting...\n");
   //exit(EXIT_FAILURE);
   //just do nothing
   return;
 }
 if (L->cursor->prev == NULL) { //defined and at front
   L->cursor = NULL;
   L->cursorPos = -1;
 } else {
   int old = L->cursor->index;
   L->cursor = L->cursor->prev;
   L->cursorPos = L->cursor->index; //should always subtract 1.
   assert(L->cursorPos == old - 1);
 }


}
void moveNext(List L){ // If cursor is defined and not at back, move cursor one
 // step toward the  back of L; if cursor is defined and at
 // front, cursor becomes undefined; if cursor is undefined
 // do nothing
 if (L == NULL) {
   fprintf(stderr, "List ADT | moveNext() was called on a NULL pointer.\n");
   exit(EXIT_FAILURE);
 }
 if (isEmpty(L) || !L->cursor || L->cursorPos == -1) { // empty or undefined
   //fprintf(stderr, "List ADT | get() reports that this list is empty. Exiting...\n");
   //exit(EXIT_FAILURE);
   //just do nothing
   return;
 }
 if (L->cursor->next == NULL) { //defined and at front
   L->cursor = NULL;
   L->cursorPos = -1;
 } else {
   int old = L->cursor->index;
   L->cursor = L->cursor->next;
   L->cursorPos = L->cursor->index; //should always add 1.
   assert(L->cursorPos == old + 1);
 }


}
void prepend(List L, void* x){ // Insert new element into L. If L is non-empty,
 // insertion takes place before front element.
 if (L == NULL) {
   fprintf(stderr, "List ADT | prepend() was called on a NULL pointer.\n");
   exit(EXIT_FAILURE);
 }
 /////////////////////////////
   Node new = newNode(); //call the newNode helper func
   new->prev = NULL; //appending will always put the new node at the beginning.
   new->data = x; //slap in the data.
   if (L->length == 0) {
     new->next = NULL; //nothing after.
     L->front = new; // since length is 0, it will now be the front AND the back of the list.
     L->back = new;
   }
   else { //occurs when list already has an element inside it.
     L->front->prev = new; //set the current head to point at new
     new->next = L->front; //set the new head to point to old head as next
     L->front = new; // set new as the new head of L
   }
   new->index = 0; //set the new node's index.
   L->length++; //increment length

   //now we need to update every "index" of all list items.
   fixIndexes(L);
   return;
}
void append(List L, void* x){ // Insert new element into L. If L is non-empty, insertion takes place after back element.
  if (L == NULL) {
    fprintf(stderr, "List ADT | append() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
/////////////////////////////
  Node new = newNode(); //call the newNode helper func
  new->next = NULL; //appending will always put the new node at the end.
  new->data = x; //slap in the data.
  if (L->length == 0) {
    new->prev = NULL; //nothing before.
    L->front = new; // since length is 0, it will now be the front AND the back of the list.
    L->back = new;
  }
  else { //occurs when list already has an element inside it.
    L->back->next = new; //set the current tail to point at new
    new->prev = L->back; //set the new tail to point to old tail as prev
    L->back = new; // set new as the new tail of L
  }
  new->index = L->length; //set the new node's index.
  L->length++; //increment length
  return;
}
void insertBefore(List L, void* x){ // Insert new element before cursor.
  // Pre: length()>0, index()>=0
  if (L == NULL) {
    fprintf(stderr, "List ADT | insertBefore() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | insertBefore() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  if (L->cursor == NULL || L->cursorPos < 0) {
    fprintf(stderr, "List ADT | insertBefore() reports that this list has no valid cursor. Exiting...\n");
    exit(EXIT_FAILURE);
  }
 /////////////////////////////
 //if we are able to, call prepend to make our lives easier.
if (L->cursorPos == 0) {
    //printf(" prepending..\n" );
    prepend(L, x);
} else {
    Node new = newNode(); //call the newNode helper func
    //give the newNode its values
    new->data = x; //slap in the data.
    new->index = -2; //this will be asserted later to make sure it's updated properly.
    //now shove it into the LL
    Node left = L->cursor->prev;
    left->next = new;
    new->prev = left;
    new->next = L->cursor;
    L->cursor->prev = new;
    L->length++;
    //now fix indexes.
    fixIndexes(L);
    assert(new->index != -2);
  }
  return;
}
void insertAfter(List L, void* x){ // Insert new element before cursor.
  // Pre: length()>0, index()>=0
  if (L == NULL) {
    fprintf(stderr, "List ADT | insertAfter() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | insertAfter() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  if (L->cursor == NULL || L->cursorPos < 0) {
    fprintf(stderr, "List ADT | insertAfter() reports that this list has no valid cursor. Exiting...\n");
    exit(EXIT_FAILURE);
  }
 /////////////////////////////
 //if we are able to, call append to make our lives easier.
if (L->cursorPos == L->length -1 ) {
    append(L, x);
} else {
    //printf("in insertAfter, top of else\n" );
    //printf("cursorpos: %i    length: %i\n", L->cursorPos, L->length);
    Node new = newNode(); //call the newNode helper func

    //give the newNode its values
    new->data = x; //slap in the data.
    new->index = -2; //this will be asserted later to make sure it's updated properly.
    //now shove it into the LL
    //printf("L->cursor->data: %i\n", L->cursor->data);
    Node right = L->cursor->next;
    assert(right != NULL);
    right->prev = new;
    //printf("in insertAfter\n" );

    new->next = right;
    new->prev = L->cursor;
    L->cursor->next = new;
    L->length++;

    //now fix indexes.
    fixIndexes(L);

    assert(new->index != -2);
  }
  return;
}
void deleteFront(List L){ // Delete the front element. Pre: length()>0
  if (L == NULL) {
    fprintf(stderr, "List ADT | deleteFront() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | deleteFront() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  //////////////////////////////
  Node N = L->front;
  if (length(L) > 1) {
    L->front = L->front->next;
    L->front->prev = NULL; //make sure new front isnt pointing to bad data
  } else {
    L->front = L->back = NULL; //thanks for this line prof i appreciate it
  }
  if (L->cursor == N) {
    L->cursor = NULL;
  }
  L->length--;
  freeNode(&N);

  //now we need to make sure the indexes are corrected.
  fixIndexes(L);
}
void deleteBack(List L){ // Delete the back element. Pre: length()>0
  if (L == NULL) {
    fprintf(stderr, "List ADT | deleteBack() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (isEmpty(L)) {
    fprintf(stderr, "List ADT | deleteBack() reports that this list is empty. Exiting...\n");
    exit(EXIT_FAILURE);
  }
  //////////////////////////////
  Node N = L->back;
  if (length(L) > 1) {
    L->back = L->back->prev;
    L->back->next = NULL; //same process as deleteFront but just in reverse
  } else {
    L->front = L->back = NULL;
  }
  if (L->cursor == N) {
    L->cursor = NULL;
  }
  L->length--;
  freeNode(&N);
}
void delete(List L){ // Delete cursor element, making cursor undefined.
 // Pre: length()>0, index()>=0
 if (L == NULL) {
   fprintf(stderr, "List ADT | delete() was called on a NULL pointer.\n");
   exit(EXIT_FAILURE);
 }
 if (isEmpty(L)) {
   fprintf(stderr, "List ADT | delete() reports that this list is empty. Exiting...\n");
   exit(EXIT_FAILURE);
 }
 if (L->cursor == NULL || L->cursorPos < 0) {
   fprintf(stderr, "List ADT | delete() reports that this list has no valid cursor. Exiting...\n");
   exit(EXIT_FAILURE);
 }
//////////////////////////////////////
  //call deleteFront or deleteBack to make our lives easier if possible.
  if (L->cursorPos == 0) {
    deleteFront(L);
    //nullify cursor.
    L->cursor = NULL;
    L->cursorPos = -1;
    return;
  } else if (L->cursorPos == L->length - 1){
    deleteBack(L);
    //nullify cursor.
    L->cursor = NULL;
    L->cursorPos = -1;
    return;
  } else {
    //default case
    Node N = L->cursor;
    Node left = N->prev;
    Node right = N->next;
    left->next = right;
    right->prev = left;
    freeNode(&N);
    //nullify cursor.
    L->cursor = NULL;
    L->cursorPos = -1;
    //reduce length
    L->length--;
    //fix indexes
    fixIndexes(L);
  }


}

// ---------------- other operations ---------------------
void printList(FILE* out, List L){ // Prints to the file pointed to by out, a
 // string representation of L consisting
 // of a space separated sequence of integers,
// with front on left.
if (L == NULL) {
  fprintf(stderr, "List ADT | printList() was called on a NULL list pointer.\n");
  exit(EXIT_FAILURE);
}
if (out == NULL) {
  fprintf(stderr, "List ADT | printList() was called on a NULL file pointer.\n");
  exit(EXIT_FAILURE);
}
if (isEmpty(L)) {
  return; //empty list, we don't need to print anything lol.
}
//////////////////////////////////////////////
Node curr = L->front;
while (curr != NULL) {
  fprintf(out, "%p ", curr->data);
  curr = curr->next;
}
fprintf(out, "\n");
}
