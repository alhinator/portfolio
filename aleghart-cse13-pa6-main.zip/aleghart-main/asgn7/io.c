#include "code.h"

#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <inttypes.h>

extern uint64_t bytes_read;
extern uint64_t bytes_written;

uint8_t w_buf[BLOCK] = {0};
uint16_t w_off = 0;

uint8_t r_buf[BLOCK] = {0};
uint16_t r_off = 32768; //init this at max so that it triggers the read when we first call read bit.

//uint8_t io_buffer;

int read_bytes(int infile, uint8_t *buf, int nbytes){
  //printf("in read_bytes\n");
  int brd = 0; // local bytes read
  uint8_t lb = '\0'; //single byte buffer
  while (brd < nbytes && read(infile, &lb, 1)) {
      //printf("read returned nonzero, lb is: %c | %"PRIu8"\n", lb, lb);
      buf[brd] = lb;
      brd++;
      //bytes_read++;
  }
  return brd;
}

int write_bytes(int outfile, uint8_t *buf, int nbytes){
  int bwr = 0; // local bytes written;
  //printf(":%s\n", buf);
  while (bwr < nbytes && write(outfile, &buf[bwr], 1)) {
    //printf("%c", buf[bwr]);
    bwr++;
    //bytes_written++;
  }
  return bwr;
}

bool read_bit(int infile, uint8_t *bit){
  if (r_off/8 >= BLOCK) { //if the current read_offset has reached the end of the block,
    if (read_bytes(infile, r_buf, BLOCK) <= 0) {
      fprintf(stderr, "read failed.\n");
      return false; // we tried to get a new block but theres nothing left to read.
    }
    r_off = 0;
  } //now we have a filled up block to read from
  *bit = (((r_buf[(r_off / 8)]) >> (r_off%8)) & 0x00000001) > 0;
  r_off++;
  //fprintf(stderr, "the current bit is: %"PRIu8", offset is: %"PRIu16"\n", *bit, r_off);
  //checks if the current byte of the buffer, right shifted the correct place, and anded with 1, is 1;
  return true;
}


void write_code(int outfile, Code *c){
  uint8_t bit = 0;
  uint32_t curr = 0;
  while (curr < c->top) { //while there are still bits to read

    if (w_off/8 >= BLOCK) { // we have reached BLOCK, accounted that we're counting bits.
      write_bytes(outfile, w_buf, BLOCK);
      w_off = 0;
      //need to clear buffer
      for (size_t i = 0; i < BLOCK; i++) {
        w_buf[i] = 0;
      }
    }

    //write into the buffer
    bit = (code_get_bit(c, curr) == 1);
    //printf("bit is: %"PRIu8"\n", bit);
    w_buf[w_off/8] |= bit << (w_off % 8);
    //printf("the buffer is: %"PRIu8"\n", w_buf);
    w_off ++;
    curr++;


  }
}

void flush_codes(int outfile){
  //fprintf(stderr, "remainder : \n");
  while (w_off %8) { // fill up the rest of the unused bits in the byte.
    w_buf[w_off/8] |= 0 << (w_off % 8); // with zeros.
    w_off ++;
  }

  write_bytes(outfile, w_buf, w_off/8); //print
}
