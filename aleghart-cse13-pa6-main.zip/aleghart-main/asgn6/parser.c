#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_PARSER_LINE_LENGTH 1000

struct Parser {
  FILE *f;
  char current_line[MAX_PARSER_LINE_LENGTH + 1];
  uint32_t line_offset;
};

struct Parser *parser_create(FILE *f){
  struct Parser *new_parser = (struct Parser*) malloc(sizeof(struct Parser));
  new_parser->f = f;
  for (int i = 0; i < MAX_PARSER_LINE_LENGTH; i++) {
    new_parser->current_line[i] = '\0';
  }
  new_parser->line_offset = 0;
  return new_parser;
}

void parser_delete(struct Parser **p){
  free(*p);
  p = NULL;
  return;
}

bool is_acceptable(char letter){ // "It.. is_acceptable." - Gustavo "Sus" Fring
  return (isalnum(letter) != 0 || letter == '\'' || letter == '-');
}


bool next_word(struct Parser *p, char *word){

    //we are always looking at a character at one of three points:
    //the beginning of a valid word
    //the separator-character directly before/after a word.
    //the \n  at the end of a line.

    //according to the pdf, words will never span lines.
    //we don't need to worry about hitting \n or 1000 and saving the prev word

    //starting at the end of parser length? get next line.
    if (p->line_offset > MAX_PARSER_LINE_LENGTH || p->current_line[p->line_offset] == '\n') {
      if (fgets(p->current_line, MAX_PARSER_LINE_LENGTH, p->f)== NULL){
        return false; //fgets ran out of file to parse
      } else{
        p->line_offset = 0; //otherwise, reset line offset & continue.
      }
    }
    //starting at an invalid character? let's loop till we find a good one.
    while (!is_acceptable(p->current_line[p->line_offset])) {

      //found the end of a line or hit parser length? get the next one.
      if (p->line_offset > MAX_PARSER_LINE_LENGTH || p->current_line[p->line_offset] == '\n') {
        if (fgets(p->current_line, MAX_PARSER_LINE_LENGTH, p->f)== NULL){
          return false; //fgets ran out of file to parse
        }
        p->line_offset = 0; //otherwise, reset line offset & continue.
      } else{
        p->line_offset += 1; //it wasn't a good character but it wasn't an EOL.
      }
    }

    //at this point, the current_line[line_offset] SHOULD be pointing
    //at our first acceptable character.
    int w_offset = 0;
    //now we keep looping until the end of the line or we reach an invalid char.
    while (p->line_offset < MAX_PARSER_LINE_LENGTH && is_acceptable(p->current_line[p->line_offset])) {
      word[w_offset] = tolower(p->current_line[p->line_offset]);
      w_offset ++;
      p->line_offset += 1;
    }
    //now, we have broken out of the loop by either hitting MAX_PARSER_LINE_LENGTH
    //or reaching an invalid character AFTER finding a good one.
    word[w_offset] = '\0'; //null-terminate our word.
    return true;

}
