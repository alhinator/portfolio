#include "bv.h"
#include "city.h"

#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define N_HASHES 5

struct BloomFilter {
  uint64_t salts[N_HASHES];
  uint32_t n_keys;
  uint32_t n_hits;
  uint32_t n_misses;
  uint32_t n_bits_examined;
  BitVector *filter;
};

static uint64_t default_salts[] = {0x5adf08ae86d36f21, 0x419d292ea2ffd49e,
                                   0x50d8bb08de3818df, 0x272347aea4045dd5,
                                   0x7c8e16f768811a21};

struct BloomFilter *bf_create(uint32_t size) {

  struct BloomFilter *bf = (struct BloomFilter *)malloc(sizeof(struct BloomFilter));
  if (bf != NULL) {
    bf->n_keys = bf->n_hits = 0;
    bf->n_misses = bf->n_bits_examined = 0;
    for (int i = 0; i < N_HASHES; i++) {
      bf->salts[i] = default_salts[i];
    }
    bf->filter = bv_create(size);
    if (bf->filter == NULL) {
      free(bf);
      bf = NULL;
    }
  }
  return bf;
}

void bf_print(struct BloomFilter *bf) {
  for (size_t i = 0; i < N_HASHES; i++) {
    fprintf(stderr, "%" PRIu64 "\n", bf->salts[i]);
  }
  fprintf(stderr,
          "%" PRIu32 " , \n%" PRIu32 " , \n%" PRIu32 " , \n%" PRIu32 " , \n",
          bf->n_keys, bf->n_hits, bf->n_misses, bf->n_bits_examined);
  bv_print(bf->filter);
}

void bf_delete(struct BloomFilter **bf) {
  bv_delete(&((*bf)->filter));
  free(*bf);
  bf = NULL;
  return;
}

uint32_t bf_size(struct BloomFilter *bf) { return bv_length(bf->filter); }

uint64_t *five_hash_helper(uint32_t len, uint64_t salts[], const char *s) {
  uint64_t *retArr = (uint64_t *)calloc(N_HASHES, sizeof(uint64_t));
  if (retArr == NULL) {
    fprintf(stderr, "calloc five_hash_helper failed.\n");
    return NULL;
  }
  for (size_t i = 0; i < N_HASHES; i++) {
    retArr[i] = hash(salts[i], s) % len;
  }
  return retArr;
}

void bf_insert(struct BloomFilter *bf, char *oldspeak) {
  //printf("hell! inside bf_insert\n" );
  for (size_t i = 0; i < N_HASHES; i++) {
    uint64_t salty = hash(bf->salts[i], oldspeak) % bf_size(bf);
    bv_set_bit(bf->filter, salty);
    //printf("(set) one of the hashes for %s is %"PRIu64". ", oldspeak, salty);
    //printf(" its %"PRIu8"\n", bv_get_bit(bf->filter, salty));

    //bv_print(bf->filter);
  }
  bf->n_keys += 1;

  return;
}

bool bf_probe(struct BloomFilter *bf, char *oldspeak){


  for (size_t i = 0; i < N_HASHES; i++) {
    bf->n_bits_examined += 1;
    //printf("(probe) one of the hashes for %s is %"PRIu64".\n", oldspeak, salty);
    uint64_t salty = hash(bf->salts[i], oldspeak) % bf_size(bf);
    if(bv_get_bit(bf->filter, salty) == 0){
      //printf("not in bloom filter.\n");
      bf->n_misses += 1;
      return false;
    }
  }
  bf->n_hits += 1;
  //printf("end of bf prope\n");
  return true;
}

uint32_t bf_count(struct BloomFilter *bf){
  uint32_t retVal = 0;
  for (size_t i = 0; i < bv_length(bf->filter); i++) {
    if (bv_get_bit(bf->filter, i) == 1) {
      retVal++;
    }
  }
  return retVal;
}

void bf_stats(struct BloomFilter *bf, uint32_t *nk, uint32_t *nh, uint32_t *nm, uint32_t *ne){
  *nk = bf->n_keys;
  *nh = bf->n_hits;
  *nm = bf->n_misses;
  *ne = bf->n_bits_examined;
  return;
}
