`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA8
* README.md
* Readme file

*********************************************************************************`

### Included Files:

*Dictionary.cpp* contains an implementation of a RED-BLACK Binary Tree that contains indexes of key:value pairs, using a doubly-linked list as the model.

*Dictionary.h* provides an interface for external files to interact with *Dictionary.cpp*

*DictionaryTest.cpp* contains tests for the functions contained within *Dictionary.cpp*

*Order.cpp* uses the Dictionary implementation to read in a file of words separated by line, and place them into a RBT, then print the sorted words in two different formats.

*WordFrequency.cpp* uses the Dictionary implementation to read in any text file, tokenized alphabetically by line, and place them into a RBT, then print the sorted words in one  formats.

*Makefile* provides various options for compiling the *.cpp* and *.h* files.
