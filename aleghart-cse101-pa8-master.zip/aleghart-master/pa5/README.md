`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA5
* README.md
* Readme file
*********************************************************************************`

### Included Files:

*List.cpp* contains an implementation of a doubly-linked integer list and various access, manipulation, and miscellaneous operations. This version is C++, as compared to previous assignments.

*List.h* provides an interface for external files to interact with *List.cpp*

*ListTest.cpp* contains tests for the functions contained within *List.cpp*

*Shuffle.cpp* uses the List implementation to read in an integer n, create lists of size 1 to n-1, and for each list, perform riffle shuffles on it until it is returned to its original state.

*Makefile* provides various options for compiling the *.cpp* and *.h* files.
