#include "stdio.h"
#include "stats.h"
#include "stdint.h"

int next_gap(int gappy){
  if(gappy == 1){
    return 0;
  }
  else if (gappy <= 2){
    return 1;
  }
  else{
    return (5 * gappy / 11);
  }
}


void shell_sort(Stats *stats, uint32_t *arr, uint32_t n_elements){
  int start = next_gap(n_elements);
  for (int gap = start; gap > 0; gap = next_gap(gap)) {
    for (uint32_t i = gap; i < n_elements; i++){
      int j = i;
      uint32_t temp = move(stats, arr[i]);
      while (j >= gap && cmp(stats, temp, arr[j-gap])==-1){
        arr[j] = move(stats, arr[j-gap]);
        arr[j] = move(stats, arr[j-gap]);
        j -= gap;
      }
      arr[j] = move(stats, temp);

    }
  }
  return;
}
