/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* BigIntegerTest.cpp
* BigInteger ADT test harness
*********************************************************************************/
#include "BigInteger.h"
#include "List.h"

#include <assert.h>

//using namespace std;

int main(int argc, char **argv) {

  //grah...
  // long L1 = 12345678910111213;
  // string L2 = "123429545130948790123847301";
  // string L3 = "-223429545130948790123847301";
  // BigInteger B = BigInteger(L1);
  // BigInteger C = BigInteger();
  // BigInteger D = BigInteger(L2);
  // BigInteger E = BigInteger(L3);
  //
  // std::cout << B.to_string() << '\n';
  // std::cout << C.to_string() << '\n';
  // std::cout << D.to_string() << '\n';
  // std::cout << E.to_string() << '\n';

  // std::cout << B.compare(C) << '\n'; // should be 1
  // std::cout << C.compare(D) << '\n'; // should be 1
  // std::cout << C.compare(C) << '\n'; //should be 0
  // std::cout << D.compare(B) << '\n'; //should be -1
  // std::cout << B.compare(D) << '\n'; //should be 1
  // std::cout << B.compare(B) << '\n'; //should be 0
  // std::cout << D.compare(E) << '\n'; //should be 1

  // assert(B > C);
  // assert(C > D);
  // assert(C >= C);
  // assert(D <= B);
  // assert(B > D);
  // assert(B == B);
  // assert(D > E);
  //
  // List L;
  // L.insertBefore(1);
  // L.insertBefore(2);
  // L.insertBefore(-3);
  // L.insertBefore(4);
  // L.insertBefore(-5);
  // std::cout << L << '\n';
  // negateList(L);
  // std::cout << L << '\n';
  //
  // L.clear();
  //
  // L.insertBefore(111);
  //
  // // L.insertBefore(1123334445);
  // // std::cout << L << '\n';
  // // normalizeList(L);
  // // std::cout << L << '\n';
  //
  // L.clear();
  // L.insertBefore(35);
  // L.insertBefore(57);
  // L.insertBefore(97);
  //
  // List G;
  //
  // G.insertBefore(14);
  // G.insertBefore(90);
  // G.insertBefore(82);
  // std::cout << L << '\n';
  // std::cout << G << '\n';
  // List S;
  // sumList(S, L, G, -1);
  // std::cout << S << '\n';
  // normalizeList(S);
  // std::cout << S << '\n';

  // BigInteger B, C, D;
  // BigInteger A = B;
  // if (A.sign() != 0) {
  //   std::cout << "whuh" << '\n';
  //   exit(EXIT_FAILURE);
  // }
  // //std::cout << A.sign() << '\n';  // constructor sign checks
  // A = BigInteger(4350324795287093857);
  // assert(A.sign() == 1);
  // A = BigInteger(-13487234);
  // assert(A.sign() == -1);
  // A = BigInteger();
  // assert(A.sign() == 0);
  // A = BigInteger(0);
  // assert(A.sign() == 0);
  // A = BigInteger("1034723790");
  // assert(A.sign() == 1);
  // A = BigInteger("-1034723790");
  // assert(A.sign() == -1);
  // A = BigInteger("0");
  // assert(A.sign() == 0);
  // A = BigInteger("+1034723790");
  //   assert(A.sign() == 1);
  //
  //
  // A = BigInteger("112233");  //pos and pos
  // B = BigInteger("332211");
  // C = BigInteger("444444");
  // D = A + B;
  // assert(D == C);
  // assert(D.sign() == 1);
  //
  // B = BigInteger("-332211"); //pos and neg
  // C = BigInteger("-219978");
  // D = A + B;
  // assert(D == C);
  // assert(D.sign() == -1);
  //
  // A = BigInteger("-332211");  //neg and pos
  // B = BigInteger("112233");
  // C = BigInteger("-219978");
  // D = A + B;
  // assert(D == C);
  // assert(D.sign() == -1);
  //
  // B = BigInteger("-112233");
  // C = BigInteger("-444444");
  // D = A + B;
  // assert(D == C);
  // assert(D.sign() == -1);
  //
  // //pos and neg to 0
  // A = BigInteger("112233");  //neg and pos
  // B = BigInteger("-112233");
  // C = BigInteger();
  // D = A + B;
  // std::cout << D << '\n';
  // assert(D == C);
  // assert(D.sign() == 0);
  //
  // std::cout << "done" << '\n';


  // List L;
  // L.insertBefore(123456);
  // L.insertBefore(789);
  // std::cout << L << '\n';
  // shiftList(L, 6);
  // std::cout << L << '\n';

  BigInteger A, B, C, D;
  A = BigInteger("2276000000000000000000000101580000000000000000000073235000000000000000000000379054691648041393022029");
  std::cout << A << '\n';

  B = BigInteger("9521651023449965519405564118547355094880066777565423238991085675906554459642294029683201863865856036");
  //B.negate();

  //std::cout << B << '\n';

  std::cout << "------" << '\n';


  A -= A;
  std::cout << A << '\n';

    return 0;

  return 0;
}
