
`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA2
* README.md
* Readme file
*********************************************************************************`

### Included Files:

*List.c* contains an implementation of a doubly-linked integer list and various access, manipulation, and miscellaneous operations.

*List.h* provides an interface for external files to interact with *List.c*


*Graph.c* contains an implementation of a vertex-based graph ADT utilizing the List ADT.

*Graph.h* provides an interface for external files to interact with *Graph.c*

*GraphTest.c* contains tests for the functions contained within *Graph.c*

*FindPath.c* uses the Graph implementation to construct an undirected graph from a text file, then determine the shortest path between various vertices.

*Makefile* provides various options for compiling the *.c* and *.h* files.
