/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA7
* DictionaryTest.cpp
* Dictionary ADT test harness
*********************************************************************************/

#include "Dictionary.h"
#include <assert.h>

int main(int argc, char **argv) {

  Dictionary B = Dictionary();
  Dictionary D = B;

  D.setValue("b", 2);
  D.setValue("a", 1);
  D.setValue("e", 5);
  D.setValue("d", 4);
  D.setValue("c", 3);
  D.setValue("f", 6);

  std::cout << D.pre_string() << '\n';
  std::cout << D << '\n';

  std::cout << D.size() << '\n';

  std::cout << D.contains("e") << '\n';
  std::cout << D.contains("h") << '\n';

  D.remove("d");

  assert(D.getValue("e") == valType(5));

  D.clear();

  std::cout << D.pre_string() << '\n';

  


  return 0;
}
