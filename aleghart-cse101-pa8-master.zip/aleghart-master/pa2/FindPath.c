/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA2
* FindPath.c
* Uses Graph ADT to create a graph from a given input file, and determine shortest paths between two vertices.
*********************************************************************************/
#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

#include "List.h"
#include "Graph.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>

char *infile;
char *outfile;

int main(int argc, char **argv) {
  if (argc != 3) {
    //occurs when the amount of runtime arguments is not two.
    fprintf(stderr, "Incorrect number of inputs.\n");
    exit(EXIT_FAILURE);
  }
//step 1: parse infile and outfile
  infile = argv[1];
  outfile = argv[2];
//open and validate files
  FILE *input;
  input = fopen(infile, "r");
  if (input == NULL) {
    fprintf(stderr, "Bad filepath for input file.\n");
    exit(EXIT_FAILURE);
  }
  FILE *output;
  output = fopen(outfile, "w");
  if (output == NULL) {
    fprintf(stderr, "Bad filepath for output file.\n");
    exit(EXIT_FAILURE);
  }
// both should now be open :)
//fprintf(stderr, "finished opening both files.\n");

  //to parse the infile:
    //step 1: the first line should be the order of the graph.
    //from there, the first word of the next lines is the source of an edge.
        //the third word is the destination of the edge.

    //once the edges are done being listed, there will be a dummy line of 0's
    //from there, the first word in the line is the "source"
      //bfs with first word as source, then, try and find a path to the destination, the third char
  char* line = NULL;
  size_t len = 100;
  getline(&line, &len, input);
  int order = atoi(line);
  //fprintf(stderr, "%i\n", order);
  Graph G = newGraph(order);


  while (getline(&line, &len, input) != -1) {
    //fprintf(stderr, "%s\n", line);
    int num1 = atoi(strtok(line, " "));
    int num2 = atoi(strtok(NULL, " "));
    if (num1 == 0){
      break;
    }
    //fprintf(stderr, "num1: %i | num2: %i\n", num1, num2);
    addEdge(G, num1, num2);
  }
  //done with part 1
  printGraph(output, G);

  List L = newList();
  while (getline(&line, &len, input) != -1) {
    //fprintf(stderr, "%s\n", line);
    int source = atoi(strtok(line, " "));
    int dest = atoi(strtok(NULL, " "));
    if (source == 0){
      break;
    }
    //fprintf(stderr, "source: %i | dest: %i\n", source, dest);
    clear(L);
    BFS(G, source);
    getPath(L, G, dest);
    moveFront(L);
    if (get(L) == NIL) {
      fprintf(output, "\nThe distance from %i to %i is infinity\nNo %i-%i path exists\n", source, dest, source, dest);
    } else {
      fprintf(output, "\nThe distance from %i to %i is %i\nA shortest %i-%i path is: ", source, dest, length(L) -1, source, dest);
      printList(output, L);
    }

  }

  freeGraph(&G);
  return 0;
}
