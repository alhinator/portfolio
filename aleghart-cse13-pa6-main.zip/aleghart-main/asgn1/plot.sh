#!/bin/bash

make clean
make

#make new data files or wipe them if they already exist
echo > /tmp/lengthPlot.dat
echo > /tmp/maxPlot.dat
echo > /tmp/histogram.dat
echo > /tmp/avgPlot.dat

for cout in {2..10000} #here, we are looping through each collatz sequence.
do
	./collatz -n $cout > /tmp/collatzOut.dat #slap collatz sequence into a temp file.
	PRINTLINE=$(cat "/tmp/collatzOut.dat")
	#initialize our variables to collect
	let seqLength=0
	let seqMax=0
	let seqAvg=0
	for line in $PRINTLINE #loop through each line in the current collatz sequence.
	do
		let seqLength=seqLength+1 #collect length
		if ((line > seqMax)); then let seqMax=line; fi #test for max
		let seqAvg=seqAvg+line #collect avg, we will divide later		
	done
	let seqAvg=seqAvg/seqLength #average the average
	let lengthBin=5*seqLength/5 #bin our histogram here so we don't have to do it in gnuplot
	#and output our data
	echo $cout" "$seqLength >> /tmp/lengthPlot.dat	
	echo $cout" "$seqMax >> /tmp/maxPlot.dat
	echo $lengthBin >> /tmp/histogram.dat
	echo $cout" "$seqAvg >> /tmp/avgPlot.dat
done

#now that we've finished getting all our data, let's slap it into gnuplot.
#here's our here-document.

#here, we will plot all four graphs into one PDF.
gnuplot <<END
	set terminal pdf
	set output "collatzGraphs.pdf"

	set title "Length of Collatz Sequences"
	set xlabel "seed (n)"
	set ylabel "length"
	set zeroaxis
	set yrange [0:]
	set xrange [0:]
	plot "/tmp/lengthPlot.dat" with dots title ""


	set title "Maximum Value of Collatz Sequences"
	set xlabel "seed (n)"
	set ylabel "maximum value"
	set zeroaxis
	set yrange [0:100000]
	set xrange [0:]
	plot "/tmp/maxPlot.dat" with dots title ""


	set title "Histogram of Collatz Sequence Lengths"
	set xlabel "length"
	set ylabel "# of occurences"
	set zeroaxis
	set yrange [0:200]
	set xrange [0:225]
	plot "/tmp/histogram.dat" smooth freq with boxes


	set title "Average Value of Collatz Sequences"
	set xlabel "seed (n)"
	set ylabel "average value"
	set zeroaxis
	set yrange [0:100000]
	set xrange [0:10000]
	plot "/tmp/avgPlot.dat" with dots title ""
	

END
