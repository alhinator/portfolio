#!/bin/bash

make clean
make

echo > /tmp/allsort.dat

#grab the runtime of each, using the same seed and the same length
#change length every run using same seed
#awk it into the dat file

for cout in {1..20}
do
	./sorting -a -n $cout -p 0 >> /tmp/allsort.dat
done

awk '$1 ~ /Bubble/ {print $3,$5+$7}' /tmp/allsort.dat > /tmp/bubble.dat
awk '$1 ~ /Shell/ {print $3,$5+$7}' /tmp/allsort.dat > /tmp/shell.dat
awk '$1 ~ /Quick/ {print $3,$5+$7}' /tmp/allsort.dat > /tmp/quick.dat
awk '$1 ~ /Heap/ {print $3,$5+$7}' /tmp/allsort.dat > /tmp/heap.dat

gnuplot <<END
	set terminal pdf
	set output "sorts.pdf"

	set title "Operations taken to complete various sorts"
	set xlabel "Array Length"
	set ylabel "Moves + Comparisons"
	set zeroaxis 
	plot "/tmp/bubble.dat" with lines, \
	"/tmp/shell.dat" with lines, \
	"/tmp/quick.dat" with lines, \
	"/tmp/heap.dat" with lines

END
