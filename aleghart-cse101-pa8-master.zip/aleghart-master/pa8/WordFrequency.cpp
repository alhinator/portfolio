

#include "Dictionary.h"

#include <iostream>
#include <fstream>
#include <iomanip>

#include <string>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
using namespace std;

#define MAX_LEN 300

#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.


int main(int argc, char  *argv[]) {
  size_t begin, end, len;
  ifstream in;
  ofstream out;
  string line;
  string tokenBuffer;
  string token;
  //string delim = " ";
  string delim = " \r\n\t\\\"\',<.>/?;:[{]}|`~!@#$%^&*()-_=+0123456789";

  // check command line for correct number of arguments
  if( argc != 3 ){
    cerr << "Usage: " << argv[0] << " <input file> <output file>" << endl;
    return(EXIT_FAILURE);
  }

  // open files for reading and writing
  in.open(argv[1]);
  if( !in.is_open() ){
    cerr << "Unable to open file " << argv[1] << " for reading" << endl;
    return(EXIT_FAILURE);
  }

  out.open(argv[2]);
  if( !out.is_open() ){
    cerr << "Unable to open file " << argv[2] << " for writing" << endl;
    return(EXIT_FAILURE);
  }


  Dictionary D;


    while( getline(in, line) )  {
      //std::cout << line << '\n';
      len = line.length();

      begin = min(line.find_first_not_of(delim, 0), len);
      end   = min(line.find_first_of(delim, begin), len);
      token = line.substr(begin, end-begin);

      while (token != "") {
        for (char& c : token) { //lowercase all
          c = tolower(c);
          // if (c == '\n' || c == '\r') {
          //   std::cout << "found a return in token" << '\n';
          // }
        }
        //out << "|" << token << "|";
        if (!D.contains(token)) { //new word
          D.setValue(token, 1);
        } else {
          D.getValue(token)++;
        }

        begin = min(line.find_first_not_of(delim, end+1), len);
        end   = min(line.find_first_of(delim, begin), len);
        token = line.substr(begin, end-begin);
      }

    }

  out << D << '\n';
  // close files
  in.close();
  out.close();




  return 0;
}
