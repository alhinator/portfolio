/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA4
* Matrix.c
* Matrix ADT implementation
*********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "Matrix.h"
#include "List.h"

//typedefs
typedef struct CellObj* Cell;

typedef struct CellObj{ //changing this to cell bc the list is called entries. easier to remember.
  int column;
  double value;
} CellObj;

typedef struct MatrixObj* Matrix;


typedef struct MatrixObj{
  int n;
  //int nnz; //for easy keeping track
  List* entries;

} MatrixObj;

//Constructors/Destructors
Cell newCell(int column, double value){
  Cell C = malloc(sizeof(CellObj));
  C->column = column;
  C->value = value;
  return C;
}
// void freeCell(Cell* pC){
//   fprintf(stderr, "in freeCell\n");
//   if( pC != NULL && *pC != NULL ){
//       free(*pC);
//       fprintf(stderr, "pC freed\n" );
//
//       pC = NULL;
//    }
// }


Matrix newMatrix(int n){ //returns pointer to a new nxn matrix with no entries.
  Matrix M = malloc(sizeof(MatrixObj));
  assert (M != NULL);
  M->n = n; // set n
  //M->nnz = 0; // start off number of filled entries at zero
  M->entries = malloc(sizeof(List) * (n + 1)); //create space for n lists. DON'T USE LIST 0
  M->entries[0] = NULL;
  for (int i = 1; i <= n; i++) {
    M->entries[i] = newList();
    //each "List" in "Entries" represents one horizontal row in matrix M.

    //fprintf(stderr, "created new list (row %i)\n", i);
  }
  return M;
}
void freeMatrix(Matrix* pM){
  if (*pM != NULL && pM != NULL) {
    for (int i = 1; i <= (*pM)->n; i++) {
      //fprintf(stderr, "freeing list %i\n", i);
      freeList(&(*pM)->entries[i]);
      //in freeList, each vptr is freed by freeNode, so we don't need to free them here.
    }
    free((*pM)->entries);
    free(*pM);
    pM = NULL;
  }
}

//helper functions
/*void printMatrixShitty(Matrix M){
  if (M == NULL) {
    fprintf(stderr, "Matrix ADT | printMatrixShitty() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  for (int i = 0; i < M->n; i++) {
    printList(stdout, M->entries[i]);
  }
}*/
double dotProduct(List A, List B){
  if (A == NULL || B == NULL) {
    fprintf(stderr, "Matrix ADT | dotProduct() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (length(A) == 0 || length(B) == 0) { //one or both vectors are zero-vectors.
    return 0;
  }
  //takes two lists of potentially different lengths, and multiplies them together dot-product style.
    //for each index 0-n, if both lists contain an entry at that "column" (even though not technically column)
    //then multiply those values together and add it to a cumulative sum.
  moveFront(A);
  moveFront(B);

  int currCol = 0;
  double _dotProduct = 0;
  while (index(A) >= 0 && index(B) >= 0) {
    //we can exit the loop if one list is done; the remaining entries will be 0 if only one list has them.
    Cell CA = NULL;
    Cell CB = NULL;
    //if (index(LA) >= 0) { //assign CA if it's within list bounds. (checked above now)
      CA = (struct CellObj*) get(A);
    //}
    //if (index(LB) >= 0) { //assign CB if it's within list bounds. (checked above now)
      CB = (struct CellObj*) get(B);
    //}
    ///////
    if (CA && CA->column == currCol && CB && CB->column == currCol) { //if both are correct col
      _dotProduct += CA->value * CB->value;
      moveNext(A); // moveNext on both since the cell values have been used.
      moveNext(B);
    } else if (CA && CA->column == currCol) { //occurs if ONLY A is the correct col
      moveNext(A);
    } else if (CB && CB->column == currCol) { //occurs if ONLY B is the correct col
      moveNext(B);
    }

    currCol++;
  }


  return _dotProduct;
}
double getEntry(Matrix M, int i, int j){
  List L = M->entries[i];
  if (length(L) == 0) {
    return 0;
  }
  moveFront(L);
  while (index(L) >= 0) {
    Cell C = (struct CellObj*) get(L);
    if (C->column == j) {
      return C->value;
    }
    moveNext(L);
  }
  return 0;
}

//access functions
int size(Matrix M){
  if (M == NULL) {
    fprintf(stderr, "Matrix ADT | size() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return M->n;
}
int NNZ(Matrix M){
  if (M == NULL) {
    fprintf(stderr, "Matrix ADT | NNZ() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  int nnz = 0;
  for (int i = 1; i <= M->n; i++) {
    nnz += length(M->entries[i]);
  }
  return nnz;
}
int equals(Matrix A, Matrix B){
  if (A == NULL || B == NULL) {
    fprintf(stderr, "Matrix ADT | equals() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (A->n != B->n || NNZ(A) != NNZ(B)) { //different size, different NNZ
    //fprintf(stderr, "A and B are different n or NNZ\n");
    return 0;
  }
  // THIS CODE WORKS, BUT IS VERY INEFFICIENT.
  // for (int i = 1; i < A->n; i++) {
  //   for (int j = 1; j < A->n; j++) {
  //     if (getEntry(A, i, j) != getEntry(B, i, j)) {
  //       return 0;
  //     }
  //   }
  // }

  // make a copy of B so that when comparing a matrix to itself, we do not Fuck Up
  Matrix COP_B = copy(B);

  for (int i = 1; i < A->n; i++) {
    List LA = A->entries[i];
    List LB = COP_B->entries[i];
    if (length(LA) != length(LB)) {
      return 0;
    }
    moveFront(LA);
    moveFront(LB);
    while (index(LA) >= 0 && index(LB) >= 0) {
      Cell CA = (struct CellObj*)get(LA);
      Cell CB = (struct CellObj*)get(LB);
      if (CA->value != CB->value || CA->column != CB->column) {
        return 0; //the column and value must be the same in both.
      }
      moveNext(LA);
      moveNext(LB);
    }
  }
  freeMatrix(&COP_B);
  return 1;
}



//manipulation procedures
void makeZero(Matrix M){
  if (M == NULL) {
    fprintf(stderr, "Matrix ADT | makeZero() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  for (int i = 1; i <= M->n; i++) {
    clear(M->entries[i]);
  }
  //M->nnz = 0;
}
Matrix copy(Matrix A){
  if (A == NULL) {
    fprintf(stderr, "Matrix ADT | copy() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  Matrix B = newMatrix(A->n); //create a new matrix B the same nxn as A
  for (int i = 1; i <= A->n; i++) { //go through every row of A.
    List L = A->entries[i]; //placeholder List
    moveFront(L);
    while (index(L) >= 0) {
      Cell C = (struct CellObj*) get(L);
      // do NOT simply copy the pounter, we must copy the values.
      changeEntry(B, i, C->column, C->value);
      //changeEntry makes it slightly more time complex BUT is able to properly track nnz
      moveNext(L);
      C = NULL;
    }
  }
  return B;
}
void changeEntry(Matrix M, int i, int j, double x){
  if (M == NULL) {
    fprintf(stderr, "Matrix ADT | changeEntry() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (i < 1 || i > M->n || j < 1 || j > M->n) {
    fprintf(stderr, "Matrix ADT | changeEntry() i or j parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }

  //first off, we need to find row i.
  //fprintf(stderr, "in changeentry\n" );
  List L = M->entries[i];
  //fprintf(stderr, "accessed L\n" );
  if (L == NULL) {
    fprintf(stderr, "Matrix ADT | changeEntry() something is wrong with List.\n");
    exit(EXIT_FAILURE);
  }
  //now, insert the data x into the list, making sure that the list entry
    // is sorted based on j and the current entries in the list. Assume
    // List entries are Cell types.

  if (length(L) == 0 && x != 0) { //if empty
    //fprintf(stderr, "appended to empty list.\n" );
    Cell new = newCell(j, x);
    append(L, new);
    //free(new);
    //M->nnz++;
    return;
  }

  moveFront(L);
  Cell cell;

  while (index(L) >= 0) { //loop through all entries
    cell = (struct CellObj*) get(L);
    //fprintf(stderr, "got cell: %i , %f\n", cell->column, cell->value);
    if (cell->column == j) {
      //fprintf(stderr, "in if\n");
      //fprintf(stderr, "found existing spot, overwriting\n");
      if (x != 0) {
        Cell new = newCell(j, x);
        set(L , new);
      }
      else {
        delete(L); //do not want a zero-entry in our list.
        //M->nnz --;
      }
      return;
    }
    if (cell->column > j && x != 0) { //stop when we find an element with a column larger than our desired column.
      Cell new = newCell(j, x);
      insertBefore(L, new);
      //fprintf(stderr, "found good spot, inserting\n");

      //M->nnz ++;
      return;
    }
    moveNext(L);
  }
  if (index(L) == -1 && x != 0) { //we've ran off the back
    Cell new = newCell(j, x);
    append(L, new);
    //fprintf(stderr, "ran off back, inserting\n");
    //M->nnz++;
  }
  cell = NULL;
  L = NULL;
}
Matrix transpose(Matrix A){ //same code as copy except insert swapped row and col.
  if (A == NULL) {
    fprintf(stderr, "Matrix ADT | transpose() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  Matrix B = newMatrix(A->n); //create a new matrix B the same nxn as A
  for (int i = 1; i <= A->n; i++) { //go through every row of A.
    List L = A->entries[i]; //placeholder List
    moveFront(L);
    while (index(L) >= 0) {
      Cell C = (struct CellObj*) get(L);
      // do NOT simply copy the pounter, we must copy the values.
      changeEntry(B, C->column, i, C->value);
      //changeEntry makes it slightly more time complex BUT is able to properly track nnz
      moveNext(L);
    }
  }
  return B;
}
Matrix scalarMult(double x, Matrix A){ //same code as copy, except we "changeEntry" with the multiplied value.
  if (A == NULL) {
    fprintf(stderr, "Matrix ADT | scalarMult() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  Matrix B = newMatrix(A->n); //create a new matrix B the same nxn as A
  for (int i = 1; i <= A->n; i++) { //go through every row of A.
    List L = A->entries[i]; //placeholder List
    moveFront(L);
    while (index(L) >= 0) {
      Cell C = (struct CellObj*) get(L);
      // do NOT simply copy the pounter, we must copy the values.
      changeEntry(B, i, C->column, C->value * x);
      //changeEntry makes it slightly more time complex BUT is able to properly track nnz
      moveNext(L);
      C = NULL;
    }
  }
  return B;
}
Matrix diff(Matrix A, Matrix B){
  if (A == NULL || B == NULL) {
    fprintf(stderr, "Matrix ADT | diff() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (A->n != B->n) {
    fprintf(stderr, "Matrix ADT | diff() was called on two arrays of different size.\n");
    exit(EXIT_FAILURE);
  }
  Matrix C = copy(A); //create a new matrix C which is the copy of A.
  //now to add B to A.
  for (size_t i = 1; i <= C->n; i++) {
    List L = B->entries[i];
    if (length(L) == 0) {
      continue; //don't need to modify this row.
    }
    moveFront(L);
    while (index(L) >= 0) { //loop thru the row and add all its values to the current row in C.
      Cell CELL = (struct CellObj*) get(L);
      double d = getEntry(C, i, CELL->column);
      //fprintf(stderr, "got entry\n" );
      d -= CELL->value;
        //fprintf(stderr, "changing value\n");
      changeEntry(C, i, CELL->column, d);

      moveNext(L);
      //fprintf(stderr, "moved next\n");
    }
  }
  return C;
}
Matrix sum(Matrix A, Matrix B){
  if (A == NULL || B == NULL) {
    fprintf(stderr, "Matrix ADT | diff() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (A->n != B->n) {
    fprintf(stderr, "Matrix ADT | diff() was called on two arrays of different size.\n");
    exit(EXIT_FAILURE);
  }
  Matrix C = copy(A); //create a new matrix C which is the copy of A.
  //now to add B to A.
  for (size_t i = 1; i <= C->n; i++) {
    List L = B->entries[i];
    if (length(L) == 0) {
      continue; //don't need to modify this row.
    }
    moveFront(L);
    while (index(L) >= 0) { //loop thru the row and add all its values to the current row in C.
      Cell CELL = (struct CellObj*) get(L);
      double d = getEntry(C, i, CELL->column);
      //fprintf(stderr, "got entry\n" );
      d += CELL->value;
      //fprintf(stderr, "changing value\n");
      changeEntry(C, i, CELL->column, d);
      moveNext(L);
      //fprintf(stderr, "moved next\n");
    }
  }
  return C;
}
Matrix product(Matrix A, Matrix B){
  if (A == NULL || B == NULL) {
    fprintf(stderr, "Matrix ADT | product() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (A->n != B->n) {
    fprintf(stderr, "Matrix ADT | product() was called on two arrays of different size.\n");
    exit(EXIT_FAILURE);
  }
  Matrix C = newMatrix(A->n); //create a new matrix C the same nxn as A
  Matrix BT = transpose(B); //THIS MAKES LIFE SO MUCH EASIER.
    //also, this accounts for Fuckery when multiplying a matrix by itself.
  //for every cell in matrix C, if the row i and column j associated with that
  //cell are both nonempty, find the dot product of the row in A and row in B, and
  // assign it as the value of the cell in C.
  for (int i = 1; i <= C->n; i++) {
    //fprintf(stderr, "row %i\n", i );
    if (length(A->entries[i]) == 0) {
      continue; //all relevant rows will be 0.
    }
    for (int j = 1; j <= C->n; j++) {
      //fprintf(stderr, "col %i\n", j );
      if (length(BT->entries[j]) == 0) {
        continue; //all relevant columns will be 0.
      }
      double dp = dotProduct(A->entries[i], BT->entries[j]);
      if (dp != 0) {
        changeEntry(C, i , j, dp);
      }
    }
  }
  freeMatrix(&BT);
  return C;
}




//other
void printMatrix(FILE* out, Matrix M){
  //loop through all entries: in each entry, print the existing cells.
  //do not print zero-rows.
  for (int i = 1; i <= M->n; i++) {
    List L = M->entries[i];
    if (length(L) == 0) {
      continue;
    }
    fprintf(out, "%i:", i);
    moveFront(L);
    while (index(L) >= 0) {
      Cell C = (struct CellObj*)get(L);
      fprintf(out, " (%i, %.1f)", C->column, C->value);
      moveNext(L);
    }
    fprintf(out, "\n");

  }
}
