#include "node.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>

struct PriorityQueue {
  uint32_t capacity;
  uint32_t c_key; //stands for current_key. if its -1 then that means teh q is empty
  Node **queue;
};

struct PriorityQueue *pq_create(uint32_t capacity){
  struct PriorityQueue *new_pq = (struct PriorityQueue*) malloc(sizeof(struct PriorityQueue));
  if (new_pq == NULL) {
    printf("PQ create malloc failed.\n");
    return NULL;
  }
  new_pq->capacity = capacity;
  new_pq->c_key = 0;
  new_pq->queue = (Node **) calloc(capacity, sizeof(Node *));
  if (new_pq->queue == NULL) {
    printf("PQ create calloc failed.\n");
    return NULL;
  }
  return new_pq;
}

void pq_delete(struct PriorityQueue **q){
  for (size_t i = 0; i < (*q)->capacity; i++) {
    if ((*q)->queue[i] != NULL) {
      node_delete(&(*q)->queue[i]);
    }
  }
  free((*q)->queue);
  (*q)->queue = NULL;
  free(*q);
  *q = NULL;
}

uint32_t l_child(uint32_t n){ //that's an L. Left. left child.
  return (2 * n) + 1;
}

uint32_t r_child(uint32_t n){//right child
  return (2 * n) + 2;
}

uint32_t parent(uint32_t n){//parent element
  return (n - 1) / 2;
}

void swap(Node **a, uint32_t b, uint32_t c){ //same as the stats swap. make temp vars and then swap.
  struct Node *tmp = a[b];
  a[b] = a[c];
  a[c] = tmp;
  return;
}

void up_heap(Node **a, uint32_t n){ //up heap moves a node up the heap until it is smaller than all the nodes below it.
  uint32_t par = parent(n); // get the parent of n
  while(n > 0 && a[n]->frequency < a[par]->frequency ){ //while larger than parent and not root
    swap(a, n, par); //swap
    n = par; //set new position
    par = parent(n); // get new parent.
  }
}

void down_heap(Node **a, uint32_t heap_size){ //moves a node down the heap to its correct spot.
  uint32_t n = 0; //start at the root.
  uint32_t smaller; //index of the smaller child of the two.
  while (l_child(n) < heap_size) {
    if ( r_child(n) == heap_size) { //if the right child is the largest in the heap (bottom right)
      smaller = l_child(n); //then the smaller is obviously the left child.
    } else if (a[l_child(n)]->frequency < a[r_child(n)]->frequency){ //compare the two
      smaller = l_child(n); // and set smaller to equal the smaller one.
    } else {
      smaller = r_child(n);
    }
    if (a[n]->frequency < a[smaller]->frequency) {
      break; //once n is smaller than the smaller child, we break.
    }
    swap(a, n, smaller); // otherwise, we swap the two.
    n = smaller; // and set index of new n.
  }
}

bool pq_empty(struct PriorityQueue *q){
  return q->c_key == 0;
}

bool pq_full(struct PriorityQueue *q){
  return (q->c_key) == q->capacity;
}

uint32_t pq_size(struct PriorityQueue *q){
  return q->c_key;
}

bool enqueue(struct PriorityQueue *q, Node *n){
  if(pq_full(q)){return false;}; // if this queue is full we cant add another.
  //current position to insert into the queue is c_key.
  q->queue[q->c_key] = n; //insert at spot
  up_heap(q->queue, q->c_key); // move it up the heap to the proper spot.
  q->c_key ++; //increment c_key after key addition.

  return true;
}

bool dequeue(struct PriorityQueue *q, Node **n){
  if (pq_empty(q)) {return false;}; //if the queue is empty we can't remove from it.
  *n = q->queue[0]; //set pointer to root. this is our smallest item.
  //printf("n is:");
  //node_print(*n);
  q->c_key --; //decrease current key by one.
  struct Node *tmp = q->queue[q->c_key]; //grab the bottom right item. we are going to put this at the top of the queue and then send it downwards.
  //printf("grammed largest:");
  //node_print(tmp);
  q->queue[0] = tmp; // set the root to the grabbed leaf
  q->queue[q->c_key] = NULL; //remove the leaf that has been duplicated.
  down_heap(q->queue, q->c_key); // move that bad boy down the list.
  //printf("n is:");
  //node_print(*n);
  return true;
}

void pq_print(struct PriorityQueue *q){
  if (pq_empty(q)) {
    printf("This queue is empty.\n");
    return;
  }
  for (size_t i = 0; i < q->c_key; i++) {
    node_print(q->queue[i]);
  }
}
