#include "node.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

uint64_t seeks; // Number of seeks performed.
uint64_t links; // Number of links traversed.

struct LinkedList {
  uint32_t length;
  Node *head;
  Node *tail;
  bool mtf;
};

struct LinkedList *ll_create(bool mtf){
  struct LinkedList *new_ll = (struct LinkedList *) malloc(sizeof(struct LinkedList));
  if (new_ll != NULL) {
    new_ll->length = 0;
    new_ll->head = node_create(NULL, NULL);
    new_ll->tail = node_create(NULL, NULL);
    new_ll->mtf = mtf;
    new_ll->head->next = new_ll->tail;
    new_ll->tail->prev = new_ll->head;
  }
  return new_ll;
}

void ll_delete(struct LinkedList **ll){

  while ((*ll)->head != NULL) { //while there is a head
    struct Node *temp = (*ll)->head; //set our temp variable to point at the head node
    (*ll)->head = temp->next; //set the new head node to now be the old second node
    node_delete(&temp); //delete the old head
  }
  free(*ll);
  ll = NULL; //free and set to null
  return;
}

uint32_t ll_length(struct LinkedList *ll){
  return ll->length;
}

bool oldspeak_comp(char *test, char *original){
  if (test == NULL) { //first thing, is test null?
    return false;
  }
  size_t original_len = 0;
  while (original[original_len] != '\0') {
    original_len++;
  }
  size_t test_len = 1;
  while (test[test_len] != '\0') {
    test_len++;
  }
  if (original_len != test_len) {
    return false;
  }
  //now we have determined the two strings are the same length.

  for (size_t i = 0; i < original_len; i++){
    if (original[i] != test[i]) {
      return false;
    }
  }

  return true;
}

struct Node *ll_lookup(struct LinkedList *ll, char *oldspeak){
  //printf("in ll_lookup\n");
  if (ll == NULL || ll_length(ll) == 0) {
    //printf("list is empty\n");
    seeks++;
    return false;
  }
  //printf("in ll_lookup after empty check\n");

  struct Node *c_node = ll->head->next;
  //printf("got c_node\n");
  //printf("testing %s and %s.\n", c_node->oldspeak, oldspeak);

  seeks++;
  while (c_node != NULL && c_node->oldspeak != NULL) {

    links++;
    if (oldspeak_comp(c_node->oldspeak, oldspeak)) {
      //mtf
      //printf("found a match between %s and %s.\n", c_node->oldspeak, oldspeak);
      if (ll->mtf) {
        /*call this shit the shurima shuffle cause we shuffling pointers around
        without using any temp variables*/
        //set the current position's previous and next to point to each other.
        c_node->next->prev = c_node->prev;
        c_node->prev->next = c_node->next;
        //set the original first item to point at the new first item as prev
        ll->head->next->prev = c_node;
        //set the new first item to poitn at the original first item as next
        c_node->next = ll->head->next;
        //set the head to point at the new first as its next
        ll->head->next = c_node;
        //set the new first to point at the head as previous
        c_node->prev = ll->head;
      }
      return c_node;
    }
    c_node = c_node->next;
  }
  //printf("end ll_lookup\n");
  return NULL;
}

void ll_insert(struct LinkedList *ll, char *oldspeak, char *newspeak){
  if (ll_lookup(ll, oldspeak) == NULL) {
    struct Node *new_node = node_create(oldspeak, newspeak);
    //set the original first item to point at the new first item as prev
    ll->head->next->prev = new_node;
    //set the new first item to poitn at the original first item as next
    new_node->next = ll->head->next;
    //set the head to point at the new first as its next
    ll->head->next = new_node;
    //set the new first to point at the head as previous
    new_node->prev = ll->head;
    ll->length += 1;
  } else {
    //printf("%s | %s is already in this linked list. \n", oldspeak , newspeak);
  }
  return;
}

void ll_print(struct LinkedList *ll){
  //printf("this linked list is:\n");
  struct Node *curr = ll->head->next; //this should cut off the head.
  while (curr->next != NULL) { //this should cut off the tail.
    node_print(curr);
    curr = curr->next;
  }
  return;
}

void ll_stats(uint32_t *n_seeks, uint32_t *n_links){
  //printf("in ll_stats\n");
  *n_seeks = seeks;
  *n_links = links;
  //printf("end ll_stats\n");
  return;
}
