#!/bin/bash

make clean
make

echo > /tmp/p6c4avg.dat

echo > /tmp/2pavg.dat
echo > /tmp/4pavg.dat
echo > /tmp/6pavg.dat
echo > /tmp/8pavg.dat

echo > /tmp/highlowturn.dat

#On average, how long does a game of dreidel with 6 players and 4 coins last? What is the longest
#		game, and what is the shortest game?
#• If there are more players, does the game last more or fewer rounds? Experiment with 3 coins per
#		player to test your idea.
#• Is there an advantage (or disadvantage) to position in a round? In other words, are players in a
#		particular position more likely to win or lose a game?

for cout in {2..1000} #run games with seeds between 2 and 1,000
do
	./play-dreidel -p 6 -c 4 -s $cout -b >> /tmp/p6c4avg.dat 	#our first question

	./play-dreidel -p 2 -c 3 -s $cout -b >> /tmp/2pavg.dat #second question
	./play-dreidel -p 4 -c 3 -s $cout -b >> /tmp/4pavg.dat
	./play-dreidel -p 6 -c 3 -s $cout -b >> /tmp/6pavg.dat
	./play-dreidel -p 8 -c 3 -s $cout -b >> /tmp/8pavg.dat #gonna compare all these on one graph.

	./play-dreidel -p 8 -c 3 -s $cout -h>> /tmp/highlowturn.dat #our last question

done

PRINTLINE=$(cat "/tmp/2pavg.dat")
let seqLength=0
let seqMax=0
let seqMin=0
let seqAvg=0
for line in $PRINTLINE #loop through each line in the current collatz sequence.
do
	let seqLength=seqLength+1 #collect length
	if ((line > seqMax)); then let seqMax=line; fi #test for max
	if ((line < seqMin || seqMin == 0)); then let seqMin=line; fi #test for min
	let seqAvg=seqAvg+line #collect avg, we will divide later
done
let seqAvg=seqAvg/seqLength #average the average
echo "2-PLAYER
			Average Length: $seqAvg
			Longest Game: $seqMax
			Shortest Game: $seqMin"

PRINTLINE=$(cat "/tmp/4pavg.dat")
let seqLength=0
let seqMax=0
let seqMin=0
let seqAvg=0
for line in $PRINTLINE #loop through each line in the current collatz sequence.
do
	let seqLength=seqLength+1 #collect length
	if ((line > seqMax)); then let seqMax=line; fi #test for max
	if ((line < seqMin || seqMin == 0)); then let seqMin=line; fi #test for min
	let seqAvg=seqAvg+line #collect avg, we will divide later
done
let seqAvg=seqAvg/seqLength #average the average
echo "4-PLAYER
			Average Length: $seqAvg
			Longest Game: $seqMax
			Shortest Game: $seqMin"

PRINTLINE=$(cat "/tmp/6pavg.dat")
let seqLength=0
let seqMax=0
let seqMin=0
let seqAvg=0
for line in $PRINTLINE #loop through each line in the current collatz sequence.
do
	let seqLength=seqLength+1 #collect length
	if ((line > seqMax)); then let seqMax=line; fi #test for max
	if ((line < seqMin || seqMin == 0)); then let seqMin=line; fi #test for min
	let seqAvg=seqAvg+line #collect avg, we will divide later
done
let seqAvg=seqAvg/seqLength #average the average
echo "6-PLAYER
			Average Length: $seqAvg
			Longest Game: $seqMax
			Shortest Game: $seqMin"

PRINTLINE=$(cat "/tmp/8pavg.dat")
let seqLength=0
let seqMax=0
let seqMin=0
let seqAvg=0
for line in $PRINTLINE #loop through each line in the current collatz sequence.
do
	let seqLength=seqLength+1 #collect length
	if ((line > seqMax)); then let seqMax=line; fi #test for max
	if ((line < seqMin || seqMin == 0)); then let seqMin=line; fi #test for min
	let seqAvg=seqAvg+line #collect avg, we will divide later
done
let seqAvg=seqAvg/seqLength #average the average
echo "8-PLAYER
			Average Length: $seqAvg
			Longest Game: $seqMax
			Shortest Game: $seqMin"

#and now we graph.
gnuplot <<END
	set terminal pdf
	set output "dreidelGraphs.pdf"

	set title "Average Length of 6-player 4-coin game"
	set xlabel "Length"
	set ylabel "Frequency"
	set zeroaxis
	plot "/tmp/p6c4avg.dat" smooth freq with boxes

	set title "Comparing Game Lengths Based on Player Count"
	set xlabel "Length"
	set ylabel "Frequency"
	set zeroaxis
	plot "/tmp/2pavg.dat" smooth freq with boxes, \
	"/tmp/4pavg.dat"smooth freq with boxes, \
	"/tmp/6pavg.dat" smooth freq with boxes, \
	"/tmp/8pavg.dat" smooth freq with boxes

	set title "Frequency of Which Player in the Turn Order Wins"
	set xlabel "Player #"
	set ylabel "Frequency"
	set xtics 0,1,8
	set zeroaxis
	plot "/tmp/highlowturn.dat" smooth freq with boxes
END
