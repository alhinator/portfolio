#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>

#include "bv.h"
#include "bf.h"
#include "node.h"
#include "ll.h"
#include "ht.h"
#include "parser.h"
#include "messages.h"

#define OPTIONS "ht:f:ms"

void print_help_message(){
  fprintf( stderr,
"Usage: ./banhammer [options]\n"
"  ./banhammer will read in words from stdin, identify any badspeak or old speak and output an\n"
"  appropriate punishment message. The badspeak and oldspeak (with the newspeak translation) \n"
"  that caused the punishment will be printed after the message. If statistics are enabled\n"
"  punishment messages are suppressed and only statistics will be printed.\n"
"    -t <ht_size>: Hash table size set to <ht_size>. (default: 10000)\n"
"    -f <bf_size>: Bloom filter size set to <bf_size>. (default 2^19)\n"
"    -s          : Enables the printing of statistics.\n"
"    -m          : Enables move-to-front rule.\n"
"    -h          : Display program synopsis and usage.\n");
}

uint32_t hash_table_size = 10000;
uint32_t bloom_filter_size = 524288;
bool mtf = false;
bool statistics = false;


int main(int argc, char *argv[]) {

  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 't':
        hash_table_size = (uint32_t) strtoul(optarg, NULL, 10);
        if (hash_table_size > 0 && hash_table_size <= 4294967295) {
          //printf("mep\n");
          break;
        }else{
          print_help_message();
          exit(EXIT_FAILURE);
        }
        break;
      case 'f':
        bloom_filter_size = (uint32_t) strtoul(optarg, NULL, 10);
        if (bloom_filter_size > 0 && bloom_filter_size <= 4294967295) {
          //printf("gec\n");
          break;
        }else{
          print_help_message();
          exit(EXIT_FAILURE);
        }
        break;
      case 'm':
        mtf = true;
        break;
      case 's':
        statistics = true;
        break;
      case 'h':
        print_help_message();
        exit(EXIT_SUCCESS);
        break;
      case '?':
        print_help_message();
        exit(EXIT_FAILURE);
    }
  }
  //printf("getopt loop finisehd!\n");

  struct BloomFilter *bf_main = bf_create(bloom_filter_size);
  struct HashTable *ht_main = ht_create(hash_table_size, mtf);

  //insert badspeak into our bf and ht
  FILE *bs_file = fopen("badspeak.txt", "r");
  struct Parser* parse_bad = parser_create(bs_file);
  char badspeak[MAX_PARSER_LINE_LENGTH];
  while (next_word(parse_bad, badspeak)){
      bf_insert(bf_main, badspeak);
      ht_insert(ht_main, badspeak, NULL);
      //printf("@@ %s @@\n", badspeak);
  }
  parser_delete(&parse_bad);
  fclose(bs_file);

  //printf("finished inserting badspeak\n");

  //insert oldspeak and newspeak into our bf and ht
  FILE *ns_file = fopen("newspeak.txt", "r");
  struct Parser* parse_new = parser_create(ns_file);

  char oldspeak[MAX_PARSER_LINE_LENGTH];
  char newspeak[MAX_PARSER_LINE_LENGTH];
  while (next_word(parse_new, oldspeak)) {
      bf_insert(bf_main, oldspeak);
      next_word(parse_new, newspeak);
      ht_insert(ht_main, oldspeak, newspeak);
      //for debug ---
      //node_print(ht_lookup(ht_main, oldspeak));
      // ---
  }
  parser_delete(&parse_new);
  fclose(ns_file);

  //printf("finished inserting oldspeak/newspeak\n");

//ht_print(ht_main);

  struct LinkedList* used_badspeak = ll_create(false);
  struct LinkedList* used_oldspeak = ll_create(false);
  //printf("made lists\n" );
  //PARSER  ------------------------
  struct Parser* parse_main = parser_create(stdin);
  char word[MAX_PARSER_LINE_LENGTH];
  while (next_word(parse_main, word)) {
    //"word" is the word we want to check against the firewall.
    //fprintf(stderr, "%s\n", word);

    //step 1: check against the bloom filter.
    if (bf_probe(bf_main, word)) {
      //printf("%s is in the filter.\n", word);

      struct Node* w_node = ht_lookup(ht_main, word);
      if (w_node != NULL) { //found it
        //node_print(w_node);
        if (w_node->newspeak == NULL) { //there is no translation.
          ll_insert(used_badspeak, w_node->oldspeak, NULL);
        } else {
          ll_insert(used_oldspeak, w_node->oldspeak, w_node->newspeak);
        }
      }
    }else{
      //printf("%s is not in the hash table.\n", word);
      continue; //This word does not need to be punished.
    }
  }
  //at this point, we should have gotten all of our stdin inputs! now we can
  //PUNISH THE THOUGHT-CRIMINALS.
  int severity = 0;
  //severity will become 1 if they use only badspeak.
  //severity will become 2 if they use only oldspeak.
  //severity will become 3 if they use both.
  //there's probably a more efficient way to do this but i'm fucking fried.
  uint32_t u_old = ll_length(used_oldspeak);
  uint32_t u_bad = ll_length(used_badspeak);
  if (u_old == 0 && u_bad == 0) {
    //you are a free man (for now)
  } else if (u_old == 0 && u_bad != 0) {
    severity = 1;
  } else if (u_old != 0 && u_bad == 0) {
    severity = 2;
  } else if (u_old != 0 && u_bad != 0) {
    severity = 3;
  }


  if (!statistics) {
    switch (severity) {
      case 1:
        fprintf(stdout, "%s", badspeak_message);
        ll_print(used_badspeak);
        break;
      case 2:
        fprintf(stdout, "%s", goodspeak_message);
        ll_print(used_oldspeak);
        break;
      case 3:
        fprintf(stdout, "%s", mixspeak_message);
        ll_print(used_badspeak);
        ll_print(used_oldspeak);
        break;
    }
  }else{
    //print the statistics and shit
    //printf("printing stats!\n");
    uint32_t ht_k, ht_h, ht_m, ht_e;
    uint32_t bf_k, bf_h, bf_m, bf_e;

    ht_stats(ht_main, &ht_k, &ht_h, &ht_m, &ht_e);
    printf("ht keys: %"PRIu32"\n", ht_k);
    printf("ht hits: %"PRIu32"\n", ht_h);
    printf("ht misses: %"PRIu32"\n", ht_m);
    printf("ht probes: %"PRIu32"\n", ht_e); // need fix this

    bf_stats(bf_main, &bf_k, &bf_h, &bf_m, &bf_e);
    printf("bf keys: %"PRIu32"\n", bf_k);
    printf("bf hits: %"PRIu32"\n", bf_h);
    printf("bf misses: %"PRIu32"\n", bf_m);
    printf("bf bits examined: %"PRIu32"\n", bf_e);

    float bepm = (bf_m == 0 ? 0 : (float)(bf_e-N_HASHES*bf_h)/bf_m);
    float fp = (float)ht_m / bf_h;
    //printf("fp = misses %"PRIu32" over hits %"PRIu32" = %f\n", ht_m , bf_h);
    float bfl = (float)bf_count(bf_main)/bf_size(bf_main);
    float asl = (float)ht_e / (ht_h + ht_m);

    printf("Bits examined per miss: %f\n",bepm ); //need fix this
    printf("False positives: %f\n", fp); //need fix this
    printf("Average seek length: %f\n", asl); //need fix this
    printf("Bloom filter load: %f\n", bfl); //need fix this
  }

  parser_delete(&parse_main);

  ll_delete(&used_badspeak);
  ll_delete(&used_oldspeak);


  bf_delete(&bf_main);
  ht_delete(&ht_main);









  return 0;
}
