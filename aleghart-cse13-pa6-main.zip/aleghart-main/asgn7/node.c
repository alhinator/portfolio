#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <inttypes.h>
#include <stdio.h>

#define DOL '$'

struct Node {
    struct Node *left;
    struct Node *right;
    uint8_t symbol;
    uint64_t frequency;
};

struct Node *node_create(uint8_t symbol, uint64_t frequency){
  struct Node *new_node = (struct Node * )malloc(sizeof(struct Node));
  if (new_node != NULL) {
    new_node->symbol = symbol;
    new_node->frequency = frequency;
  }
  return new_node;
}

void node_delete(struct Node **n){
  if (*n) {
    node_delete(&(*n)->left);
    node_delete(&(*n)->right);
    (*n)->left = NULL;
    (*n)->right = NULL;
    free(*n);
    *n = NULL;
  }

  return;
}

struct Node *node_join(struct Node *left, struct Node *right){
  struct Node *new_parent = node_create(DOL, left->frequency + right->frequency);
  new_parent->left = left;
  //printf(" setting %c Left to %c\n", new_parent->symbol, left->symbol );
  new_parent->right = right;
  return new_parent;
}

void node_print(struct Node *n){
  if (n == NULL) {
    printf("NULL\n");
    return;
  }
  printf("%c,%"PRIu64"\n", n->symbol, n->frequency);
  if (n->left) {
    printf("%c,%"PRIu64" Left Child: ", n->symbol, n->frequency);
    node_print(n->left);
  }
  if (n->right){
    printf("%c,%"PRIu64" Right Child: ", n->symbol, n->frequency);
    node_print(n->right);

  }
  //printf("\n");

  return;
}

bool node_cmp(struct Node *n, struct Node *m){
  return (n->symbol == m->symbol && n->frequency == m->frequency);
}

void node_print_sym(struct Node *n){
  printf("%c\n", n->symbol);
}
