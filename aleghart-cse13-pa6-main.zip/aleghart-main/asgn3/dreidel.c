#include "stdio.h"
#include "mtrand.h"
#include "dreidel.h"
#include <stdint.h>


const char SPINNY[] = {'G','H','N','S'};
const char *PLAYER_NAMES[8] = {"Aharon", "Batsheva", "Chanah", "David", "Ephraim", "Faige", "Gamaliel", "Hannah"};
int verbose = 0;
char spin_dreidel(void){return SPINNY[(mtrand_rand64() % 4)];}

int play_game(int n_players, int coins_per_player, int *n_rounds){
  int bank[n_players];  //initialize our bank
  for (int i = 0; i < n_players; i++){bank[i] = coins_per_player;}
  int pot = 0; //initialize our pot
  int remaining = n_players;
  for (*n_rounds = 1; *n_rounds > 0; *n_rounds += 1){ //each outer loop is a round
    //printf("round %i\n", *n_rounds);
    for(int currPlyr = 0; currPlyr < n_players ; currPlyr++){ // each inner loop is a turn
      if (bank[currPlyr] >= 0) { //checking if the bank of current player is still in the game
        char spin = spin_dreidel();
        //printf("%s's turn. hand is %i. pot is %i. rolled %c\n", PLAYER_NAMES[currPlyr], bank[currPlyr], pot, spin);
        //printf("%c\n", spin);
        switch(spin){ //we spin
          case 'G': // g - take the pot.
            bank[currPlyr] += pot;
            pot = 0;
            break;
          case 'H': // h - half the pot
            {int p = pot / 2;
            bank[currPlyr] += p;
            pot -= p;
            break;}
          case 'N': // n - nothing
            //printf("N");
            break;
          case 'S': // s - give one to the pot
            if (bank[currPlyr] > 0){
              bank[currPlyr] --;
              pot++;
            } else{
              bank[currPlyr] --;
              remaining --;
              if(verbose){
                printf("%s: Eliminated on round %i of a %i player game.\n", PLAYER_NAMES[currPlyr], *n_rounds, n_players);
              }
              if(remaining == 1){
                for(int w = 0; w < n_players ; w++){ // loop thru all players and see if they're remianing
                  if(bank[w] > -1){
                    return w;
                  }
                }
              }
              continue;
            }
            break;
        }
        //after we spin, we check if we've won
        if (bank[currPlyr] == coins_per_player * n_players && (remaining == 1)) {
          return currPlyr;
        }
      }
    }
  }
  return -1; // this is for if something went wrong and a player never wins
}
