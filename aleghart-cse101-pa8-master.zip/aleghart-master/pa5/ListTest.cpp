/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA5
* ListTest.cpp
* List ADT implementation C++ test harness
*********************************************************************************/
#include "List.h"

using namespace std;

int main(int argc, char **argv) {

  List L;
  List A;

  std::cout << L << '\n';
  //std::cout << (L == A) << '\n';

  L.insertBefore(1);
  std::cout << L << '\n';

  L.insertAfter(3);

  std::cout << L << '\n';

  //L.moveNext();
  L.insertBefore(2);

  std::cout << L << '\n';
  std::cout << (L == A) << '\n';

  std::cout << L.moveNext() << '\n';

  std::cout << "------------------" << '\n';

  L.moveBack();
  L.insertBefore(4);
  L.insertBefore(5);
  L.insertBefore(6);
  L.insertBefore(7);
  L.moveFront();
  std::cout << L << '\n';
  std::cout << L.findNext(1) << '\n';
  std::cout << L.findNext(8) << '\n';

  L.moveBack();
  std::cout << L.findPrev(1) << '\n';
  std::cout << L.findPrev(8) << '\n';

  std::cout << "---------------------------------" << '\n';


  List D;

  D.insertBefore(0);
  D.insertBefore(0);
  D.insertBefore(1);
  D.insertBefore(2);
  D.insertBefore(2);
  D.insertBefore(3);
  D.insertBefore(4);
  D.movePrev();
  D.movePrev();

  std::cout << D << '\n';
  std::cout << D.position() << '\n';
  D.cleanup();
  std::cout << D << '\n';
  std::cout << D.position() << '\n';

  std::cout << "---------------------------------" << '\n';
  //std::cout << L << '\n';
  List F = D;

  F = F.concat(L);
  std::cout << F << '\n';

  std::cout << D << '\n';
  std::cout << L << '\n';

  return 0;
}
