#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "node.h"
#include "pq.h"
#include "stack.h"
#include "defines.h"
#include "code.h"
#include "io.h"
#include "huffman.h"
#include "header.h"

#define OPTIONS "hi:o:v"

bool verbose = false;
char *infile = NULL;
char *outfile = NULL;


//for testing
void tree_print(Node *root){
  if (root) {
    tree_print(root->left);
    tree_print(root->right);
    node_print_sym(root);
  }
}

void print_help_message(){
  fprintf( stderr,
    "SYNOPSIS\n"
    "  A Huffman decoder.\n"
    "  Decompresses a file using the Huffman coding algorithm.\n\n"
    "USAGE\n"
    "  ./decode [-h] [-i infile] [-o outfile]\n\n"
    "OPTIONS\n"
    "  -h             Program usage and help.\n"
    "  -v             Print compression statistics.\n"
    "  -i infile      Input file to decompress.\n"
    "  -o outfile     Output of decompressed data.\n");
}

int main(int argc, char *argv[]) {
  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'i':
        infile = optarg;
        break;
      case 'o':
        outfile = optarg;
        break;
      case 'v':
        verbose = true;
        break;
      case 'h':
        print_help_message();
        exit(EXIT_SUCCESS);
        break;
      case '?':
        print_help_message();
        exit(EXIT_FAILURE);
    }
  }

  //printf("getopt loop finisehd!\n");

/*
// int input;
// int secondary;
// if (infile) {
//   input = open(infile, O_RDONLY);
// } else {
//   input = 0;
// }
// secondary = open("al_temp_infile.txt", O_RDWR | O_TRUNC | O_CREAT);
//
// if (input < 0 || secondary < 0) {
//   printf("Bad input filepath.\n");
//   print_help_message();
//   exit(EXIT_FAILURE);
// }
// //fd "0" is stdin for reference -------
//
// //construct our histogram -----
// uint64_t hist[ALPHABET] = {0};
// uint8_t buf;
// //uint8_t uniq_sym_1 = 0;
// while ((read_bytes(input, &buf, 1)) != 0) {
//   //printf("%c\n", buf);
//   if (secondary) {
//     write_bytes(secondary, &buf, 1);
//   }
//   //uniq_sym_1 += (hist[buf]==0);
//   hist[buf] ++;//construct our frequencies table.
//
// }
// hist[0] += (hist[0] == 0);
// hist[1] += (hist[1] == 0);
// //this ensures that at least two nodes will exist when constructing our huffman tree.
//
// //now we need to turn the table into a set of codes.
//
//
// Code table[ALPHABET]; //create the code table
//
// for (int i = 0; i < ALPHABET; i++) {
//    //printf("inting code for %"PRIu8"\n", (uint8_t)i);
//    table[i] = code_init(); // set each code to 0 so we dont get garbage values
// }
//
// struct Node *tree_root = build_tree(hist);
// //printf("------------------------\n\n\n");
// //tree_print(tree_root);
//
// build_codes(tree_root, table);
// uint8_t uniq_sym_2 = 0;
//
// for (int i = 0; i < ALPHABET; i++) {
//   if (!code_empty(&table[i])) {
//     //printf("this code is %"PRIu32" long\n", code_size(&table[i]));
//     //printf("%c %"PRIu64" ", (uint8_t)i , hist[i]);
//     //code_print(&table[i]);
//     uniq_sym_2++;
//   }
// }
// //printf("un1: %"PRIu8", un2: %"PRIu8"\n", uniq_sym_1, uniq_sym_2);
// //alright! we have a code table now.
// Header head;
// struct stat b_head;
// if (fstat(secondary, &b_head) < 0) {
//   printf("fstat failed.\n");
//   exit(EXIT_FAILURE);
// }
// //create header stuff based on instructions from pdf
// head.magic = MAGIC;
// head.permissions = b_head.st_mode;
// head.tree_size = (3 * uniq_sym_2) - 1;
// head.file_size = b_head.st_size;
// //printf("file size is: %"PRIu64"\n", head.file_size);
// //printf("file magic is: %"PRIu32"\n", head.magic);
// //get our output file set up. ----
// int output;
// if (outfile) {
//   output = open(outfile, O_WRONLY | O_CREAT);
// } else {
//   output = 1;
// }
// if (output < 0) {
//   printf("Bad output filepath.\n");
//   print_help_message();
//   exit(EXIT_FAILURE);
// }
// //--------
//
// fchmod(output, head.permissions);
//
// //this code is taken from the central scrutinizer telling people to use union.
// union {
//     uint8_t b[sizeof(Header)];
//     Header s;
// } hh;
// //end used code
// hh.s = head;
//
// // printf("%s\n", hh.b);
// //write the header
// write_bytes(output, hh.b , sizeof(Header));
// //printf("\n----------------------\n" );
// //dump the tree
// //tree_print(tree_root);
// dump_tree(output, tree_root);
//
// //printf("----\n\n");
// //write the codes.
// //first need to go to beginnning of secondary.
// lseek(secondary, 0, SEEK_SET);
// while ((read_bytes(secondary, &buf, 1)) != 0) {
//   //fprintf(stderr, "calling to write the code for %c :", buf);
//   //code_print(&table[buf]);
//   write_code(output, &table[buf]);
// }
// flush_codes(output);
*/ //this is encode.c code, it's here so that i can ref it.

  //setup our input file, and our output file.
  int input;
  int output;
  if (infile) {
    input = open(infile, O_RDONLY);
  } else {
    input = 0;
  }
  if (outfile) {
    output = open(outfile, O_RDWR | O_TRUNC | O_CREAT);
  } else {
    output = 1;
  }
  if (input < 0) {
    fprintf(stderr,"Bad input filepath.\n");
    print_help_message();
    exit(EXIT_FAILURE);
  }
  if (output < 0) {
    fprintf(stderr,"Bad output filepath.\n");
    print_help_message();
    exit(EXIT_FAILURE);
  }
  //fd "0" is stdin for reference, fd 1 is stdout -------

  //step 1: read in the header.
  Header head;
  //again, this code is someone else's
  union {
      uint8_t b[sizeof(Header)];
      Header s;
  } hh; // end used code.

  read_bytes(input, hh.b, sizeof(Header));
  head = hh.s;

  //printf("head file size is: %"PRIu64"\n", head.file_size);
  if (head.magic != MAGIC) {
    fprintf(stderr, "Invalid magic number.\n");
    exit(EXIT_FAILURE);
  }
  if (fchmod(output, head.permissions) < 0 || head.tree_size > MAX_TREE_SIZE) {
    fprintf(stderr,"Error: Unable to read header.\n");
    exit(EXIT_FAILURE);
  };
  //fprintf(stderr, "tree size is: %"PRIu16"\n", head.tree_size);
  uint8_t tree[head.tree_size];
  uint16_t cout = 0;
  uint8_t buf;
  while (cout < head.tree_size && read_bytes(input, &buf, 1)) {
    tree[cout] = buf;
    //fprintf(stderr, "buf: %"PRIu8"\n", tree[cout]);
    cout++;
    buf = 0;
  }
  int huh = lseek(input, 0, SEEK_CUR);
  //fprintf(stderr, "current filepos is: %i\n", huh );


  struct Node *tree_root = rebuild_tree(head.tree_size, tree);

  struct Node *c_node = tree_root;
  uint8_t bit; // this will be a 0 or 1, ie. check left or right child.
  uint8_t w_buf[BLOCK] = {0}; //byte buffer.
  uint16_t w_off = 0; //byte buffer offset.
  uint64_t num_decoded = 0;

  //fprintf(stderr, "w_off is: %"PRIu16" block is: %i\n", w_off, BLOCK);
  while (num_decoded < head.file_size) {
    //loops until our num decoded is the size of the Uncompressed file.
    read_bit(input, &bit); //get our direction & traverse.
    c_node = (bit == 0 ? c_node->left : c_node->right);
    //fprintf(stderr, "bit is %"PRIu8".\n", bit);
    //fprintf(stderr, "c_node:"); node_print_sym(c_node);
    if (!c_node->left && !c_node->right) {// if current node has no children
      //fprintf(stderr, "found a leafnode.\n");
      //we have reached a leaf node & want to write it's symbol to the buffer.
      w_buf[w_off] = c_node->symbol; // write symbol
      //fprintf(stderr, "%c\n", c_node->symbol);
      w_off++; num_decoded++; //inc our counters
      if (w_off >= BLOCK) { //if we have filled up the buffer
        //fprintf(stderr, "buffer full. decoded: %"PRIu64", w_off: %"PRIu16"\n", num_decoded, w_off);
        //fprintf(stderr, "%s\n", w_buf);
        write_bytes(output, w_buf, w_off); // write buffer to file
        //clear buffer
        w_off = 0;
        for (size_t i = 0; i < BLOCK; i++) {
          w_buf[i] = 0;
        }
      }
      //reset node to beginning of the tree.
      c_node = tree_root;
    }



  }

  // write the remainder of the buffer to file since it may not line up nicely.
  //w_buf[w_off] = '\0';
  //w_off++;
  write_bytes(output, w_buf, w_off);

  //statistics
  struct stat in_stat;
  if (fstat(input, &in_stat) < 0) {
    fprintf(stderr, "fstat for input failed.\n");
    exit(EXIT_FAILURE);
  }
  struct stat out_stat;
  if (fstat(output, &out_stat) < 0) {
    fprintf(stderr, "fstat for output failed.\n");
    exit(EXIT_FAILURE);
  }
  if (verbose) {
    fprintf(stderr,"Compressed file size: %"PRIu64" bytes\n", in_stat.st_size);
    fprintf(stderr,"Decompressed file size: %"PRIu64" bytes\n", out_stat.st_size);
    float saving = 100.0 * (1.0 - ((float)in_stat.st_size)/(float)out_stat.st_size);
    fprintf(stderr,"Space saving: %0.2f%%\n", saving);
  }

  //need freeing and closing shit here.
  node_delete(&tree_root);

  close(input);
  close(output);



  return 0;
}
