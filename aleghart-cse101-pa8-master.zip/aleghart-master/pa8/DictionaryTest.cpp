/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA8
* DictionaryTest.cpp
* Dictionary ADT test harness
*********************************************************************************/

#include "Dictionary.h"
#include <assert.h>

int main(int argc, char **argv) {

  Dictionary B = Dictionary();
  Dictionary D = B;

  // D.setValue("d", 1);
  // D.setValue("b", 5);
  // D.setValue("a", 10);
  // D.setValue("c", 15);
  // D.setValue("f", 20);
  // D.setValue("e", 25);
  // D.setValue("g", 30);


//  std::cout << D.pre_string() << '\n';
  //std::cout << D << '\n';

  //std::cout << D.size() << '\n';
  //
  // std::cout << D.contains("e") << '\n';
  // std::cout << D.contains("h") << '\n';
  //
  // D.remove("d");
  //
  // assert(D.getValue("e") == valType(5));

  //std::cout << "before clear" << '\n';
  //D.clear();
  D.setValue("insignia", 100);
  D.setValue("feather", 20);

  D.setValue("heat", 15);
  std::cout << D.pre_string() << '\n';

  D.setValue("eradicate", 10);
  D.setValue("bolstering", 5);
  D.setValue("abjuration", 1);

  std::cout << D.pre_string() << '\n';


  std::string ideal1 = "b\na\nf (RED)\ne\nh\ni (RED)\n";
  std::string ideal2 =
      "heat\neradicate (RED)\nbolstering\nabjuration (RED)\nfeather\ninsignia\n";

  std::string str = D.pre_string();
  std::cout << str << '\n';

  assert(ideal2 == str);
  // while (D.hasCurrent()) {
  //   std::cout << D.currentKey() << " : " << D.currentVal() << '\n';
  //   D.next();
  // }

  D.clear();

  std::cout << D.pre_string() << '\n';




  return 0;
}
