// clang-format off
#include <stdio.h>
#include <gmp.h>
//clang-format on
#include "unistd.h"
#include "stdlib.h"
#include <stdbool.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>
#include <inttypes.h>

#include "rsa.h"
#include "numtheory.h"
#include "randstate.h"

#define OPTIONS "b:i:n:d:s:vh"

uint64_t bits = 1024;
uint64_t iters = 50;
char *pbfile;
char *pvfile;
uint64_t seed = 0;
bool verbose = false;

void print_help_message(){
  fprintf( stderr,
"Usage: ./keygen [options]\n"
" ./keygen generates a public / private key pair, placing the keys into the public and private\n key files as specified below. The keys have a modulus (n) whose length is specified in\n the program options.\n"
"    -s <seed>    : Use <seed> as the random number seed. Default: time()\n"
"    -b <bits>    : Public modulus n must have at least <bits> bits. Default: 1024\n"
"    -i <iters>   : Run <iters> Miller-Rabin iterations for primality testing. Default: 50\n"
"    -n <pbfile>  : Public key file is <pbfile>. Default: rsa.pub\n"
"    -d <pvfile>  : Private key file is <pvfile>. Default: rsa.priv\n"
"    -v           : Enable verbose output.\n"
"    -h           : Display program synopsis and usage.\n");
}

int main(int argc, char **argv) {

  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'b':
        bits = atoi(optarg);
        if (bits >= 50 && bits <= 4096){   // copied from my last program
          break;
        }else{
          print_help_message();
          exit(EXIT_FAILURE);
        }
      case 'i':
        iters = atoi(optarg);
        if (iters > 0 && iters <= 9999999999){   // copied from my last program
          break;
        }else{
          print_help_message();
          exit(EXIT_FAILURE);
        }
      case 'n':
        pbfile = optarg;
        break;
      case 'd':
        pvfile = optarg;
        break;
      case 's':
        //set the seed
        seed = strtoul(optarg, NULL, 10);
        if (seed >= 0 && seed <= 9999999999){   // copied from my last program
          break;
        }else{
          print_help_message();
          exit(EXIT_FAILURE);
        }
        break;
      case 'v':
        verbose = true;
        break;
      case 'h':
        print_help_message();
        exit(EXIT_SUCCESS);
        break;
      case '?':
      print_help_message();
        exit(EXIT_FAILURE);
    }
  }
  //------------------------------------------------ 2, 3 file stuff
  //printf("finished getopt loop! hi\n");
  FILE *pubkey;
  FILE *privkey;
  if (pbfile == NULL) {
    pubkey = fopen("rsa.pub", "w");
  }else{
    pubkey = fopen(pbfile, "w");
  }
  if (pvfile == NULL) {
    privkey = fopen("rsa.priv", "w");
  }else{
    privkey = fopen(pvfile, "w");
  }
  if (pubkey == NULL || privkey == NULL) {
    fprintf(stderr, "Incorrect filepath for private and public key.\n");
    exit(EXIT_FAILURE);
  }
  fchmod(fileno(pubkey), 0600);
  fchmod(fileno(privkey), 0600);
  //------------------------------------------------
  //printf("finished opening files! hi\n");


  //------------------------------------------------ 4 init randstates
  if (seed == 0) {
    seed = time(NULL); // this will only occur if seed was not set via getopt
  }
  randstate_init(seed);
  //------------------------------------------------
  //printf("finished init randstate! hi\n");

  //------------------------------------------------ 5 make pub and priv keys


  mpz_t p, q, n, e, d; mpz_inits(p, q, n, e, d, NULL);
  rsa_make_pub(p, q, n, e, bits, iters);
  rsa_make_priv(d, e, p, q);
  //gmp_printf("thw private key n and d are: %Zx \n %Zx", n, d);

  //------------------------------------------------
  //printf("finished generate pub and priv keys! hi\n");

  //------------------------------------------------ 6, 7 get current user's name as a string & convert
  char *unameSTR;
  mpz_t uname; mpz_init(uname);
  unameSTR = getenv("USER");
  mpz_set_str(uname, unameSTR, 62);
  mpz_t sign; mpz_init(sign);
  rsa_sign(sign, uname, d, n);

  //printf("finisehd get uname! hi \n");

  //------------------------------------------------ 8 write pub and priv keys
  //write to files
  rsa_write_pub(n, e, sign, unameSTR, pubkey);
  rsa_write_priv(n, d, privkey);
  //printf("finished write to files! hi \n");
  //------------------------------------------------ 9 print outputs if verbose
  /*If verbose output is enabled print the following to standard error (stderr), each with a trailing
newline, in order:
(a) username
(b) the signature s
(c) the first large prime p
(d) the second large prime q
(e) the public modulus n
(f ) the public exponent e
(g) the private key d

All of the mpz_t values should be printed with information about the number of bits that constitute
them, along with their respective values in decimal. See the reference key generator program for
an example.
*/
  if (verbose) {
    fprintf(stderr, "username: %s\n", unameSTR);
    gmp_fprintf(stderr, "user signature (%zu bits): %Zd\n", mpz_sizeinbase(sign, 2), sign);
    gmp_fprintf(stderr, "p (%zu bits): %Zd\n", mpz_sizeinbase(p, 2), p);
    gmp_fprintf(stderr, "q (%zu bits): %Zd\n", mpz_sizeinbase(q, 2), q);
    gmp_fprintf(stderr, "n - modulus (%zu bits): %Zd\n", mpz_sizeinbase(n, 2), n);
    gmp_fprintf(stderr, "e - public exponent (%zu bits): %Zd\n", mpz_sizeinbase(e, 2), e);
    gmp_fprintf(stderr, "d - private exponent (%zu bits): %Zd\n", mpz_sizeinbase(d, 2), d);
  }

 //------------------------------------------------ 10 close files and free
 fclose(pubkey);
 fclose(privkey);
 randstate_clear();
 mpz_clears(p, q, n, e, d, sign, uname, NULL);
 return EXIT_SUCCESS;
}
