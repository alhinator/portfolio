/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA5
* Shuffle.cpp
* Uses the C++ list implementation to perform riffle shuffle.
*********************************************************************************/
#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

#include "List.h"

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>

#include <iostream>
#include <iomanip>

int size;


void shuffle(List&D){
  List B;
  D.moveFront();
  int max = D.length()/2;
  //construct other deck based on D --> this should work for both even and odd length lists.
  for (int count = 0; count < max; count++) {
    B.insertBefore(D.peekNext());
    D.eraseAfter();
  }
  // std::cout << B << '\n';
  // std::cout << D << '\n';
  // std::cout << "-----" << '\n';
  B.moveFront();
  D.moveFront();
  while (B.length() > 0) { //now just slap the list of B in in alternating spots
    D.moveNext();
    D.insertBefore(B.peekNext());
    B.eraseAfter();
  }
  //std::cout << D << '\n';

}



int main(int argc, char **argv) {
  if (argc != 2) {
    std::cerr << "Shuffle.cpp: Incorrect number of inputs." << '\n';
    exit(EXIT_FAILURE);
  }

//step 1: grab deck size.
  size = atoi(argv[1]);

//step 2: print header
std::cout << "deck size        shuffle count" << '\n';
std::cout << "------------------------------" << '\n';

  List L;
  List S; //we never shuffle L, we use this instead.
  L.insertBefore(0); //it'll always be at least size 1

  for (int i = 1; i <= size; i++) { //we will repeat from size 1 to i.
    S = L;
    shuffle(S);
    int shuffles = 1;
    while(!(S == L)){
     shuffle(S);
     shuffles++;
    }
    std::cout << " ";
    std::cout.width(16);
    std::cout << std::left << i << " ";
    std::cout.width(16);
    std::cout << std::left << shuffles;
    std::cout << '\n';

    L.insertBefore(i);




  }



  return 0;
}
