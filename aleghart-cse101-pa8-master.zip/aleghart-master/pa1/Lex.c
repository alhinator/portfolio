/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA1
* Lex.c
* Text file alphebetizer 
*********************************************************************************/
#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

#include "List.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>

char *infile;
char *outfile;

int main(int argc, char **argv) {
  if (argc != 3) {
    //occurs when the amount of runtime arguments is not two.
    fprintf(stderr, "Incorrect number of inputs.\n");
    exit(EXIT_FAILURE);
  }
//step 1: parse infile and outfile
  infile = argv[1];
  outfile = argv[2];
//open and validate files
  FILE *input;
  input = fopen(infile, "r");
  if (input == NULL) {
    fprintf(stderr, "Bad filepath for input file.\n");
    exit(EXIT_FAILURE);
  }
  FILE *output;
  output = fopen(outfile, "w");
  if (output == NULL) {
    fprintf(stderr, "Bad filepath for output file.\n");
    exit(EXIT_FAILURE);
  }
// both should now be open :)
//fprintf(stderr, "finished opening both files.\n");

//next: count lines of infile & create an array of that length.
//we do this by fgetc'ing every char, if i find a better way to do this i'll figure it out
  char i;
  int lines = 0; // this needs to start at 0 as every line should be \n-terminated.
  while ((i=fgetc(input)) != EOF) {
    if (i== '\n') {
      lines++;
    }
  }
  //fprintf(stderr, "lines: %i\n", lines);

  char **unsorted = malloc(lines * sizeof(char*)); //malloc the outer array
  fseek(input, 0, SEEK_SET); // move the cursor back to the start of the file
  size_t lineSize = 0;
  char *lineBuffer = NULL;
  int curr = 0;
  while (getline(&lineBuffer, &lineSize, input) != -1) { //getline every line
    unsorted[curr] = (char*)malloc(lineSize + 1); //malloc the pointer of the inner array
    strcpy(unsorted[curr], lineBuffer);
    //unsorted[curr][strcspn(unsorted[curr], "\n")] = 0; //remove trailing returns (DONT NEED THIS.)
    //fprintf(stderr, "%s", unsorted[curr]);
    //fprintf(stderr, "\n");
    curr++;
  }
  // for (size_t i = 0; i < lines; i++) {
  //   fprintf(stderr, "%s\n", unsorted[i]);
  // }
  //initialize our list.
  List L = newList();
  //so what we want to do with this is insert our zeroth index, and set the cursor for ease of use.

  append(L, 0);
  for (int uar = 1; uar < lines; uar++) {
    moveFront(L);
    //fprintf(stderr, "hello?\n");

    //the outer loop loops through each index (uar) of the unsorted array.
    // during each outer loop, we need to insert the position of that string into the integer list.
    //we need to reset the cursor to the beginning of the list during each outer loop.
    char* str1 = unsorted[uar];
    bool found = false;
    while (index(L) >= 0 && !found) { //while cursor is not undefined or we have not placed the index
      char* str2 = unsorted[get(L)];
      //fprintf(stderr, " wahh %s    to %s\n", str1, str2);
      if (strcmp(str1, str2) > 0) {
        //fprintf(stderr, "str1 is larger\n" );
        moveNext(L);
        if (index(L) == -1) { //we have gone past
          append(L, uar);
          found = true;
          continue;
        }
      } else {
        insertBefore(L, uar);
        found = true;
        continue;
      }

    }
    // the inner loop takes the string, str1, at the position unsorted[uar].
      //then, it compares it against the string, str2, located at unsorted[get()].
      //if str1 is lexically after str2    (strcmp returns > 0), we need to look at a new str2
        //if there is no new str2, we need to append.
      //else if strcmp returns <= 0, we insert str1's index before str2's index in the list.
        //and exit back to a new iteration of the outer loop

    //i could probably clean this up so it's closer to an actual insertion sort, but my head is killing me.
  }

  ////////////////////////////////
  //printList(stderr, L);
  //now we print the list.
  moveFront(L);

  while (index(L) != -1) {
    fprintf(output, "%s\n", unsorted[get(L)]);
    //fprintf(stderr, " hello? );
     //print the string in the index of the unsorted array, in the order of the nodes in the list.
     moveNext(L); //increase the cursor.
  }

  fclose(output);
  fclose(input);
  freeList(&L);
  for (size_t i = 0; i < lines; i++) {
    free(unsorted[i]);
  }
  free(unsorted);
  free(lineBuffer);
  return EXIT_SUCCESS;
}
