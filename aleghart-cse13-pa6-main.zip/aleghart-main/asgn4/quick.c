#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include <stdint.h>
#include "stdbool.h"
#include <inttypes.h>

#include "shell.h"

#define SMALL 8

void quick_sort(Stats *stats, uint32_t *arr, uint32_t n_elements){
  if(n_elements < SMALL){
    //printf("too small, calling shell_sort\n");
    shell_sort(stats, arr, n_elements);
    return;
  }
  uint32_t pivot = (arr[0] + arr[n_elements/2] + arr[n_elements-1])/3; //assign our pivot
  //printf("pivot is %u, num elements is %u\n", pivot, n_elements);
  //I AM GOING TO PUT NUMBERS EQUAL TO THE PIVOT IN THE RIGHT SIDE
  uint32_t *left = (uint32_t*) malloc(sizeof(uint32_t) * n_elements); //allocate left array
  uint32_t *right = (uint32_t*) malloc(sizeof(uint32_t) * n_elements);//allocate right array
  uint32_t lc = 0;//length of left (smaller than pivot) array
  uint32_t rc = 0;//length of right (equal or greater than pivot) array
  for (uint32_t i = 0; i < n_elements; i++) {   //first for loop puts each number into the left or right array
    if (cmp(stats, arr[i], pivot) == -1) { //depending on if it is smaller or larger than the pivot
      left[lc] = move(stats, arr[i]);
      lc++;
      //printf("added %u to left array\n", arr[i]);
    }
    else{
      right[rc] = move(stats, arr[i]);
      rc++;
      //printf("added %u to right array\n", arr[i]);
    }
  }
  //printf("calling sort on left\n");
  quick_sort(stats, left, lc); //recursively call each one, dont need an assignment cause theyre pointer
  //printf("returned from left, calling in right\n");
  quick_sort(stats, right, rc);
  //printf("returned from right\n");
  for (uint32_t i = 0; i < lc; i++) { // now we put them back into the first array
    arr[i] = move(stats, left[i]);
  }
  for (uint32_t i = 0; i < rc; i++) { //and put the right side back in
    arr[lc + i] = move(stats, right[i]);
  }
  free(left);
  free(right);
  return;

}
