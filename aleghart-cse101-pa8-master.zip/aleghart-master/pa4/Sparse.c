/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA4
* Sparse.c
* Uses the Matrix implementation to read in two matrices and perform various mathematical operations on them.
*********************************************************************************/
#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

#include "List.h"
#include "Matrix.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>


char *infile;
char *outfile;

int main(int argc, char **argv) {
  if (argc != 3) {
    //occurs when the amount of runtime arguments is not two.
    fprintf(stderr, "Incorrect number of inputs.\n");
    exit(EXIT_FAILURE);
  }
//step 1: parse infile and outfile
  infile = argv[1];
  outfile = argv[2];
//open and validate files
  FILE *input;
  input = fopen(infile, "r");
  if (input == NULL) {
    fprintf(stderr, "Bad filepath for input file.\n");
    exit(EXIT_FAILURE);
  }
  FILE *output;
  output = fopen(outfile, "w");
  if (output == NULL) {
    fprintf(stderr, "Bad filepath for output file.\n");
    exit(EXIT_FAILURE);
  }
// both should now be open :)
//fprintf(stderr, "finished opening both files.\n");

char* line = NULL;
size_t len = 100;
getline(&line, &len, input);

//first, we take the three numbers from the first line. These numbers are:
int NxN = atoi(strtok(line, " "));
int entriesA = atoi(strtok(NULL, " "));
int entriesB = atoi(strtok(NULL, " "));
//then, construct our empty matrices.
Matrix A = newMatrix(NxN);
Matrix B = newMatrix(NxN);
getline(&line, &len, input); //skip the second line.

for (int i = 0; i < entriesA; i++) {
  getline(&line, &len, input);
  int row = atoi(strtok(line, " "));
  int col = atoi(strtok(NULL, " "));
  double val = atof(strtok(NULL, " "));
  changeEntry(A, row, col, val);
}
getline(&line, &len, input); //skip the separator line.

for (int i = 0; i < entriesB; i++) {
  getline(&line, &len, input);
  int row = atoi(strtok(line, " "));
  int col = atoi(strtok(NULL, " "));
  double val = atof(strtok(NULL, " "));
  changeEntry(B, row, col, val);
}

fprintf(output, "A has %i non-zero entries:\n", NNZ(A));
printMatrix(output, A);
fprintf(output, "\nB has %i non-zero entries:\n", NNZ(B));
printMatrix(output, B);

fprintf(output, "\n(1.5)*A =\n");
Matrix M = scalarMult(1.5, A);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nA+B =\n");
 M = sum(A, B);
printMatrix(output, M);
freeMatrix(&M);

fprintf(output, "\nA+A =\n");
 M = sum(A, A);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nB-A =\n");
 M = diff(B, A);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nA-A =\n");
 M = diff(A, A);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nTranspose(A) =\n");
 M = transpose(A);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nA*B =\n");
 M = product(A, B);
printMatrix(output, M);
freeMatrix(&M);


fprintf(output, "\nB*B =\n");
 M = product(B, B);
printMatrix(output, M);


freeMatrix(&A);
freeMatrix(&B);
freeMatrix(&M);
fclose(input);
fclose(output);
free(line);


  return 0;
}
