/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* ListTest.cpp
* List ADT Long implementation C++ test harness
*********************************************************************************/
#include "List.h"

using namespace std;

int main(int argc, char **argv) {

  List L;

  return 0;
}
