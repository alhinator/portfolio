// clang-format off
#include <stdio.h>
#include <gmp.h>
//clang-format on
#include "stdlib.h"
#include "unistd.h"
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>


#include "numtheory.h"
#include "randstate.h"
#include "rsa.h"

#define OPTIONS "i:o:n:vh"

char *infile;
char *outfile;
char *keyfile;
bool verbose = false;

void print_help_message() {
  fprintf(
      stderr,
      "Usage: ./decrypt [options]\n"
      "  ./decrypt decrypts an input file using the specified private key "
      "file,\n  writing the result to the specified output file.\n"
      "    -i <infile> : Read input from <infile>. Default: standard input.\n"
      "    -o <outfile>: Write output to <outfile>. Default: standard output.\n"
      "    -n <keyfile>: Private key is in <keyfile>. Default: rsa.priv\n"
      "    -v          : Enable verbose output.\n"
      "    -h          : Display program synopsis and usage.\n");
}

int main(int argc, char **argv) {

  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1) { // step 1: parse getopt
    switch (opt) {
    case 'i':
      infile = optarg;
      break;
    case 'o':
      outfile = optarg;
      break;
    case 'n':
      keyfile = optarg;
      break;
    case 'v':
      verbose = true;
      break;
    case 'h':
      print_help_message();
      exit(EXIT_SUCCESS);
      break;
    case '?':
      print_help_message();
      exit(EXIT_FAILURE);
    }
  }

  // step 2: open the private key with fopen.
  FILE *privkey;
  if (keyfile == NULL) {
    privkey = fopen("rsa.priv", "r");
  } else {
    privkey = fopen(keyfile, "r");
  }
  if (privkey == NULL) {
    fprintf(stderr, "Incorrect filepath for private key.\n");
    exit(EXIT_FAILURE);
  }
  // read priv key.
  mpz_t n, d;
  mpz_inits(n, d, NULL);

  rsa_read_priv(n, d, privkey);
  // if verbose output is enabled....
  if (verbose) {
    gmp_fprintf(stderr, "n - modulus (%zu bits): %Zd\n", mpz_sizeinbase(n, 2),
                n);
    gmp_fprintf(stderr, "d - private exponent (%zu bits): %Zd\n",
                mpz_sizeinbase(d, 2), d);
  }

  // decrypt the file.
  // need to account for stdin and stdout if no file is specified.
  FILE *input;
  FILE *output;
  if (infile == NULL) {
    input = stdin;
  } else {
    input = fopen(infile, "r");
  }
  if (outfile == NULL) {
    output = stdout;
  } else {
    output = fopen(outfile, "w");
  }
  if (input == NULL || output == NULL) {
    fprintf(stderr, "Incorrect filepath for infile or outfile.\n");
    exit(EXIT_FAILURE);
  }
  // there we go. now we can encrypt.
  rsa_decrypt_file(input, output, n, d);

  // close, clear, and free.
  fclose(input);
  fclose(output);
  fclose(privkey);
  mpz_clears(n, d, NULL);

  return EXIT_SUCCESS;
}
