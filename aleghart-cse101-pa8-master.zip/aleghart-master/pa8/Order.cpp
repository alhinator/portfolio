/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA8
* Order.cpp
* Prints two sequences of a read-in Dictionary: alphabetical, and then pre-order tree walk.
*********************************************************************************/

#include "Dictionary.h"

#include <iostream>
#include <fstream>
#include <iomanip>

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
//using namespace std;

#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

int main(int argc, char **argv) {
  if (argc != 3) {
    std::cerr << "Order.cpp: Incorrect number of inputs." << '\n';
    exit(EXIT_FAILURE);
  }

  //step 1: parse infile and outfile
    // char* infile = argv[1];
    // char* outfile = argv[2];
  //open and validate files
    std::ifstream input;
    input.open(argv[1], std::ios::in);
    // if (input.is_open()) {
    //   std::cout << "input opened" << '\n';
    // }
    if (input.fail()) {
      std::cerr << "Order.cpp: Bad filepath for input file." << '\n';
      exit(EXIT_FAILURE);
    }
    std::ofstream output;
    output.open(argv[2], std::ios::out | std::ios::trunc);
    if (output.fail()) {
      std::cerr << "Order.cpp: Bad filepath for output file." << '\n';
      exit(EXIT_FAILURE);
    }
  // both should now be open :)
  //fprintf(stderr, "finished opening both files.\n");

  Dictionary D;

  std::string line;
  valType val = 1;

  while (std::getline(input, line)) {
    D.setValue(line, val);
    val++;
  }
//  std::cerr << D.size() << '\n';
  D.begin();
  while (D.hasCurrent()) {
    output << D.currentKey() << " : " << D.currentVal() << '\n';
    D.next();
  }

  output << '\n' << D.pre_string() << '\n';

  input.close();
  output.close();


  //std::cerr << "finished" << '\n';

  return 0;
}
