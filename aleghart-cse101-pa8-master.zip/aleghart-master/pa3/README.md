
`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA3
* README.md
* Readme file

*********************************************************************************`

### Included Files:

*List.c* contains an implementation of a doubly-linked integer list and various access, manipulation, and miscellaneous operations.

*List.h* provides an interface for external files to interact with *List.c*


*Graph.c* contains an implementation of a vertex-based graph ADT utilizing the List ADT. This has been updated from PA2 to now include the ability to copy and transpose graphs. Note: the time variable is used as an input/return parameter in visit().

*Graph.h* provides an interface for external files to interact with *Graph.c*

*GraphTest.c* contains tests for the functions contained within *Graph.c*

*FindComponents.c* uses the Graph implementation to construct a directed graph from a text file, then determine the strongly connected components of the graph.

*Makefile* provides various options for compiling the *.c* and *.h* files.
