// clang-format off
#include <stdio.h>
#include <gmp.h>
//clang-format on
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#include "numtheory.h"
#include "randstate.h"

void my_lcm(mpz_t rop, mpz_t p, mpz_t q){
  //printf("in my lcm\n");
  mpz_t num , denom; mpz_inits(num, denom, NULL);
  mpz_mul(num, p, q);
  mpz_abs(num, num);
  gcd(denom, p, q);
  mpz_div(rop, num, denom);
  mpz_clears(num, denom, NULL);
  return;
}

void my_make_coprime(mpz_t rop, mpz_t cmp, uint64_t nbits){
  //printf("in my_make_coprime\n");
  mpz_t gcd_result; mpz_init(gcd_result);
  do {
    mpz_urandomb(rop, state, nbits);
    gcd(gcd_result, rop, cmp);
  } while(mpz_cmp_ui(gcd_result, 1) != 0);
  mpz_clear(gcd_result);
  return;
}

void rsa_make_pub(mpz_t p, mpz_t q, mpz_t n, mpz_t e, uint64_t nbits, uint64_t iters){
  //printf("in make pub\n");
  //init all our temp mpz_t vars
  mpz_t pm1, qm1, lambda; mpz_inits(pm1, qm1, lambda, NULL);

  // set lengths for each prime
  uint64_t lo = nbits/4;
  uint64_t hi = 3*lo;
  uint64_t p_len = (random() % (hi - lo)) + lo;
  uint64_t q_len = nbits - p_len;

  // make 2 primes
  make_prime(p, p_len, iters);
  make_prime(q, q_len, iters);

  //compute n
  mpz_mul(n, p, q);

  //compute λ(n)
  mpz_sub_ui(pm1, p, 1);
  mpz_sub_ui(qm1, q, 1);
  my_lcm(lambda, pm1, qm1);
  //printf("finished compute lambda\n");

  //generate e
  my_make_coprime(e, lambda, nbits);
  //printf("finished make coprime\n");

  //i think that's it?
  mpz_clears(pm1, qm1, lambda, NULL);
  return;

}

void rsa_write_pub(mpz_t n, mpz_t e, mpz_t s, char username[], FILE *pbfile){
  if (pbfile == NULL) {
    fprintf(stderr, "Unable to write to pbfile.\n");
    return;
  }
  gmp_fprintf(pbfile, "%Zx\n%Zx\n%Zx\n%s\n", n, e, s, username); //order: n (Z) e (Z) s (Z) username (s)
  return;
}

void rsa_read_pub(mpz_t n, mpz_t e, mpz_t s, char username[], FILE *pbfile){
  if (pbfile == NULL) {
    fprintf(stderr, "Unable to read pbfile.\n");
    return;
  }
  gmp_fscanf(pbfile, "%Zx %Zx %Zx %s", n, e, s, username);
  return;
}

void rsa_make_priv(mpz_t d, mpz_t e, mpz_t p, mpz_t q){
  //printf("in make priv\n");
  mpz_t rop, lambda, pm1, qm1; mpz_inits(rop, lambda, pm1, qm1, NULL);
  //compute λ(n)
  mpz_sub_ui(pm1, p, 1);
  mpz_sub_ui(qm1, q, 1);
  my_lcm(lambda, pm1, qm1);


  mod_inverse(rop, e, lambda);
  mpz_set(d, rop);
  //gmp_printf(" (inside make priv - d is ) \n%Zx\n", d);

  mpz_clears(rop, lambda, pm1, qm1, NULL);
  return;
}

void rsa_write_priv(mpz_t n, mpz_t d, FILE *pvfile){
  if (pvfile == NULL) {
    fprintf(stderr, "Unable to write to pvfile.\n");
    return;
  }
  gmp_fprintf(pvfile, "%Zx\n%Zx\n", n, d);
  return;
}

void rsa_read_priv(mpz_t n, mpz_t d, FILE *pvfile){
  if (pvfile == NULL) {
    fprintf(stderr, "Unable to read pvfile.\n");
    return;
  }
  gmp_fscanf(pvfile, "%Zx %Zx", n, d);
  return;
}

void rsa_encrypt(mpz_t c, mpz_t m, mpz_t e, mpz_t n){
  pow_mod(c, m, e, n);
  return;
}

void rsa_encrypt_file(FILE *infile, FILE *outfile, mpz_t n, mpz_t e){
  //step 1: calculate k
  uint64_t k = (mpz_sizeinbase(n, 2)) / 8;
  //step 2: dynamically allocate an array that can hold k bytes.
  uint8_t *arr = (uint8_t*) malloc(k);
  if (arr == NULL) {
    fprintf(stderr, "Memory for file encrypt not allocated.\n");
    return;
  } else{
    //step 3: set the zeroeth byte to 0xFF.
    arr[0] = 0xFF;
    uint64_t j;
    mpz_t c, m; mpz_inits(c, m, NULL);
    while( (j = fread(arr+1, sizeof(uint8_t), k-1, infile)) > 0){ //4. while there are still unprocessed bytes

      mpz_import(m, j+1, 1, sizeof(arr[0]), 1, 0, arr); //
      rsa_encrypt(c, m, e, n);
      gmp_fprintf(outfile, "%Zx\n", c);
      for (size_t i = 0; i < k; i++) {
        arr[i] = 0;
      }
      arr[0] = 0xFF;
    }

    mpz_clears(c, m, NULL);
    free(arr);
  }
  return;
}

void rsa_decrypt(mpz_t m, mpz_t c, mpz_t d, mpz_t n){
  pow_mod(m, c, d, n);
  return;
}

void rsa_decrypt_file(FILE *infile, FILE *outfile, mpz_t n, mpz_t d){
  //step 1: calculate k
  uint64_t k = (mpz_sizeinbase(n, 2)) / 8;
  //step 2: dynamically allocate an array that can hold k bytes.
  uint8_t *arr = (uint8_t*) malloc(k);
  if (arr == NULL) {
    fprintf(stderr, "Memory for file decrypt not allocated.\n");
    return;
  } else{
    mpz_t c, m; mpz_inits(c, m, NULL);
    uint64_t j;
    while (gmp_fscanf(infile, "%Zx", c) > 0) {
      rsa_decrypt(m, c, d, n);
      mpz_export(arr, &j, 1, sizeof(arr[0]), 1, 0, m);
      fwrite(arr+1, sizeof(arr[0]), j-1, outfile);
    }
    mpz_clears(c, m, NULL);
    free(arr);
  }
}


void rsa_sign(mpz_t s, mpz_t m, mpz_t d, mpz_t n){
  pow_mod(s, m, d, n);
  return;
}

bool rsa_verify(mpz_t m, mpz_t s, mpz_t e, mpz_t n){
  mpz_t t; mpz_init(t);
  pow_mod(t, s, e, n);
  if (mpz_cmp(t, m) == 0) {
    mpz_clear(t);
    return true;
  }
  mpz_clear(t);
  return false;
}
