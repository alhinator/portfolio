// clang-format off
#include <stdio.h>
#include <gmp.h>
//clang-format on
#include "stdlib.h"
#include "unistd.h"
#include <inttypes.h>
#include <limits.h>
#include <stdbool.h>
#include <stdint.h>
#include <sys/stat.h>
#include <time.h>

#include "numtheory.h"
#include "randstate.h"
#include "rsa.h"

#define OPTIONS "i:o:n:vh"

char *infile;
char *outfile;
char *keyfile;
bool verbose = false;

// my name is gustavo, but you can call me sus.
// another comment to make git run tests again :)

void print_help_message() {
  fprintf(
      stderr,
      "Usage: ./encrypt [options]\n"
      "  ./encrypt encrypts an input file using the specified public key "
      "file,\n  writing the result to the specified output file.\n"
      "    -i <infile> : Read input from <infile>. Default: standard input.\n"
      "    -o <outfile>: Write output to <outfile>. Default: standard output.\n"
      "    -n <keyfile>: Public key is in <keyfile>. Default: rsa.pub\n"
      "    -v          : Enable verbose output.\n"
      "    -h          : Display program synopsis and usage.\n");
}

int main(int argc, char **argv) {

  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1) { // step 1: parse getopt
    switch (opt) {
    case 'i':
      infile = optarg;
      break;
    case 'o':
      outfile = optarg;
      break;
    case 'n':
      keyfile = optarg;
      break;
    case 'v':
      verbose = true;
      break;
    case 'h':
      print_help_message();
      exit(EXIT_SUCCESS);
      break;
    case '?':
      print_help_message();
      exit(EXIT_FAILURE);
    }
  }

  // step 2: open the public key with fopen.
  FILE *pubkey;
  if (keyfile == NULL) {
    pubkey = fopen("rsa.pub", "r");
  } else {
    pubkey = fopen(keyfile, "r");
  }
  if (pubkey == NULL) {
    fprintf(stderr, "Incorrect filepath for public key.\n");
    exit(EXIT_FAILURE);
  }
  // read pub key.
  mpz_t n, e, sign;
  mpz_inits(n, e, sign, NULL);
  char unameSTR[LOGIN_NAME_MAX];
  rsa_read_pub(n, e, sign, unameSTR, pubkey);
  // if verbose output is enabled....
  if (verbose) {
    fprintf(stderr, "username: %s\n", unameSTR);
    gmp_fprintf(stderr, "user signature (%zu bits): %Zd\n",
                mpz_sizeinbase(sign, 2), sign);
    gmp_fprintf(stderr, "n - modulus (%zu bits): %Zd\n", mpz_sizeinbase(n, 2),
                n);
    gmp_fprintf(stderr, "e - public exponent (%zu bits): %Zd\n",
                mpz_sizeinbase(e, 2), e);
  }

  // convert uname that was read in to an mpz_t
  mpz_t uname;
  mpz_init(uname);
  mpz_set_str(uname, unameSTR, 62);
  if (rsa_verify(uname, sign, e, n) == false) {
    fprintf(stderr, "Signature could not be verified.\n");
    exit(EXIT_FAILURE);
  }

  // encrypt the file.
  // need to account for stdin and stdout if no file is specified.
  FILE *input;
  FILE *output;
  if (infile == NULL) {
    input = stdin;
  } else {
    input = fopen(infile, "r");
  }
  if (outfile == NULL) {
    output = stdout;
  } else {
    output = fopen(outfile, "w");
  }
  if (input == NULL || output == NULL) {
    fprintf(stderr, "Incorrect filepath for infile or outfile.\n");
    exit(EXIT_FAILURE);
  }
  // there we go. now we can encrypt.
  rsa_encrypt_file(input, output, n, e);

  // close, clear, and free.
  fclose(input);
  fclose(output);
  fclose(pubkey);
  mpz_clears(n, e, sign, uname, NULL);

  return EXIT_SUCCESS;
}
