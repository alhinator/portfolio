`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA7
* README.md
* Readme file

*********************************************************************************`

### Included Files:

*Dictionary.cpp* contains an implementation of a Binary Search Tree that contains indexes of key:value pairs, using a doubly-linked list as the model.

*Dictionary.h* provides an interface for external files to interact with *Dictionary.cpp*

*DictionaryTest.cpp* contains tests for the functions contained within *Dictionary.cpp*

*Order.cpp* uses the Dictionary implementation to read in a file of words, and place them into a BST, then print the sorted words in two different formats.

*Makefile* provides various options for compiling the *.cpp* and *.h* files.
