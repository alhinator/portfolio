# PURPOSE
This program uses the files *play-dreidel.c* and *dreidel.c* to simulate a single game of dreidel, given certain inputs via command line argument.

The game is simulated randomly using a Mersenne Twister, provided by the files *mtrand.c* and *mtrand.h*.

Additionally, the file *grapher.sh* is used to generate a series of graphs based on the outcomes of the games.

# DEPENDENCIES
*grapher.sh* requires GNUPLOT, which can be installed via `$ apt install gnuplot`

build-essential, which can be installed via `$ apt install build-essential`

clang, which can be installed via `$ apt install clang`

# OPTIONAL MODULES
clang-format is required for some arguments of Makefile, but is not used by default. It can be installed via `$apt install clang-format`

# I/O & USAGE
All Files must be in the same directory as the provided files and Makefile as it compiles the c program during runtime.

The program can be run by executing `$ ./play-dreidel`.

The *play-dreidel* executable accepts the following optional arguments.

-p [Players]
---
Specifies the amount of players in the game. 2-8, inclusive. Default is 4.

-c [Coins]
---
Specifies the amount of coins each player starts with. 1-20, inclusive. Default is 3.

-s [Seed]
---
Specifies the number with which the Mersenne Twister is seeded. Any positive non-zero integer less than 10 digits. Default is 613.

-v
---
Specifies verbose output, which prints when a player is eliminated. Default off.

# Makefile
*Makefile*, which is by default executed by *grapher.sh*, can be run by itself to compile all the *.c* and *.h* files in the directory.

*Makefile* can be run via `$ make` assuming build-essential is installed. It accepts the following arguments:

`all`, `play-dreidel`
---
All, which is also the default none argument, will compile all necessary *.c* and *.h* files: *play-dreidel.c*, *dreidel.c*, *dreidel.h*, *mtrand.c*, *mtrand.h*.

`clean`
---
Removes all compiled executables and PDFs from the directory Makefile is in.

`format`
---
Formats all .c and .h files in the working directory in accordance with a .clang-format file. File not provided.
