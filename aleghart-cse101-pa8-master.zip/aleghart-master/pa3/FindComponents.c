/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA3
* FindComponents.c
* Uses Graph ADT DFS to determine the strongly connected components of a graph
*********************************************************************************/
#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.

#include "List.h"
#include "Graph.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>


char *infile;
char *outfile;

int main(int argc, char **argv) {
  if (argc != 3) {
    //occurs when the amount of runtime arguments is not two.
    fprintf(stderr, "Incorrect number of inputs.\n");
    exit(EXIT_FAILURE);
  }
//step 1: parse infile and outfile
  infile = argv[1];
  outfile = argv[2];
//open and validate files
  FILE *input;
  input = fopen(infile, "r");
  if (input == NULL) {
    fprintf(stderr, "Bad filepath for input file.\n");
    exit(EXIT_FAILURE);
  }
  FILE *output;
  output = fopen(outfile, "w");
  if (output == NULL) {
    fprintf(stderr, "Bad filepath for output file.\n");
    exit(EXIT_FAILURE);
  }
// both should now be open :)
//fprintf(stderr, "finished opening both files.\n");

  //to parse the infile:
    //step 1: the first line should be the order of the graph.
    //from there, the first word of the next lines is the source of an edge.
        //the third word is the destination of the edge.

    //once the edges are done being listed, there will be a dummy line of 0's
    //from there, the first word in the line is the "source"
      //bfs with first word as source, then, try and find a path to the destination, the third char
  char* line = NULL;
  size_t len = 100;
  getline(&line, &len, input);
  int order = atoi(line);
  //fprintf(stderr, "%i\n", order);

  Graph G = newGraph(order);


  while (getline(&line, &len, input) != -1) {
    //fprintf(stderr, "%s\n", line);
    int num1 = atoi(strtok(line, " "));
    int num2 = atoi(strtok(NULL, " "));
    if (num1 == 0){
      break;
    }
    //fprintf(stderr, "num1: %i | num2: %i\n", num1, num2);
    addArc(G, num1, num2);
  }
  //free(&line);

  //done with part 1
  fprintf(output, "Adjacency list representation of G:\n");
  printGraph(output, G);
  fprintf(output, "\n");


  //now to run DFS on G and G^t
  List L = newList();
  for (int i = 1; i <= getOrder(G); i++) {
    append(L, i);
  } //start in regular order

  DFS(G, L);
  Graph T = transpose(G);
  //for testing only
  // fprintf(output, "Adjacency list representation of G-transpose:\n");
  // printGraph(output, T);
  // fprintf(output, "\n");
  DFS(T, L); // L will now already be in decreasing finish times.
  //printList(stdout, L);
  //preliminary find the number of components.
  moveFront(L);
  int numComponents = 0;
  while (index(L) != -1) {
    if (getParent(T, get(L)) == NIL) { // found a tree head
      numComponents++;
    }
    moveNext(L);
  }
  fprintf(output, "G contains %i strongly connected components:\n", numComponents);

  List S = newList();
  moveBack(L);
  int found = 0;
  //to construct the strong components:
    //walk the list L in reverse order, prepending each visited number to S.
    //once a tree head is reached, print & clear S.
  while (index(L) != -1) {
    prepend(S, get(L));
    if (getParent(T, get(L)) == NIL) {
      found++;
      fprintf(output, "Component %i: ", found);
      printList(output, S);
      clear(S);
    }
    movePrev(L);
  }
  assert(found == numComponents);


  fclose(input);
  fclose(output);
  input = NULL;
  output = NULL;
  freeGraph(&G);
  freeGraph(&T);
  freeList(&L);
  freeList(&S);


  return EXIT_SUCCESS;
}
