/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* Arithmentic.cpp
* DESCRIPTION HERE
*********************************************************************************/
#include "BigInteger.h"

#include <iostream>
#include <fstream>
#include <iomanip>

#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
//using namespace std;

#define  _POSIX_C_SOURCE 200809L //man idk what this actually does but its for getline.
//won't compile without a warning without this define.




int main(int argc, char **argv) {
  if (argc != 3) {
    std::cerr << "Arithmetic.cpp: Incorrect number of inputs." << '\n';
    exit(EXIT_FAILURE);
  }
//step 1: parse infile and outfile
  // char* infile = argv[1];
  // char* outfile = argv[2];
//open and validate files
  std::ifstream input;
  input.open(argv[1], std::ios::in);
  // if (input.is_open()) {
  //   std::cout << "input opened" << '\n';
  // }
  if (input.fail()) {
    std::cerr << "Arithmetic.cpp: Bad filepath for input file." << '\n';
    exit(EXIT_FAILURE);
  }
  std::ofstream output;
  output.open(argv[2], std::ios::out | std::ios::trunc);
  if (output.fail()) {
    std::cerr << "Arithmetic.cpp: Bad filepath for output file." << '\n';
    exit(EXIT_FAILURE);
  }
// both should now be open :)
//fprintf(stderr, "finished opening both files.\n");

  std::string line;

  BigInteger A, B;

  //get line 1 and make our first bigInt
  //std::cout << input << '\n';

  std::getline(input, line);
  //std::cout << "line: " << line << '\n';
  A = BigInteger(line);

  //discard line 2.
  std::getline(input, line);

//make b line 3
  std::getline(input, line);
  B = BigInteger(line);

  // std::cout << "a: " << A << '\n';
  // std::cout << "b: " << B << '\n';

//A
  output << A << '\n' << '\n';
  //std::cout << "done a" << '\n';
//B
  output << B << '\n' << '\n';
  // std::cout << "done B" << '\n';


  BigInteger T;

//A + B
  T = A + B;
  output << T << '\n' << '\n';
  // std::cout << "done a+b" << '\n';

//A - B
  T = A - B;
  output << T << '\n' << '\n';
  // std::cout << "done a-b" << '\n';


//A - A
  T = A - A;
  output << T << '\n' << '\n';
  // std::cout << "done a-a" << '\n';


  BigInteger C = BigInteger(3);
  BigInteger D = BigInteger(2);

//3A - 2B
  T = (C*A) - (D*B);
  output << T << '\n' << '\n';
  // std::cout << "done 3a-2b" << '\n';

//AB
  T = A*B;
  output << T << '\n' << '\n';
  // std::cout << "done a*b" << '\n';

//A^2
  T = A*A;
  output << T << '\n' << '\n';
  // std::cout << "done a^2" << '\n';


//B^2
  T = B*B;
  output << T << '\n' << '\n';
  // std::cout << "done b^2" << '\n';

  std::cout << "starting 9a^4 16b^5" << '\n';
//9A^4 + 16B^5
  C = A * A * A * A;
  C *= BigInteger(9);

  std::cout << "done with c" << '\n';
  D = B * B * B * B * B;
  D *= BigInteger(16);
  std::cout << "done with d" << '\n';
  C += D;
  output << C << '\n' << '\n';
  std::cout << "done with c + D" << '\n';
  input.close();
  output.close();

  return 0;
}
