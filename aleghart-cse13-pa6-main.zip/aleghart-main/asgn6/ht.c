#include "ll.h"
#include "city.h"

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct HashTable{
  uint64_t salt;
  uint32_t size;
  uint32_t n_keys;
  uint32_t n_hits;
  uint32_t n_misses;
  uint32_t n_examined;
  bool mtf;
  LinkedList **lists;
};


struct HashTable *ht_create(uint32_t size, bool mtf){
  struct HashTable *ht = (struct HashTable *) malloc(sizeof(struct HashTable));
  if (ht != NULL) {
    ht->mtf = mtf;
    ht->salt = 0x9846e4f157fe8840;
    ht->n_hits = ht->n_misses = ht->n_examined = 0;
    ht->n_keys = 0;
    ht->size = size;
    ht->lists = (LinkedList **) calloc(size , sizeof(LinkedList *));
    if (!ht->lists) {
      free(ht);
      ht = NULL;
    }
  }
  return ht;
}

void ht_print(struct HashTable *ht) {
  for (size_t i = 0; i < ht->size; i++) {
    if (ht->lists[i] != NULL) {
      ll_print(ht->lists[i]);
    }
  }
  return;
}

void ht_delete(struct HashTable **ht){
  for (size_t i = 0; i < (*ht)->size; i++) { // loop through the array of linked lists
    if ((*ht)->lists[i] != NULL){
      ll_delete(&(*ht)->lists[i]); // if  a list exists at that index, call it's delete.
    }
  }
  free((*ht)->lists); // once the array has been looped through , free it.
  (*ht)->lists = NULL;
  //now there are no other things inside ht that need to be freed,
  // so we can free ht.
  free(*ht);
  ht = NULL;
  return;
}

uint32_t ht_size(struct HashTable *ht){
  return ht->size;
}

struct Node *ht_lookup(struct HashTable *ht, char *oldspeak){
  //printf("in ht_lookup\n");
  uint32_t seeks, links, seeks2;
  ll_stats(&seeks, &links);
  uint64_t index = hash(ht->salt, oldspeak) % ht->size;
  struct Node *retVal = ll_lookup(ht->lists[index], oldspeak);
  //printf("after lookup\n");
  ll_stats(&seeks2, &links);
  ht->n_examined += seeks2 - seeks;
  if (retVal != NULL) {
    ht->n_hits++;
  }else{
    ht->n_misses++;
  }
  //printf("end ht_lookup\n");
  return retVal;
}

void ht_insert(struct HashTable *ht, char *oldspeak, char *newspeak){
  //printf("in ht insert!\n");
  uint64_t index = hash(ht->salt, oldspeak) % ht->size;
  if (ht->lists[index] == NULL){
    ht->lists[index] = ll_create(ht->mtf); //if that index is empy then we init
  }
  //we do NOT need to check for duplicates, as ll_insert does this for us.
  //scratch that -> we DO need to check for duplicates, so that we don't add
  //to n_keys if it's already in there. without using lookup.
  if (ll_lookup(ht->lists[index], oldspeak) == NULL) {
    ll_insert(ht->lists[index], oldspeak, newspeak);
    ht->n_keys += 1;
  } else {
    //printf("not inserting: %s\n", oldspeak);
  }

}

uint32_t ht_count(struct HashTable *ht){
  uint32_t cout = 0;
  for (size_t i = 0; i < ht->size; i++) { // loop through the array of linked lists
    if (ht->lists[i] != NULL){
      cout++; //if a list exists at that index, add one to cout.
    }
  }
  return cout;
}

void ht_stats(struct HashTable *ht, uint32_t *nk, uint32_t *nh, uint32_t *nm, uint32_t *ne){
  *nk = ht->n_keys;
  *nh = ht->n_hits;
  *nm = ht->n_misses;
  *ne = ht->n_examined;
  return;
}
