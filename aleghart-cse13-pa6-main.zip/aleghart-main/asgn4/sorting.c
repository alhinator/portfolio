#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include <stdint.h>
#include "stdbool.h"
#include <inttypes.h>

#include "mtrand.h"

#include "stats.h"
#include "set.h"

#include "bubble.h"
#include "shell.h"
#include "quick.h"
#include "heap.h"

#define OPTIONS "asbqhr:n:p:H"

//define all our set stuff
#define BUBBLE 1
#define HEAP 2
#define QUICK 3
#define SHELL 4

uint64_t BITMASK = 0x3FFFFFFF;
uint64_t seed = 13371453;
int array_length = 100;
int print_elements = 100;
int backwards = 0;

void print_my_array(char * name, int prLen, Stats *the, uint32_t *arr, uint32_t arrLen){
  printf("%s Sort, %u elements, %"PRIu64" moves, %"PRIu64" compares\n", name, arrLen, the->moves, the->compares); //fucking problematic
  int printed = 0;
  for (int pr = 0; pr < prLen; pr++) {
    printf("%13"PRIu32, arr[pr]);
    printed++;
    if (printed == 5) {
      printf("\n");
      printed = 0;
    }
  } if (printed != 0){printf("\n");}
}

void print_help_message(){
  fprintf( stderr,
"SYNOPSIS\n"
"   A collection of comparison-based sorting algorithms.\n\n"
"USAGE\n"
"   ./sorting [-Hasbhq] [-n length] [-p elements] [-r seed]\n\n"
"OPTIONS\n"
"   -H              Display program help and usage.\n"
"   -a              Enable all sorts.\n"
"   -b              Enable Bubble Sort.\n"
"   -h              Enable Heap Sort.\n"
"   -q              Enable Quick Sort.\n"
"   -s              Enable Shell Sort.\n"
"   -n length       Specify number of array elements (default: 100).\n"
"   -p elements     Specify number of elements to print (default: 100).\n"
"   -r seed         Specify random seed (default: 13371453).\n");
}

int main(int argc, char **argv) { // this was all sourced from man getopt (3) so i dont have to cite it i think, just putting this here to be safe.

  //define our set and our stats
  uint32_t optset = set_empty();
  Stats* myStats = malloc(2 * sizeof(uint64_t));


  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'a':
        //enable all sorts
        optset = set_insert(optset, SHELL);
        optset = set_insert(optset, BUBBLE);
        optset = set_insert(optset, QUICK);
        optset = set_insert(optset, HEAP);

        break;
      case 's':
        //enable shell sort
        optset = set_insert(optset, SHELL);
        break;
      case 'b':
        //enable bubble sort
        optset = set_insert(optset, BUBBLE);
        break;
      case 'q':
        //enable quick sort
        optset = set_insert(optset, QUICK);
        break;
      case 'h':
        //enable heap sort
        optset = set_insert(optset, HEAP);
        break;
      case 'r':
        //set the seed
        seed = strtoul(optarg, NULL, 10);
        if (seed >= 0 && seed <= 9999999999){   // copied from my last program
          break;
        }else{
          print_help_message();
          exit(71);
        }
        break;
      // case 'k':
      //   backwards = 1;
      //   break;
      case 'n':
      array_length = atoi(optarg);
      if (array_length >= 1 && array_length <= 250000000){
        break;
      }else{
        print_help_message();
        exit(72);
      }
        break;
      case 'p':
        print_elements = atoi(optarg);
        //printf("print eles set to %i\n", print_elements);
        if (print_elements < 0){
          print_help_message();
          exit(73);
        }
        break;
      case 'H':
        print_help_message();
        exit(EXIT_SUCCESS);
        break;
      case '?':
      print_help_message();
        exit(EXIT_FAILURE);
    }
  }
  //now that all of optarg is done, we adjust print_elements
  if (print_elements > array_length) {print_elements = array_length;}
  //seed the twister
  mtrand_seed(seed);
  //GENERATE OUR UNSORTED ARRAY
  uint32_t *unsortedArr = (uint32_t*) malloc(sizeof(uint32_t) * array_length);

  // if (backwards == 1) {  //FOR GRAPHING ONLY
  //   for (int i = 0; i < array_length; i++) {
  //     unsortedArr[i] = array_length - i;
  //     //printf("%u\n", unsortedArr[i]);
  //   }
  //
  // }else{
    for (int i = 0; i < array_length; i++) {
      uint64_t rand = mtrand_rand64();
      uint32_t tmp = (uint32_t) BITMASK & rand;  // bitwise and it so that only the last 30 bits are used, then cast to a uint32_t
      unsortedArr[i] = tmp; //DO NOT MODIFY THE UNSORTED ARRAY BY PASSING INTO THE SORTS!!!!! MAKE A COPY!!!!
    }
  //}

  uint32_t *sortableArr = (uint32_t*) malloc(sizeof(uint32_t) * array_length); //allocate  copy of the array to pass into sorting func

  //begin sorting
  for (int i = 1; i <= 4 ; i++) {
    if (set_member(optset, i)) {
      switch (i) {
        case SHELL:
          reset(myStats); // reset the statistics
          for (int j = 0; j < array_length; j++) {sortableArr[j] = unsortedArr[j];} //REMAKE THE COPY TO UNSORTED FORM
          shell_sort(myStats, sortableArr, array_length); // sort the array
          print_my_array("Shell", print_elements, myStats, sortableArr, array_length); // print the array
          break;
        case BUBBLE:
          reset(myStats); // reset the statistics
          for (int j = 0; j < array_length; j++) {sortableArr[j] = unsortedArr[j];} //REMAKE THE COPY TO UNSORTED FORM
          bubble_sort(myStats, sortableArr, array_length); // sort the array
          print_my_array("Bubble", print_elements, myStats, sortableArr, array_length); // print the array
          break;
        case QUICK:
          reset(myStats); // reset the statistics
          for (int j = 0; j < array_length; j++) {sortableArr[j] = unsortedArr[j];} //REMAKE THE COPY TO UNSORTED FORM
          quick_sort(myStats, sortableArr, array_length); // sort the array
          print_my_array("Quick", print_elements, myStats, sortableArr, array_length); // print the array
          break;
        case HEAP:
          reset(myStats); // reset the statistics
          for (int j = 0; j < array_length; j++) {sortableArr[j] = unsortedArr[j];} //REMAKE THE COPY TO UNSORTED FORM
          heap_sort(myStats, sortableArr, array_length); // sort the array
          print_my_array("Heap", print_elements, myStats, sortableArr, array_length); // print the array
          break;
      }
    }
  }
  free(myStats); // free stats
  free(sortableArr); // free the copy
  free(unsortedArr); //free teh original
  return 0;
}
