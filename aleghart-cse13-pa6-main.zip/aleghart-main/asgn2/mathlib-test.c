#include "stdio.h"
#include "mathlib.h"
#include "unistd.h"
#include "math.h"

#define _USE_MATH_DEFINES
#define OPTIONS "ascSCTl"

void sin_option(){
  // okay, we need to run the sin function in steps of 0.05pi from zero to 2pi
  double pie = M_PI;
  printf("  x            sin              Library       Difference\n  -            ---              -------       ----------\n");
  for(double seed = 0.05*pie; seed < 2*pie; seed += 0.05*pie){
    double mysin = my_sin(seed);
    double libsin = sin(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, mysin, libsin, mysin-libsin);
    //printf("%lf, %lf\n", seed, mysin);
  }
}

void cos_option(){
  // okay, we need to run the cosine function in steps of 0.05pi from zero to 2pi
  double pie = M_PI;
  printf("  x            cos              Library       Difference\n  -            ---              -------       ----------\n");
  for(double seed = 0.05*pie; seed < 2*pie; seed += 0.05*pie){
    double mycos = my_cos(seed);
    double libcos = cos(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, mycos, libcos, mycos-libcos);
  }
}

void arcsin_option(){
  //okay, we need to run the arcsin function in steps of 0.05 from -1 to 1
  printf("  x            arcsin           Library       Difference\n  -            ------           -------       ----------\n");
  for(double seed = -1; seed < 1; seed += 0.05){
    double myarcsin = my_arcsin(seed);
    double libarcsin = asin(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, myarcsin, libarcsin, myarcsin-libarcsin);
  }
}

void arccos_option(){
  //okay, we need to run the arcsin function in steps of 0.05 from -1 to 1
  printf("  x            arccos           Library       Difference\n  -            ------           -------       ----------\n");
  for(double seed = -1; seed < 1; seed += 0.05){
    double myarccos = my_arccos(seed);
    double libarccos = acos(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, myarccos, libarccos, myarccos-libarccos);
  }
}

void arctan_option(){
  //okay, arctan function
  printf("  x            arctan           Library       Difference\n  -            ------           -------       ----------\n");
  for(double seed = 1; seed < 10; seed += 0.05){
    double myarctan = my_arctan(seed);
    double libarctan = atan(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, myarctan, libarctan, myarctan-libarctan);
  }
}

void log_option(){
  printf("  x            log              Library       Difference\n  -            ---              -------       ----------\n");
  for(double seed = 1; seed < 10; seed += 0.05){
    double mylog = my_log(seed);
    double liblog = log(seed);
    printf(" %7.4lf % 16.9lf % 16.9lf % 16.12lf\n", seed, mylog, liblog, mylog-liblog);
    //printf("%lf, %lf\n", seed, mysin);
  }
}

void all_option(){
  arcsin_option();
  arccos_option();
  arctan_option();
  log_option();
  sin_option();
  cos_option();
}

int main(int argc, char **argv) {
  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'a':
        all_option();
        break;
      case 's':
        sin_option();
        break;
      case 'c':
        cos_option();
        break;
      case 'S':
        arcsin_option();
        break;
      case 'C':
        arccos_option();
        break;
      case 'T':
        arctan_option();
        break;
      case 'l':
        log_option();
        break;
    }
  }
}
