/********************************************************************************* 
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA1
* ListTest.c
* Testing harness for List ADT
*********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "List.h"
#include <assert.h>



int main(int argc, char **argv) {



//test append & front/back funcs
// List myList = newList();
//   append(myList, 1);
//
//   //printf("%i\n",   front(myList));
//   append(myList, 3);
//   //printf("%i\n",   back(myList));
//   append(myList, 2);
//   //printf("%i\n",   back(myList));
//   //printf("%i\n", length(myList));
//
//   moveFront(myList);
// //test index
//   printf("%i\n", index(myList));
// //test get
//   printf("%i\n", get(myList));
//
//   moveBack(myList);
//   //test index
//     printf("%i\n", index(myList));
//   //test get
//     printf("%i\n", get(myList));
//test removal functions
  //deleteFront(myList);
  // deleteFront(myList);
  // deleteFront(myList);
  //deleteFront(myList);
  //clear(myList);
  //append(myList, 6);

//biggy cheese test. going to try and use all the functions here.
  List L = newList();
  prepend(L, 1);
  clear(L);
  append(L, 2);
  clear(L);
  prepend(L, 3);
  fprintf(stderr, "break 1\n");
  moveFront(L);

  insertBefore(L, 4);

  insertAfter(L, 5);
  fprintf(stderr, "after\n");

  fprintf(stderr, "break 2\n");
  moveBack(L);
  insertBefore(L, 6);
  insertAfter(L, 7);
  movePrev(L);
  movePrev(L);
  delete(L);
  deleteFront(L);
  moveFront(L);
  moveNext(L);
  insertAfter(L, 8);
  insertAfter(L, 9);
  moveFront(L);
  deleteFront(L);
  moveBack(L);
  deleteBack(L);

  List M = copyList(L);

  assert(equals(L, M));
  append(M, 6);
  assert(!equals(L, M));

  List A = newList();
  List B = newList();
  assert(equals(A, B));

  FILE *outfile = fopen("cock.txt", "w");
  printList(outfile, L);

  freeList(&L);
  fclose(outfile);




  return EXIT_SUCCESS;
}
