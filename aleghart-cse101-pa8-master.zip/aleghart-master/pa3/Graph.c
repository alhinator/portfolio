/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA3
* Graph.c
* Graph ADT implementation
*********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "List.h"
#include "Graph.h"


//exportable types
typedef struct GraphObj{
  List* vertices; //an array of lists. NOTE: don't use index 0, create the array size n+1
    //each index in vertices will contain a list that contains the neighbors of that vertex.
  int* colors; //an array of ints where the value at index i is the color of vertex i
  int* parents; //for a given index i in parents, the value at i is the index of i's parent.
  //int* distance; //in a given index i, the value is the distance from the most recent "source" to i.
  int order; // the number of vertices in this list
  //int source; // the vertex most recently defined as the "source"
  int* discover; //the time at which vertiex i was discovered
  int* finish; //the time at which vertex i was finished
  int edges; // doing this for ease of access
  int arcs; // doing this for ease of access

}GraphObj;

// ----------- Constructors/Destructors -------------------
Graph newGraph(int n){ //allocates and returns space for a new graph. n ins the number of vertices.
  Graph retGraph = malloc(sizeof(GraphObj));
  assert(retGraph != NULL);
  retGraph-> order = n;
  retGraph->vertices = malloc(sizeof(List) * (n+1)); //makes space for pointers to N lists an leave 0 empty
  retGraph->colors = malloc(sizeof(int) * (n+1)); // makes space for N colors leave 0 empty
  retGraph->parents = malloc(sizeof(int) * (n+1));
  //retGraph->distance = malloc(sizeof(int) * (n+1));
  retGraph->discover = malloc(sizeof(int) * (n+1));
  retGraph->finish = malloc(sizeof(int) * (n+1));

  //retGraph->source = NIL; // undefined.
  retGraph->edges = 0;
  retGraph->arcs = 0;

  //now init our lists
  for (size_t i = 1; i <= n; i++) { // leave 0 empty
    retGraph->vertices[i] = newList(); //init lists in vertices
    retGraph->parents[i] = NIL; // init parents to NIL
    retGraph->discover[i] = UNDEF; // init discover time to und
    retGraph->finish[i] = UNDEF; // init finish time to und
  }


  return retGraph;
}
void freeGraph(Graph* pG){
  assert(pG != NULL && *pG != NULL);
  //free((*pG)->distance);
  free((*pG)->parents);
  free((*pG)->colors);
  free((*pG)->discover);
  free((*pG)->finish);

  //free all the primitive arrays
  //fprintf(stderr, "%i\n", (*pG)->order);
  for (size_t i = 1; i <= (*pG)->order; i++) { //free the lists
    freeList(&(*pG)->vertices[i]);
    //fprintf(stderr, "%s\n", "freed list");
  }

  free((*pG)->vertices); //free the array vertices
  free(*pG); // free the graph.
  pG = NULL;

  return;
} //frees a graph and all its components

Graph copyGraph(Graph G){ // returns a copy of a graph G
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | copyGraph() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  Graph retGraph = newGraph(getOrder(G));

  for (int i = 1; i <= getOrder(G); i++) {
    retGraph->vertices[i] = copyList(G->vertices[i]);
    // retGraph->colors[i] = G->colors[i];
    // retGraph->parents[i] = G->parents[i];
    // retGraph->discover[i] = G->discover[i];
    // retGraph->finish[i] = G->finish[i];
  }
  retGraph->edges = G->edges;
  retGraph->arcs = G->arcs;
  return retGraph;
}
Graph transpose(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | transpose() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  //only needs to copy inverse vertices and size.
  Graph T = newGraph(getOrder(G));
  // assume G is a directed graph.
  //loop through all vertices of G.
  //in each vertex's adjacency list, loop through that list and
  // add themself to list of each of those vertexes in the T-graph.
  for (int i = 1; i <= getOrder(G); i++) {
    List L = G->vertices[i];
    moveFront(L);
    while (index(L) != -1) {
      int v = get(L);
      //add i to v's list in the new graph.
      addArc(T, v, i);
      moveNext(L);
    }
  }
  //check the sizes are the same.
  assert(getSize(G) == getSize(T));

  return T;
}


// ----------- access functions ---------------------------

int getOrder(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getOrder() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->order;
}
int getSize(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getSize() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  //this is mega simplified from before lol. just gonna require an extra line in addEdge and addArc.
  return (G->edges);
}
/*int getSource(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getSource() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->source;
}*/
int getParent(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getParent() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->parents[u];
}
int getDiscover(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getDiscover() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->discover[u];
}
int getFinish(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getFinish() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->finish[u];
}
/*int getDist(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getDist() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->distance[u];
}*/
/*void getPath(List L, Graph G, int u){
// appends to the List L the vertices of a shortest path
  //in G from source to u, or appends to L the value NIL if no such path exists
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getPath() was called on a NULL graph pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (L == NULL) {
    fprintf(stderr, "Graph ADT | getPath() was called on a NULL list pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || u < 1)  {
    fprintf(stderr, "Graph ADT | getPath() destination parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  if (G->source == NIL) {
    fprintf(stderr, "Graph ADT | getPath() source is NIL.\n");
    exit(EXIT_FAILURE);
  }
  //case 1: no path
  if (G->distance[u] == INF) {
    append(L, NIL);
    return;
  }
  //getPath walks from u to source via parent
  int p = u;
  int counter = 0;
  //begin with the first parent.
  //due to the append requirement to L, the cursor gets a litle funky.
  append(L, p); // the end of the path.
  moveBack(L);
  //cursor is pointing to the end of the list, which is the end of the path.
  while (G->parents[p] != NIL) {
    p = G->parents[p]; //move to prev step
    insertBefore(L, p); //insert the previous step in the path before the current step in the path.
    movePrev(L); //move cursor to prev step
    counter++; //for the assert at the end.
  }
  assert(counter == G->distance[u]); // make sure we found path of the same distance.

}*/

//helper functions
bool addListSorted(List L, int n){
  // start at the beginning of the list and walk it (order N time unfortunately)
  // until we find an entry that is larger than v. then we insertBefore
  if (L == NULL) {
    fprintf(stderr, "Graph ADT | addListSorted() null list pointer.\n");
    exit(EXIT_FAILURE);
  }
  //first case we should check is if the list is empty.
  if (length(L) <= 0) {
    append(L, n); // can just slap it on.
    return true; ///and gtfo
  }
  moveFront(L);

  while (index(L) >= 0 && get(L) < n) {
    //fprintf(stderr, "in addListSorted search loop\n");
    moveNext(L);
  }
  if (index(L) == -1){ //we ran off the back
    append(L, n);
    return true;
  } else if (get(L) == n) { //already has
    //fprintf(stderr, "Graph ADT | addListSorted() entry already exists.\n");
    //exit(EXIT_FAILURE); //do nothing as directed by Ed Discussion.
    return false;
  } else { //found right spot
    insertBefore(L, n);
    return true;
  }
  return false;
}


int visit(Graph G, int x, int time){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | visit() was called on a NULL graph pointer.\n");
    exit(EXIT_FAILURE);
  }
  /*if (S == NULL) {
    fprintf(stderr, "Graph ADT | visit() was called on a NULL list pointer.\n");
    exit(EXIT_FAILURE);
  }*/
  if ( -1 > x || x > getOrder(G)) {
    fprintf(stderr, "Graph ADT | visit() was called on a bad vertex.\n");
    exit(EXIT_FAILURE);
  }

  G->discover[x] = ++time;
  G->colors[x] = GRAY;
  List L = G->vertices[x];
  //fprintf(stderr, "in visit (%i), list of vertices adjacent to current vertex is: ", x);
  //printList(stderr, L);
  moveFront(L);
  while (index(L) != -1) {
    int y = get(L);
    if (G->colors[y] == WHITE) {
      G->parents[y] = x;
      //fprintf(stderr, "%i is WHITE, visiting at %i \n", y, time);
      time = visit(G, y, time);
    }
    moveNext(L);
  }
  G->colors[x] = BLACK;
  //fprintf(stderr, "setting %i to BLACK\n", x);
  G->finish[x] = ++time;
  //fprintf(stderr, "exiting visit (%i), visit is finished at %i\n", x, time);
  return time;
}

// ------------ manipulation procedures ---------------------
void makeNull(Graph G){ //deletes all edges of G, restoring it to its original (no edge) state.
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | makeNull() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 1; i <= G->order; i++) { //revert the lists of edges
    clear(G->vertices[i]);
  }
  G->edges = 0;
  G->arcs = 0;
return;
}
void addEdge(Graph G, int u, int v){
  //going to insert 'v' into vertices[u] at the correct point.
  // then insert u into vertices[v] a the correct point as it is an edge
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || v > getOrder(G) || u < 1 || v < 1)  {
    fprintf(stderr, "Graph ADT | addEdge() vertex u or v parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //add v to u addListSorted
  if (addListSorted(G->vertices[u], v) && addListSorted(G->vertices[v], u) ) {
    G->edges++;
  }
  return;
}
void addArc(Graph G, int u, int v){
  //going to insert 'v' into vertices[u] at the correct point.
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || v > getOrder(G) || u < 1 || v < 1)  {
    fprintf(stderr, "Graph ADT | addEdge() vertex u or v parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //add v to u addListSorted
  if (addListSorted(G->vertices[u], v)) {
    //fprintf(stderr, "adding %i to %i suceeded\n", u, v);
    G->edges++;
    // add Arc we only insert ONCE! arcs ARE unidirectional.
    //lets go!
    //increment arcs by one
  }

  return;
}
/*void BFS(Graph G, int s){ //breadth first sussy
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | BFS() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (s > getOrder(G) || s < 1)  {
    fprintf(stderr, "Graph ADT | BFS() source parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //discovers every vertex reachable from vertex s.
    //step 1: setup the colors, distances, and parents.
  //fprintf(stderr, "top of BFS\n");
  for (int i = 1; i <= getOrder(G); i++) {
    G->colors[i] = WHITE;
    G->distance[i] = INF;
    G->parents[i] = NIL;
  }
    //step 2: discover the source s by making it gray, set distance to itself as 0.
    //it's parent is already nil.
  G->source = s;
  G->colors[s] = GRAY;
  G->distance[s] = 0;
    //step 3: create an empty queue and add s to the queue.
  List Q = newList();
  append(Q, s);
    //step 4: main loop, which will discover until the queue is empty.
  while (length(Q) > 0) {
    //fprintf(stderr, "top of Queue\n");
      //part A: dequeue x
    moveFront(Q);
    int x = get(Q);
    deleteFront(Q);
    //fprintf(stderr, "dequeueing %i\n", x);

      //part B: loop through the adjacency list of x.
      //make a temp pointer.
    List ADJ = G->vertices[x];
    moveFront(ADJ);
    while (length(ADJ) > 0 && index(ADJ) >= 0) {
        //part C: inside the adjacency loop
        //get y, which is a neighbor of x.
        int y = get(ADJ);
        if (G->colors[y] == WHITE) { //if y is undiscovered
          G->colors[y] = GRAY; //discover y
          G->distance[y] = G->distance[x] + 1;
           //the distance from the source to y is one more than the previous neighbor.
           //this is okay to do in BFS beause it touches all neighbors on the same level before increasing the distance
          G->parents[y] = x; //set x as the parent of y.
          append(Q, y); // enqueue y to the BFS queue.
          //fprintf(stderr, "enqueuing %i\n", y);
        }
        //end of adj loop: increase position in adjacency list
        moveNext(ADJ);
    }
    //we have visited all neighbors of X at this point.
    G->colors[x] = BLACK;
  }
  //end of BFS!
  freeList(&Q);
}*/
void DFS(Graph G, List S){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | DFS() was called on a NULL graph pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (S == NULL) {
    fprintf(stderr, "Graph ADT | DFS() was called on a NULL list pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (length(S) != getOrder(G)) {
    fprintf(stderr, "Graph ADT | DFS() list is of incorrect length.\n");
    exit(EXIT_FAILURE);
  }

  //fprintf(stderr, "top of DFS:\n");
  //performs a depth first search from each vertex in Graph g.
  for (int i = 1; i <= getOrder(G); i++) { //loop through all vertices, setting color and parentage.
    G->colors[i] = WHITE;
    G->parents[i] = NIL;
  }
  //fprintf(stderr, "set colors and parents to default.\n");
  int time = 0; //our timer func, goes from 0 to up to 2n.
  //main loop:
  moveFront(S);
  while (index(S) != -1) {
    if (G->colors[get(S)] == WHITE) {
      //fprintf(stderr, "%i is WHITE, visiting at %i \n", get(S), time);
      time = visit(G, get(S), time);
    }
    moveNext(S);
  }
  //now use the list as a "stack" output
  clear(S);
  append(S, 1);
  for (int i = 2; i <= getOrder(G); i++) {
    moveFront(S);
    int ft = G->finish[i];
    while(index(S) != -1 && ft < G->finish[get(S)]){ //while the current finish time is smaller than the compared time, go further
      moveNext(S);
    }
    if (index(S) == -1) { //ran off the back; finish time is smallest of the list.
      append(S, i);
    } else {
      //we have now found our correct spot in the list
      insertBefore(S, i);
    }

  }
}


// ----------- other functions ------------------
void printGraph(FILE* out, Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | printGraph() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (out == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() bad output file.\n");
    exit(EXIT_FAILURE);
  }

  //what we need to do here is: for every index from 1-n,
    //print the label of that index, colon, space, then every number in that list separated by space.

  for (int i = 1; i <= getOrder(G); i++) {
    fprintf(out, "%i: ", i); //no \n yet
    printList(out, G->vertices[i]); //can just use this baby
  }
}










//hi =)
