# PURPOSE
./banhammer will read in words from stdin, identify any badspeak or old speak and output an
appropriate punishment message. The badspeak and oldspeak (with the newspeak translation)
that caused the punishment will be printed after the message. If statistics are enabled
punishment messages are suppressed and only statistics will be printed.

# DEPENDENCIES

build-essential, which can be installed via `$ apt install build-essential`

clang, which can be installed via `$ apt install clang`

# OPTIONAL MODULES
clang-format is required for some arguments of Makefile, but is not used by default. It can be installed via `$apt install clang-format`

# I/O & USAGE
All Files must be in the same directory as the provided files and Makefile as it compiles the c program during runtime.

Usage: ./banhammer [options]
  ./banhammer will read in words from stdin, identify any badspeak or old speak and output an appropriate punishment message. The badspeak and oldspeak (with the newspeak translation) that caused the punishment will be printed after the message. If statistics are enabled punishment messages are suppressed and only statistics will be printed.

    -t <ht_size>: Hash table size set to <ht_size>. (default: 10000)
    -f <bf_size>: Bloom filter size set to <bf_size>. (default 2^19)
    -s          : Enables the printing of statistics.
    -m          : Enables move-to-front rule.
    -h          : Display program synopsis and usage.

    # Makefile
    *Makefile* can be run by itself to compile all the included *.c* and *.h* files in the directory.

    *Makefile* can be run via `$ make` assuming build-essential is installed. It accepts the following arguments:

    `all`
    ---
    All, which is also the default none argument, will compile all necessary
     *.c* and *.h* files: *banhammer.c*, *banhammer.h*, *bf.c*, *bf.h*, *ht.c*, *ht.h*, *ll.c*, *ll.h*, *node.c*, *node.h*, *parser.c*, *parser.h*, *city.c*, and *city.h*.

    `<filename>`
    ---
    `make <filename>` will compile only the specified file.

    `clean`
    ---
    Removes all compiled .o files from the directory Makefile is in.

    `spotless`
    ---
    Removes all compiled .o files and derived executables from the directory Makefile is in.

    `format`
    ---
    Formats all .c and .h files in the working directory in accordance with a .clang-format file. File not included.
