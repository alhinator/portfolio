#pragma once

char spin_dreidel(void);
int play_game (int n_players , int coins_per_player , int * n_rounds);

extern int verbose;
extern const char *PLAYER_NAMES[8];
