CHEATING-aleghart.pdf -> Academic Dishonesty Document
PRD-aleghart.pdf -> Personal Responsibility Document
hello.c -> Prints "Hello World!"
README.md -> Recursive definition :3
