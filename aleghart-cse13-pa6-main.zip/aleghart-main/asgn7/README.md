# PURPOSE
A Huffman encoder / decoder.
Compresses or decompresses a file using the Huffman Coding algorithm.

# DEPENDENCIES

build-essential, which can be installed via `$ apt install build-essential`

clang, which can be installed via `$ apt install clang`

# OPTIONAL MODULES
clang-format is required for some arguments of Makefile, but is not used by default. It can be installed via `$apt install clang-format`

# I/O & USAGE
All Files must be in the same directory as the provided files and Makefile as it compiles the c program during runtime.

USAGE
  ./encode [-h] [-i infile] [-o outfile]

OPTIONS
  -h             Program usage and help.
  -v             Print compression statistics.
  -i infile      Input file to compress.
  -o outfile     Output of compressed data.

# Makefile
*Makefile* can be run by itself to compile all the included *.c* and *.h* files in the directory.

*Makefile* can be run via `$ make` assuming build-essential is installed. It accepts the following arguments:

`all`
---
All, which is also the default none argument, will compile all necessary
 *.c* and *.h* files: *code.c*, *code.h*, *decode.c*, *defines.h*, *encode.c*, *header.h*, *huffman.c*, *huffman.h*, *io.h*, *io.h*, *node.c*, *node.h*, *pq.c*, *pq.h*, *stack.c*, *stack.h*.

`<filename>`
---
`make <filename>` will compile only the specified file.

`clean`
---
Removes all compiled .o files from the directory Makefile is in.

`spotless`
---
Removes all compiled .o files and derived executables from the directory Makefile is in.

`format`
---
Formats all .c and .h files in the working directory in accordance with a .clang-format file. File not included.
NOTE: The submitted files have been formatted using a file provided by tutor Ben G.
