// clang-format off
#include <stdio.h>
#include <gmp.h>
//clang-format on
#include <stdbool.h>
#include <stdint.h>


#include "randstate.h"

void gcd(mpz_t d, mpz_t a, mpz_t b) {
  // stores d, the  greatest common divisor of a and b
  mpz_t t, bb;
  mpz_inits(t, bb, NULL);
  mpz_set(d, a);  // this way we can directly return d without modifying a.
  mpz_set(bb, b); // don't want to modify b.
  while (mpz_sgn(bb) != 0) { // while b != 0
    mpz_set(t, bb);          // t <-- b
    mpz_mod(bb, d, bb);      // b <-- a mod b
    mpz_set(d, t);           // a <-- t
  }
  mpz_clears(t, bb, NULL);
  return; // d should be correct value
}

void mod_inverse(mpz_t o, mpz_t a, mpz_t n) { // o is return value, not i
  // set up all mpz_t variables
  mpz_t r, rp, t, tp, q, xtemp, xptemp, temp3;
  mpz_inits(r, rp, t, tp, q, xtemp, xptemp, temp3, NULL);
  // 1 (r,r′) ←(n,a)
  mpz_set(r, n);
  mpz_set(rp, a);
  // 2 (t,t′) ←(0,1)
  mpz_set_ui(t, 0);
  mpz_set_ui(tp, 1);

  while (mpz_sgn(rp) != 0) { // 3 while loop
    mpz_div(q, r, rp);       // 4 q←⌊r/r′⌋
    // 5 (r,r′) ←(r′,r−q×r′)
    // what we need to do, in order, is:
    // set "original" r & rp variables into their temps
    // set NEW r to equal original rp
    // set NEW rp to equal original r minus q times original rp
    mpz_set(xtemp, r);
    mpz_set(xptemp, rp);
    mpz_set(r, rp);
    mpz_mul(temp3, q, xptemp);
    mpz_sub(rp, xtemp, temp3);
    // 6 (t,t′) ←(t′,t−q×t′
    // what we need to do, in order, is:
    // set "original" t & tp variables into their temps
    // set NEW t to equal original tp
    // set NEW tp to equal original t minus q times original tp
    mpz_set(xtemp, t);
    mpz_set(xptemp, tp);
    mpz_set(t, tp);
    mpz_mul(temp3, q, xptemp);
    mpz_sub(tp, xtemp, temp3);
  }                           // end while loop
  if (mpz_cmp_ui(r, 1) > 0) { // 7 if r > 1
    // 8 return no inverse
    mpz_set(o, 0);
    mpz_clears(r, rp, t, tp, q, xtemp, xptemp, temp3, NULL);
    return;
  }
  // 9 if t < 0
  if (mpz_sgn(t) < 0) {
    mpz_add(t, t, n); // 10 t ← t + n
  }
  mpz_set(o, t); // 11 return t
  mpz_clears(r, rp, t, tp, q, xtemp, xptemp, temp3, NULL);
  return;
}

void pow_mod(mpz_t o, mpz_t a, mpz_t d,
             mpz_t n) { // o = out, a = base, d = exponent, n = modulus
  // updated to use foo vars so as not to modify originals.
  mpz_t aa, dd, nn, p, temp;
  mpz_inits(aa, dd, nn, p, temp, NULL);
  mpz_set(aa, a);
  mpz_set(dd, d);
  mpz_set(nn, n);
  mpz_set_ui(o, 1);
  mpz_set(p, aa);
  while (mpz_sgn(dd) > 0) {
    if (mpz_odd_p(dd) != 0) { // if exp is odd
      mpz_mul(temp, o, p);
      mpz_mod(o, temp, nn);
    }
    mpz_mul(temp, p, p);
    mpz_mod(p, temp, nn);
    mpz_div_ui(dd, dd, 2);
  }
  mpz_clears(aa, dd, nn, p, temp, NULL);
  return;
}

bool is_prime(mpz_t n, uint64_t iters) {
  if (mpz_even_p(n) !=
      0) { // easiest way to check if its not prime is if its even
    return false;
  }

  mpz_t s, r, a, y, temp, nm1, j, sm1;
  mpz_inits(s, r, a, y, temp, nm1, j, sm1, NULL); // first step, generate s
  mpz_sub_ui(nm1, n, 1);
  mpz_set(r, nm1);  // lets start r at n - 1
  mpz_set_ui(s, 0); // start s at 0
  while (mpz_cmp(s, n) < 0) {
    // check if r is odd
    if (mpz_even_p(r) != 0) {
      mpz_div_ui(r, r, 2);
      break;
    }
    mpz_add_ui(s, s, 1);
  } // end s & r generation
  for (uint64_t i = 1; i < iters; i++) {
    // Choose a random ‘a’ between 2 and n-2
    mpz_sub_ui(temp, n, 3);
    mpz_urandomm(a, state, temp);
    mpz_add_ui(a, y, 2);
    pow_mod(y, a, r, n);
    if (mpz_cmp_ui(y, 1) != 0 && mpz_cmp(y, nm1) != 0) {
      mpz_set_ui(j, 1);
      mpz_sub_ui(sm1, s, 1);
      while (mpz_cmp(j, sm1) <= 0 && mpz_cmp(y, nm1) != 0) {
        mpz_set_ui(temp, 2);
        pow_mod(y, y, temp, n);
        if (mpz_cmp_ui(y, 1) == 0) {
          mpz_clears(s, r, a, y, temp, nm1, j, sm1, NULL);
          return false;
        }
        mpz_add_ui(j, j, 1);
      }
      if (mpz_cmp(y, nm1) != 0) {
        mpz_clears(s, r, a, y, temp, nm1, j, sm1, NULL);
        return false;
      }
    }
  }
  mpz_clears(s, r, a, y, temp, nm1, j, sm1, NULL);
  return true;
}

void make_prime(mpz_t p, uint64_t bits,
                uint64_t iters) { // p is return, bits is how long, and iters is
                                  // how many times to test primality
  mpz_t rand;
  mpz_init(rand);
  while (true) {
    mpz_urandomb(rand, state, bits);
    if (is_prime(rand, iters)) {
      mpz_set(p, rand);
      mpz_clear(rand);
      return;
    }
  }
}
