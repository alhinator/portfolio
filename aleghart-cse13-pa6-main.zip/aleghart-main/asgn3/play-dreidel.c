#include "dreidel.h"
#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include <stdint.h>
#include "mtrand.h"


#define OPTIONS "p:c:s:vbh"

int playerCount = 4;
int startingCoins = 3;
uint64_t seed = 613;
int bash = 0;
int bash2 = 0;
int main(int argc, char **argv) { // this was all sourced from man getopt (3) so i dont have to cite it i think, just putting this here to be safe.
  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'p':
        //printf("%s\n", optarg);
        playerCount = atoi(optarg);
        if (playerCount >= 2 && playerCount <= 8){ // need to get error handling properly formatted
          //printf("work\n");
          break;
        } else{
          fprintf(stderr, "Bad player count argument.\n" );
          exit(69);
        }
        break;
      case 'c':
      startingCoins = atoi(optarg);
        if (startingCoins >= 1 && startingCoins <= 20){ // need to get error handling properly formatted
          break;
        } else{
          fprintf(stderr, "Bad coin value argument.\n" );
          exit(70);
        }
      case 's':
        seed = strtoul(optarg, NULL, 10);
        if (seed > 0 && seed <= 9999999999){// need to get error handling properly formatted
          break;
        }else{
          fprintf(stderr, "Bad seed argument.\n" );
          exit(71);
        }
      case 'v':
        verbose = 1;
        break;
      case 'b':
        bash = 1;
        break;
      case 'h':
        bash2 = 1;
        break;
      case '?':
        fprintf(stderr, "Usage: %s [-p] playerCount [-c] startingCoins [-s] seed [-v Print Elims] [-b my BASH output only]\n", argv[0]);
        exit(EXIT_FAILURE);
    }
  }
  //end of getopt loop
  //now we play the damn game
  int roundCount;
  mtrand_seed(seed);
  int winner = play_game(playerCount, startingCoins, &roundCount);
  if (winner == -1){
    printf("winner is -1 smth went wrong\n");
  }else{
    if (bash){
      printf("%i\n", roundCount); // THIS IS FOR BASH ONLY
    }else if (bash2){
      printf("%i\n", winner); // THIS IS FOR BASH ONLY
    }else{
      printf("%s %i %i %i %lu\n", PLAYER_NAMES[winner], playerCount, startingCoins, roundCount, seed);
    }
  }
}
