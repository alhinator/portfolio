#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "node.h"
#include "pq.h"
#include "stack.h"
#include "defines.h"
#include "code.h"
#include "io.h"
#include "huffman.h"
#include "header.h"

#define OPTIONS "hi:o:v"

bool verbose = false;
char *infile = NULL;
char *outfile = NULL;


//for testing
void tree_print(Node *root){
  if (root) {
    tree_print(root->left);
    tree_print(root->right);
    node_print_sym(root);
  }
}

void print_help_message(){
  fprintf( stderr,
    "SYNOPSIS\n"
    "  A Huffman encoder.\n"
    "  Compresses a file using the Huffman coding algorithm.\n\n"
    "USAGE\n"
    "  ./encode [-h] [-i infile] [-o outfile]\n\n"
    "OPTIONS\n"
    "  -h             Program usage and help.\n"
    "  -v             Print compression statistics.\n"
    "  -i infile      Input file to compress.\n"
    "  -o outfile     Output of compressed data.\n");
}

int main(int argc, char *argv[]) {
  int opt = 0;
  while ((opt = getopt(argc, argv, OPTIONS)) != -1){
    switch (opt){
      case 'i':
        infile = optarg;
        break;
      case 'o':
        outfile = optarg;
        break;
      case 'v':
        verbose = true;
        break;
      case 'h':
        print_help_message();
        exit(EXIT_SUCCESS);
        break;
      case '?':
        print_help_message();
        exit(EXIT_FAILURE);
    }
  }

  //printf("getopt loop finisehd!\n");
/*
//for testing prio queue, stack
  // struct Node* test_node_A = node_create('a', 1);
  // struct Node* test_node_B = node_create('b', 2);
  // struct Node* test_node_C = node_create('c', 3);
  // struct Node* test_node_D = node_create('d', 4);
  // struct Node* test_node_E = node_create('e', 5);
  // struct Node* test_node_F = node_create('f', 6);
  // struct Node* test_node_G = node_create('g', 7);
  //
  // struct PriorityQueue *pq = pq_create(6);
  //
  // struct Node *dq = NULL;
  //
  // enqueue(pq, test_node_F);
  // enqueue(pq, test_node_A);
  // enqueue(pq, test_node_C);
  // enqueue(pq, test_node_B);
  // dequeue(pq, &dq);
  // enqueue(pq, test_node_E);
  // enqueue(pq, test_node_D);
  // enqueue(pq, dq);
  // enqueue(pq, test_node_G);
  //
  // while (dequeue(pq, &dq)) {
  //   printf("dequeuing:");
  //   node_print(dq);
  // }
  //
  // pq_print(pq);
  //
  // struct Stack *st = stack_create(6);
  //
  // struct Node *dq = NULL;
  //
  // stack_push(st, test_node_A);
  // stack_push(st, test_node_B);
  // stack_push(st, test_node_C);
  // stack_push(st, test_node_D);
  // stack_push(st, test_node_E);
  //
  // struct Node *j = node_join(test_node_F, test_node_G);
  // stack_push(st, j);
  //
  // stack_print(st);
  //
  //
  // while (stack_pop(st, &dq)) {
  //   printf("dequeuing:");
  //   node_print(dq);
  // }
  //
  // stack_print(st);
  //
  // stack_delete(&st);
  // stack_print(st);

//-----------------------------------------------------------------------------

//for testing code.c
// Code c = code_init();
// uint8_t ONE = 1;
// uint8_t ZERO = 0;
// uint8_t pop;
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ONE);
// code_print(&c);
// printf("a\n");
//
// code_push_bit(&c, ONE);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ONE);
// code_push_bit(&c, ONE);
//
// code_print(&c);
// printf("a\n");
//
//
// code_pop_bit(&c, &pop);
// code_pop_bit(&c, &pop);
//
// code_push_bit(&c, ONE);
//
// code_push_bit(&c, ZERO);
// code_push_bit(&c, ZERO);
//
// code_print(&c);

//--------------------------
//for testing io.c */

//get our input file set up. -----------
int input;
int secondary;
if (infile) {
  input = open(infile, O_RDONLY);
  secondary = input;
} else {
  input = 0;
  char tmp[] = "/tmp/inXXXXXX";
  secondary = mkstemp(tmp);
}


if (input < 0 || secondary < 0) {
  fprintf(stderr, "Bad input filepath. %i %i\n", input, secondary);
  print_help_message();
  exit(EXIT_FAILURE);
}
//fd "0" is stdin for reference -------

//construct our histogram -----
uint64_t hist[ALPHABET] = {0};
uint8_t buf;
//uint8_t uniq_sym_1 = 0;
while ((read_bytes(input, &buf, 1)) != 0) {
  //printf("%c\n", buf);
  if (secondary) {
    write_bytes(secondary, &buf, 1);
  }
  //uniq_sym_1 += (hist[buf]==0);
  hist[buf] ++;//construct our frequencies table.

}
hist[0] += (hist[0] == 0);
hist[1] += (hist[1] == 0);
//this ensures that at least two nodes will exist when constructing our huffman tree.

//now we need to turn the table into a set of codes.


Code table[ALPHABET]; //create the code table

for (int i = 0; i < ALPHABET; i++) {
   //printf("inting code for %"PRIu8"\n", (uint8_t)i);
   table[i] = code_init(); // set each code to 0 so we dont get garbage values
}

struct Node *tree_root = build_tree(hist);
//printf("------------------------\n\n\n");
//tree_print(tree_root);

build_codes(tree_root, table);
uint16_t uniq_sym_2 = 0;

for (int i = 0; i < ALPHABET; i++) {
  if (!code_empty(&table[i])) {
    //printf("this code is %"PRIu32" long\n", code_size(&table[i]));
    //printf("%c %"PRIu64" ", (uint8_t)i , hist[i]);
    //code_print(&table[i]);
    uniq_sym_2++;
  }
}
//fprintf(stderr,"uniq_sym_2: %"PRIu8"\n", uniq_sym_2 );
//printf("un1: %"PRIu8", un2: %"PRIu8"\n", uniq_sym_1, uniq_sym_2);
//alright! we have a code table now.
Header head;
struct stat b_head;
if (fstat(secondary, &b_head) < 0) {
  fprintf(stderr, "fstat failed.\n");
  exit(EXIT_FAILURE);
}
//create header stuff based on instructions from pdf
head.magic = MAGIC;
head.permissions = b_head.st_mode;
head.tree_size = (3 * uniq_sym_2) - 1;
head.file_size = b_head.st_size;
//fprintf(stderr,"file size is: %"PRIu64"\n", head.file_size);
//fprintf(stderr,"tree size is: %"PRIu16"\n", head.tree_size);

//printf("file magic is: %"PRIu32"\n", head.magic);
//get our output file set up. ----
int output;
if (outfile) {
  output = open(outfile, O_WRONLY | O_CREAT | O_TRUNC);
} else {
  output = 1;
}
if (output < 0) {
  fprintf(stderr, "Bad output filepath.\n");
  print_help_message();
  exit(EXIT_FAILURE);
}
//--------

fchmod(output, b_head.st_mode);

//this code is taken from the central scrutinizer telling people to use union.
union {
    uint8_t b[sizeof(Header)];
    Header s;
} hh;
//end used code
hh.s = head;

// printf("%s\n", hh.b);
//write the header
write_bytes(output, hh.b , sizeof(Header));
//printf("\n----------------------\n" );
//dump the tree
//tree_print(tree_root);
dump_tree(output, tree_root);

//printf("----\n\n");
//write the codes.
//first need to go to beginnning of secondary.
lseek(secondary, 0, SEEK_SET);
while ((read_bytes(secondary, &buf, 1))) {
  //fprintf(stderr, "calling to write the code for %c :\n", buf);
  //code_print(&table[buf]);
  write_code(output, &table[buf]);
}

flush_codes(output);

//statistics.
struct stat out_stat;
if (fstat(output, &out_stat) < 0) {
  fprintf(stderr, "fstat for output failed.\n");
  exit(EXIT_FAILURE);
}
if (verbose) {
  fprintf(stderr,"Uncompressed file size: %"PRIu64" bytes\n", head.file_size);
  fprintf(stderr,"Compressed file size: %"PRIu64" bytes\n", out_stat.st_size);
  float saving = 100.0 * (1.0 - ((float)out_stat.st_size)/(float)head.file_size);
  fprintf(stderr,"Space saving: %0.2f%%\n", saving);
}


//NEED TO DO THE SHIT TO FREE EVERYTHING~!!!
//i turned node_delete into a recursor. ez.
node_delete(&tree_root);

close(input);
close(secondary);
close(output);


  return 0;
}
