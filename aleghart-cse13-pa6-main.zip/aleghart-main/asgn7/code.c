#include "defines.h"
#include <stdbool.h>
#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>

struct Code {
  uint32_t top;
  uint8_t bits[MAX_CODE_SIZE];
};

struct Code code_init(void){
  struct Code new_code;
  new_code.top = 0;
  for (uint32_t i = 0; i < MAX_CODE_SIZE; i++) {
    new_code.bits[i] = 0;
  }
  return new_code;
}

uint32_t code_size(struct Code *c){
  return c->top;
}

bool code_empty(struct Code *c){
  return c->top == 0;
}

bool code_full(struct Code *c){
  return c->top == MAX_CODE_SIZE;
}

bool code_set_bit(struct Code *c, uint32_t i){
  if (i > MAX_CODE_SIZE) {
    return false;
  }
  c->bits[(i / 8)] |= (0x1 << (i % 8)); //ripped from my bv in asgn 6
  return true;
}

bool code_clr_bit(struct Code *c, uint32_t i){
  if (i > MAX_CODE_SIZE) {
    return false;
  }
  c->bits[(i / 8)] &= ~(0x1 << (i % 8)); //ripped from my bv in asgn 6
  return true;
}

bool code_get_bit(struct Code *c, uint32_t i){
  if (i > MAX_CODE_SIZE) {
    return false;
  }
  return (((c->bits[(i / 8)]) >> (i%8)) & 0x00000001) > 0;
  // get the correct part of the vector, bitwise-and it with 00000001, and check if its larger than 0
}

bool code_push_bit(struct Code *c, uint8_t bit){
  if (code_full(c)) {
    return false;
  }
  if (bit == 0) {
    //printf("pushing 0 to bit %"PRIu32"\n", c->top);
    code_clr_bit(c, c->top);
  } else {
    //printf("pushing 1 to bit %"PRIu32"\n", c->top);
    code_set_bit(c, c->top);
  }
  c->top ++;
  return true;
}

bool code_pop_bit(struct Code *c, uint8_t *bit){
  if (code_empty(c)) {
    return false;
  }
  c->top --; //decrease to get to the last added bit.
  *bit = code_get_bit(c, c->top) == true ? 1 : 0;
  //printf("popped %"PRIu8" from bit %"PRIu32"\n", *bit, c->top);
  return true;
}

void code_print(struct Code *c){ //taken from my asgn6 bv & modified
  for (uint8_t i = 0; i < (c->top/8+(!!(c->top%8))); i++) { //dont need to print the unused bytes
    uint8_t current_vector = c->bits[i];
    //this shit is really confusing so im expanding it out so i get it
    //ok so like what we need to do is print each bit of the current_vector
    //going from least significant to most significant
    for (uint8_t j = 0; j < 8; j++) {
      //i is going from 0 to 8. we are looping thru a 8 bit int.
      //basically the gist is we print '1' if the farthest right bit is 1 after
      //a right shift. the shift is determined by i since we are starting at
      //the right side, aka the least significant bit.
      if (i == (c->top/8) && j >= (c->top%8)) {
        continue; //we don't want to print the trailing 0's
      }
      fprintf(stderr,"%"PRIu8"", (current_vector>>j) & 0x1);
    }

    //and go to the next vector
  }
  printf("\n");
  //after we finish printing the ENTIRE CODE we print a newline
  return;
}
