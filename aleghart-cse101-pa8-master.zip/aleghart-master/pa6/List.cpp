/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* List.cpp
* List ADT implementation C++
*********************************************************************************/

#include <iostream>
#include <string>
#include <stdexcept>
#include "List.h"

#define DUMMY -42069

#define POWER 9
#define BASE 1000000000


// Private Constructors

//Node
List::Node::Node(ListElement x){
  data = x;
  prev = nullptr;
  next = nullptr;
}

// Class Constructors / Destructors

//Creates a new list in the empty state
List::List(){
  frontDummy = new Node(DUMMY);
  backDummy = new Node(DUMMY);
  frontDummy->next = backDummy;
  backDummy->prev = frontDummy;
  beforeCursor = frontDummy;
  afterCursor = backDummy;
  pos_cursor = 0;
  num_elements = 0;
}

//copy constructor
List::List(const List& L){
  //start with the basics
  frontDummy = new Node(DUMMY);
  backDummy = new Node(DUMMY);
  frontDummy->next = backDummy;
  backDummy->prev = frontDummy;
  beforeCursor = frontDummy;
  afterCursor = backDummy;
  pos_cursor = 0;
  num_elements = 0;

  //copy all data from L into new list.
  Node* N = L.frontDummy->next;
  while (N->next != nullptr) {
    this->insertBefore(N->data);
    N = N->next;
  }
  moveFront();
  //get cursor to correct position
  while (pos_cursor < L.pos_cursor) {
    moveNext();
  }

}

// Destructor
List::~List(){
  clear();
  //std::cout << "in ~list" << '\n';
  beforeCursor = nullptr;
  afterCursor = nullptr;
  delete frontDummy;
  delete backDummy;
}

// Access functions

int List::length() const{
  return num_elements;
}

ListElement List::front() const{
  if (num_elements == 0) {
    throw std::length_error("List: front(): empty List");
  }
  return(frontDummy->next->data);
}

ListElement List::back() const{
  if (num_elements == 0) {
    throw std::length_error("List: back(): empty List");
  }
  return(backDummy->prev->data);
}

int List::position() const{
  return pos_cursor;
}

ListElement List::peekNext() const{
  if (num_elements == 0) {
    throw std::length_error("List: peekNext(): empty List");
  }
  if (pos_cursor == num_elements) {
    throw std::out_of_range("List: peekNext(): no element after cursor.");
  }
  return afterCursor->data;
}

ListElement List::peekPrev() const{
  if (num_elements == 0) {
    throw std::length_error("List: peekPrev(): empty List");
  }
  if (pos_cursor == 0) {
    throw std::out_of_range("List: peekPrev(): no element before cursor.");
  }
  return beforeCursor->data;
}


// Manipulation procedures

void List::clear(){
  moveFront();
  while (num_elements > 0) {
    //fprintf(stderr, "erasing...\n");
    eraseAfter();
  }
}

void List::moveFront(){
  pos_cursor = 0;
  beforeCursor = frontDummy;
  afterCursor = frontDummy->next;
}

void List::moveBack(){
  pos_cursor = num_elements;
  beforeCursor = backDummy->prev;
  afterCursor = backDummy;
}

ListElement List::moveNext(){
  if (pos_cursor == num_elements) {
    throw std::range_error("List: moveNext(): no element after cursor.");
  }
  beforeCursor = afterCursor;
  afterCursor = afterCursor->next;
  pos_cursor ++;
  return beforeCursor->data;
}

ListElement List::movePrev(){
  if (pos_cursor == 0) {
    throw std::range_error("List: movePrev(): no element before cursor.");
  }
  afterCursor = beforeCursor;
  beforeCursor = beforeCursor->prev;
  pos_cursor --;
  return afterCursor->data;
}

void List::insertAfter(ListElement x){
  Node* N = new Node(x);

  N->prev = beforeCursor;
  beforeCursor->next = N;

  N->next = afterCursor;
  afterCursor->prev = N;

  afterCursor = N;

  //does not need to increase cursor space.
  num_elements++;
}

void List::insertBefore(ListElement x){
  Node* N = new Node(x);

  N->prev = beforeCursor;
  beforeCursor->next = N;

  N->next = afterCursor;
  afterCursor->prev = N;

  beforeCursor = N;

  pos_cursor++;
  num_elements++;
}

void List::setAfter(ListElement x){
  if (num_elements == 0) {
    throw std::length_error("List: setAfter(): empty List");
  }
  if (pos_cursor == num_elements) {
    throw std::out_of_range("List: setAfter(): no element after cursor.");
  }
  afterCursor->data = x;
}

void List::setBefore(ListElement x){
  if (num_elements == 0) {
    throw std::length_error("List: setBefore(): empty List");
  }
  if (pos_cursor == 0) {
    throw std::out_of_range("List: setBefore(): no element before cursor.");
  }
  beforeCursor->data = x;
}

void List::eraseAfter(){
  if (num_elements == 0) {
    throw std::length_error("List: eraseAfter(): empty List");
  }
  if (pos_cursor == num_elements) {
    throw std::out_of_range("List: eraseAfter(): no element after cursor.");
  }
  Node* N = afterCursor;

  N->prev->next = N->next;
  N->next->prev = N->prev;

  afterCursor = N->next;
  num_elements --;

  delete N;
}

void List::eraseBefore(){
  if (num_elements == 0) {
    throw std::length_error("List: eraseBefore(): empty List");
  }
  if (pos_cursor == 0) {
    throw std::out_of_range("List: eraseBefore(): no element before cursor.");
  }
  Node* N = beforeCursor;
  N->prev->next = N->next;
  N->next->prev = N->prev;
  beforeCursor = N->prev;
  num_elements --;
  pos_cursor --;
  delete N;
}

// other functions

int List::findNext(ListElement x){

  try{
    while (moveNext() != x) {
      //dummy
    }
    return pos_cursor;
  } catch (std::range_error const&){
    return -1;
  }
}

int List::findPrev(ListElement x){

  try{
    while (movePrev() != x) {
      //dummy
    }
    return pos_cursor;
  } catch (std::range_error const&){
    return -1;
  }
}

void List::cleanup(){
  if (num_elements == 0 || num_elements == 1) { //don't need to do anything if there can't be duplicates lol
    return;
  }
  //so what we're going to do is:
  //goto front of this
  //  use node based loop for no cursor adjustment
  //if data from cursor is in SEEN (use moveBack, find prev), delete the node with a manual version of delete
  //if its not in seen then add it to SEEN
  //for the cursor stuff, maintain a "currentPos" that is incremented if an item is NOT deleted
  //if an item IS deleted
    //decrease num_elements
    //if currentPos < pos_cursor
      //decrease pos_cursor
  //fprintf(stderr, "in cleanup\n");
  List SEEN;
  Node* N;
  int currentPos = 0;
  for (N = frontDummy->next; N->next != NULL; N = N->next) {
    //fprintf(stderr, "N = %i\n", N->data);
    SEEN.moveFront();
    if (SEEN.findNext(N->data) != -1) { //we have already enocuntered this #.
      N->prev->next = N->next;
      N->next->prev = N->prev;
      num_elements --;
      //handle cursor.
      if (currentPos == pos_cursor -1) { //deleting beforeCursor
        beforeCursor = N->prev;
        pos_cursor --;
      } else if (currentPos == pos_cursor) { //deleting afterCursor
        afterCursor = N->next;
      } else if (currentPos < pos_cursor) { //deleting an element distance < -1 from cursor
        pos_cursor -= 1;
      }
      //N = nullptr; //free a bitch
      Node* temp = N->prev;
      delete N;
      N = temp;
      //fprintf(stderr, "deleterd\n" );
    } else { // we have not encountered this # yet.
      SEEN.moveFront();
      SEEN.insertBefore(N->data);
      //put N at the beginning of SEEN so that any duplicates that are right next to each other
      //get caught immediately, decreases execution time a teeny bit for long lists.
      currentPos++; //increase pos bc we aren't deleting.
    }
  }
}

List List::concat(const List& L) const{
  List C = *this;
  Node* N;

  C.moveBack();
  for (N = L.frontDummy->next; N->next != NULL; N = N->next) {
    C.insertBefore(N->data);
  }
  C.moveFront();
  return C;
}

std::string List::to_string() const{

  std::string retVal = "";
  if (num_elements == 0) {
    //retVal += "";
    return retVal;
  }
  Node* N = frontDummy->next;
  retVal += std::to_string(N->data); //we do not want to prepent leading zeroes on the first number only.
  //retVal += " "; //for inserting a dummy space between chunks

  for (N = frontDummy->next->next; N->next != nullptr; N = N->next) { // gets every node except the first.
    if (N->data == 0) {
    }
    //std::cout << "data: " << N->data << '\n';
    std::string chunk = std::to_string(N->data);
    if (chunk.length() < POWER) {
      chunk.insert(0, POWER - chunk.length(), '0');  //prepend leading zeros.
    }
    retVal += chunk;
    //retVal += " "; //for inserting a dummy space between chunks
  }

  return retVal;
}

bool List::equals(const List& R) const{
  bool eq = false;
  Node* A = nullptr;
  Node* B = nullptr;
  if (this->num_elements == 0 && R.length() == 0) {
    return true;
  }
  eq = (this->num_elements == R.length());
  A = this->frontDummy->next;
  B = R.frontDummy->next;
  while (eq && A->next != nullptr) {
    eq = (A->data == B->data);
    A = A->next;
    B = B->next;
  }
  //std::cout << "done with eq" + std::to_string(eq) << '\n';
  return eq;
}

int List::compare(const List& R) const{
  int eq = 0;
  Node* A = nullptr;
  Node* B = nullptr;
  if (this->num_elements == 0 && R.length() == 0) {
    return 0;
  }
  if (this->num_elements == R.length()) {
    eq = 0;
  } else if (this->num_elements > R.length()) {
    return 1;
  } else if (this->num_elements < R.length()) {
    return -1;
  }

  A = this->frontDummy->next;
  B = R.frontDummy->next;
  while (eq == 0 && A->next != nullptr) {
    //std::cout << " " << A->data << "  " << B->data << '\n';
    if (A->data > B->data) {
      //std::cout << "bigger" << '\n';
      return 1;
    } else if (A->data < B->data) {
      //std::cout << "smaller" << '\n';
      return -1;
    } else {
      A = A->next;
      B = B->next;
    }
  }
  return -2;

}


//overloaded Operators

std::ostream& operator<<( std::ostream& stream, const List& L ){
  return stream << L.List::to_string();
}

bool operator==(const List& A, const List&B){
  return A.List::equals(B);
}

List& List::operator=(const List& L){
  if (this != &L) { // not self assignment
    List temp = L;
    std::swap(frontDummy, temp.frontDummy);
    std::swap(backDummy, temp.backDummy);
    std::swap(beforeCursor, temp.beforeCursor);
    std::swap(afterCursor, temp.afterCursor);
    std::swap(num_elements, temp.num_elements);
    std::swap(pos_cursor, temp.pos_cursor);
  }
  return *this;
}


//helpers

void negateList(List& L) {
  L.moveFront();
  try {
    while (L.moveNext()) {
      L.setBefore(L.peekPrev() * -1);
    }
  } catch (std::range_error const&){
    //grah
  }
}
//takes a list and normalizes it to BASE, returning the sign of the list.
int normalizeList(List& L){
  if (L.length() == 0) { //nothing to do here
    return 0;
  }
  int polarity = 1;
  //if the front number is negative, flip the whole list.
  L.moveFront();
  if (L.peekNext() < 0) {
    polarity = -1;
    negateList(L);
  }

  L.moveBack();

  long x;
  while (true) {
    try{
      L.movePrev();
    } catch (std::range_error const&){ //at front of list
      //std::cout << "range errored" << '\n';
      break;
    }
    x = L.peekNext();
    //std::cout << "x = " << x << "(base =)" << BASE << '\n';
    std::string rightSide;
    std::string leftSide;
    if (x >= BASE) { //too big
        //std::cout << "too big: " << x << "  " << BASE << '\n';
        rightSide = std::to_string(x);
        while (rightSide.length() > POWER) { //while the number of digits is larger than the max length
          leftSide += rightSide[0]; //add the frontmost digits of right side to back end of left leftSide
          rightSide.erase(rightSide.begin(), rightSide.begin()+1);
        }
        //std::cout << "left: " << leftSide << '\n';
        //std::cout << "right: " << rightSide << '\n';

        L.setAfter(stol(rightSide));
        try {
          L.setBefore(L.peekPrev() + stol(leftSide));
        }
        catch (std::out_of_range const&) { //if we're at the front of the list and trying to set the node in front of it.
          L.insertBefore(stol(leftSide));
        }
        x = L.peekNext();
      }

    if (x < 0) { //too small
        //std::cout << "too small: " << x << '\n';
        //std::cout << "/* message */" << '\n';
        try{
          int basesToFlip = (x / BASE)  + 1;
          L.setBefore(L.peekPrev() - basesToFlip);
          L.setAfter((x + BASE*basesToFlip)); //make it positive and within range.
          //std::cout << "used " << basesToFlip << " bases to turn into " << (x + BASE*basesToFlip) << '\n';
        }

        catch (std::out_of_range const&) { //if we're at the front of the list and trying to set the node in front of it.
          L.setAfter(x * -1);
          polarity = -1;
        }
        x = L.peekNext();
      }
  }
  L.moveFront();
  //remove all zero's at the head of the list.
  try{
    while (L.moveNext() == 0) {
      //std::cout << "deleting: " << L.peekPrev() << '\n';
      L.eraseBefore();
    }
  } catch (std::range_error const&){
    //done looping
  }


  if (L.length() == 0) { //if we ended up removing all list elements while getting rid of zeroes.
    //std::cout << L << '\n';
    polarity = 0;
  }
  //std::cout << "pol: " << polarity << '\n';
  return polarity;
}
//sumList()
//overwrites S with A + sgn*B (considered as vectors)
//used by  both sum and sub.
void sumList(List& S, List A, List B, int sgn) {
  S.clear();
  if (A.length() == 0 && B.length() == 0) { //two empty lists
    return;
  }
  List CA = A;
  List CB = B;
  // std::cout << "CA: " << CA << '\n';
  // std::cout << "CA: " << CB << '\n';
  if (sgn == -1) {
    if (CA == CB) {
      S.clear();
      return;
    }
    negateList(CB);
  }
  CA.moveBack();
  CB.moveBack();
  bool addedA = true;
  bool addedB = true;
  do {
    long L1 = 0;
    long L2 = 0;
    try{
      L1 = CA.movePrev(); //advance through list A
    } catch (std::range_error const&){ //at front of list
      addedA = false;
    }
    try{
      L2 = CB.movePrev(); //advance thru B
    } catch (std::range_error const&){ //at front of list
      addedB = false;
    }
    if (addedA || addedB) {
      //std::cout << "inserting: " << L1 + L2 << '\n';
      S.insertAfter(L1 + L2);
    }
  } while (addedA || addedB);
  //do not normalize in here
}

void scalarMultList(List& L, ListElement M){
  L.moveFront();
  try {
    while (L.moveNext()) {
      L.setBefore(L.peekPrev() * M);
    }
  } catch (std::range_error const&){
    //grah
  }
}

void shiftList(List& L, int p){
  L.moveBack();
  for (int i = 0; i < p; i++) {
    L.insertAfter(0);
  }
  //std::cout << "in shiftlist: " << L << '\n';
}
