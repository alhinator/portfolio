/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA2
* Graph.c
* Graph ADT implementation
*********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

#include "List.h"
#include "Graph.h"


//exportable types
typedef struct GraphObj{
  List* vertices; //an array of lists. NOTE: don't use index 0, create the array size n+1
    //each index in vertices will contain a list that contains the neighbors of that vertex.
  int* colors; //an array of ints where the value at index i is the color of vertex i
  int* parents; //for a given index i in parents, the value at i is the index of i's parent.
  int* distance; //in a given index i, the value is the distance from the most recent "source" to i.
  int order; // the number of vertices in this list
  int source; // the vertex most recently defined as the "source"
  int edges; // doing this for ease of access
  int arcs; // doing this for ease of access

}GraphObj;

// ----------- Constructors/Destructors -------------------
Graph newGraph(int n){ //allocates and returns space for a new graph. n ins the number of vertices.
  Graph retGraph = malloc(sizeof(GraphObj));
  assert(retGraph != NULL);
  retGraph-> order = n;
  retGraph->vertices = malloc(sizeof(List) * (n+1)); //makes space for pointers to N lists an leave 0 empty
  retGraph->colors = malloc(sizeof(int) * (n+1)); // makes space for N colors leave 0 empty
  retGraph->parents = malloc(sizeof(int) * (n+1));
  retGraph->distance = malloc(sizeof(int) * (n+1));
  retGraph->source = NIL; // undefined.
  retGraph->edges = 0;
  retGraph->arcs = 0;

  //now init our lists
  for (size_t i = 1; i <= n; i++) { // leave 0 empty
    retGraph->vertices[i] = newList(); //init lists in vertices
  }
  for (size_t i = 1; i <= n; i++) {
    retGraph->parents[i] = NIL; // init parents to NIL
  }
  for (size_t i = 1; i <= n; i++) {
    retGraph->distance[i] = INF; // init distances to INF
  }

  return retGraph;
}
void freeGraph(Graph* pG){
  assert(pG != NULL && *pG != NULL);
  free((*pG)->distance);
  free((*pG)->parents);
  free((*pG)->colors);
  //free all the primitive arrays
  //fprintf(stderr, "%i\n", (*pG)->order);
  for (size_t i = 1; i <= (*pG)->order; i++) { //free the lists
    freeList(&(*pG)->vertices[i]);
    //fprintf(stderr, "%s\n", "freed list");
  }

  free((*pG)->vertices); //free the array vertices
  free(*pG); // free the graph.
  pG = NULL;

  return;
} //frees a graph and all its components

// ----------- access functions ---------------------------

int getOrder(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getOrder() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->order;
}
int getSize(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getSize() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  //this is mega simplified from before lol. just gonna require an extra line in addEdge and addArc.
  return (G->edges + G->arcs);
}
int getSource(Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getSource() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->source;
}
int getParent(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getParent() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->parents[u];
}
int getDist(Graph G, int u){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getDist() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  return G->distance[u];
}
void getPath(List L, Graph G, int u){
// appends to the List L the vertices of a shortest path
  //in G from source to u, or appends to L the value NIL if no such path exists
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | getPath() was called on a NULL graph pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (L == NULL) {
    fprintf(stderr, "Graph ADT | getPath() was called on a NULL list pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || u < 1)  {
    fprintf(stderr, "Graph ADT | getPath() destination parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  if (G->source == NIL) {
    fprintf(stderr, "Graph ADT | getPath() source is NIL.\n");
    exit(EXIT_FAILURE);
  }
  //case 1: no path
  if (G->distance[u] == INF) {
    append(L, NIL);
    return;
  }
  //getPath walks from u to source via parent
  int p = u;
  int counter = 0;
  //begin with the first parent.
  //due to the append requirement to L, the cursor gets a litle funky.
  append(L, p); // the end of the path.
  moveBack(L);
  //cursor is pointing to the end of the list, which is the end of the path.
  while (G->parents[p] != NIL) {
    p = G->parents[p]; //move to prev step
    insertBefore(L, p); //insert the previous step in the path before the current step in the path.
    movePrev(L); //move cursor to prev step
    counter++; //for the assert at the end.
  }
  assert(counter == G->distance[u]); // make sure we found path of the same distance.

}

//helper functions
void addListSorted(List L, int n){
  // start at the beginning of the list and walk it (order N time unfortunately)
  // until we find an entry that is larger than v. then we insertBefore
  if (L == NULL) {
    fprintf(stderr, "Graph ADT | addListSorted() null list pointer.\n");
    exit(EXIT_FAILURE);
  }
  //first case we should check is if the list is empty.
  if (length(L) <= 0) {
    append(L, n); // can just slap it on.
    return; ///and gtfo
  }
  moveFront(L);

  while (index(L) >= 0 && get(L) < n) {
    //fprintf(stderr, "in addListSorted search loop\n");
    moveNext(L);
  }
  if (index(L) == -1){ //we ran off the back
    append(L, n);
  } else if (get(L) == n) { //already has
    //fprintf(stderr, "Graph ADT | addListSorted() entry already exists.\n");
    //exit(EXIT_FAILURE); //do nothing as directed by Ed Discussion.
    return;
  } else { //found right spot
    insertBefore(L, n);
  }
  return;
}

// ------------ manipulation procedures ---------------------
void makeNull(Graph G){ //deletes all edges of G, restoring it to its original (no edge) state.
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | makeNull() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  for (size_t i = 1; i <= G->order; i++) { //revert the lists of edges
    clear(G->vertices[i]);
  }
  G->edges = 0;
  G->arcs = 0;
return;
}
void addEdge(Graph G, int u, int v){
  //going to insert 'v' into vertices[u] at the correct point.
  // then insert u into vertices[v] a the correct point as it is an edge
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || v > getOrder(G) || u < 1 || v < 1)  {
    fprintf(stderr, "Graph ADT | addEdge() vertex u or v parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //add v to u addListSorted
  addListSorted(G->vertices[u], v);
  //and add the opposide
  addListSorted(G->vertices[v], u);
  //lets go!

  //increment edges by one
  G->edges++;
  return;
}
void addArc(Graph G, int u, int v){
  //going to insert 'v' into vertices[u] at the correct point.
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (u > getOrder(G) || v > getOrder(G) || u < 1 || v < 1)  {
    fprintf(stderr, "Graph ADT | addEdge() vertex u or v parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //add v to u addListSorted
  addListSorted(G->vertices[u], v);
  // add Arc we only insert ONCE! arcs ARE unidirectional.
  //lets go!
  //increment arcs by one
  G->arcs++;
  return;
}
void BFS(Graph G, int s){ //breadth first sussy
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | BFS() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (s > getOrder(G) || s < 1)  {
    fprintf(stderr, "Graph ADT | BFS() source parameter out of bounds.\n");
    exit(EXIT_FAILURE);
  }
  //discovers every vertex reachable from vertex s.
    //step 1: setup the colors, distances, and parents.
  //fprintf(stderr, "top of BFS\n");
  for (int i = 1; i <= getOrder(G); i++) {
    G->colors[i] = WHITE;
    G->distance[i] = INF;
    G->parents[i] = NIL;
  }
    //step 2: discover the source s by making it gray, set distance to itself as 0.
    //it's parent is already nil.
  G->source = s;
  G->colors[s] = GRAY;
  G->distance[s] = 0;
    //step 3: create an empty queue and add s to the queue.
  List Q = newList();
  append(Q, s);
    //step 4: main loop, which will discover until the queue is empty.
  while (length(Q) > 0) {
    //fprintf(stderr, "top of Queue\n");
      //part A: dequeue x
    moveFront(Q);
    int x = get(Q);
    deleteFront(Q);
    //fprintf(stderr, "dequeueing %i\n", x);

      //part B: loop through the adjacency list of x.
      //make a temp pointer.
    List ADJ = G->vertices[x];
    moveFront(ADJ);
    while (length(ADJ) > 0 && index(ADJ) >= 0) {
        //part C: inside the adjacency loop
        //get y, which is a neighbor of x.
        int y = get(ADJ);
        if (G->colors[y] == WHITE) { //if y is undiscovered
          G->colors[y] = GRAY; //discover y
          G->distance[y] = G->distance[x] + 1;
           //the distance from the source to y is one more than the previous neighbor.
           //this is okay to do in BFS beause it touches all neighbors on the same level before increasing the distance
          G->parents[y] = x; //set x as the parent of y.
          append(Q, y); // enqueue y to the BFS queue.
          //fprintf(stderr, "enqueuing %i\n", y);
        }
        //end of adj loop: increase position in adjacency list
        moveNext(ADJ);
    }
    //we have visited all neighbors of X at this point.
    G->colors[x] = BLACK;
  }
  //end of BFS!
  freeList(&Q);
}



// ----------- other functions ------------------
void printGraph(FILE* out, Graph G){
  if (G == NULL) {
    fprintf(stderr, "Graph ADT | printGraph() was called on a NULL pointer.\n");
    exit(EXIT_FAILURE);
  }
  if (out == NULL) {
    fprintf(stderr, "Graph ADT | addEdge() bad output file.\n");
    exit(EXIT_FAILURE);
  }

  //what we need to do here is: for every index from 1-n,
    //print the label of that index, colon, space, then every number in that list separated by space.

  for (int i = 1; i <= getOrder(G); i++) {
    fprintf(out, "%i: ", i); //no \n yet
    printList(out, G->vertices[i]); //can just use this baby
  }
}










//hi =)
