#include "mathlib.h"
#include "stdio.h"
#include "math.h" //THIS IS ONLY FOR PI

#define _USE_MATH_DEFINES
#define Epsilon 1e-10

static double Exp(double x){
  double t = 1.0;
  double y = 1.0;
  for (double k = 1.0; t > Epsilon; k += 1.0){
    t *= x / k;
    y += t;
  }
  return y;
}

double Exponent(double x, double k){ //helper function, fixed
  double retVal = 1;
  for (double i=0;i<k;i++){
    retVal *=x;
  }
  return retVal;
}

double Factorial(double k){ //helper function, fixed
  double retVal = 1;
  for (int i = k; i > 0; i--){
    retVal *= i;
  }
  return retVal;
}

double Abs(double x){//helper function
  if (x < 0){return (x*-1);}
  return x;
}

long double Sqrt(long double x){ //helper function
  long double f = 1.0;
  long double sqEpsilon = 1e-12;
  while (x > 1){
    x /= 4.0;
    f *= 2.0;
  }
  long double m, lo = 0.0, hi = (x < 1) ? 1 : x;
  do {
    m = (lo + hi) / 2.0;
    if (m * m < x){
      lo = m;
    } else {
      hi = m;
    }
  } while ( Abs(lo - hi) > sqEpsilon);
  return f * m;
}

double my_sin(double x){//my_sin, updated to use helper funcs
  double frac = 0;
  double polar = 1;
  for(double k = 1; 1 == 1; k+=2){ // start at 1 because the zeroth element is 2n+1 so k should be 1. we are substituting k for 2n+1.
    double numerAdd = Exponent(x,k); //we set numerator to x^k.
    double denomAdd = Factorial(k); //we set denominator to k!
    double addVal = polar*numerAdd/denomAdd;
    frac += addVal; //add to fraction
    polar *= -1; //invert polarity for next time around
    if (Abs(addVal) < Epsilon){ //break out of the loop once the additive is insignificant enough
      return frac;
    }
  }
}

double my_cos(double x){ //ok we can basically copy most of sin lmao just change starting point //updated to use helper funcs
  double frac = 0;
  double polar = 1;
  for(double k = 0; 1 == 1; k+=2){ // start at 0 because the zeroth element is 2n so k should be 0. we are substituting k for 2n.
    double numerAdd = Exponent(x,k); //we set numerator to x^k.
    double denomAdd = Factorial(k); //we set denominator to k!
    double addVal = polar*numerAdd/denomAdd;
    frac += addVal; //add to fraction
    polar *= -1; //invert polarity for next time around
    if (Abs(addVal) < Epsilon){ //break out of the loop once the additive is insignificant enough
      return frac;
    }
  }
}

double my_arcsin(double x){ // thank god the updated version fixed the bug somehow lmaooooooooooooo
  double zn = 0; //here's our starting point, we don't need polarity for this one
  double znlast = 0;
  while(1 == 1){
    double partA = znlast;
    double partB = (my_sin(znlast) - x);
    double partC = (my_cos(znlast));
    zn = partA - (partB/partC);
    if (Abs(zn-znlast) < Epsilon){
      return zn;
    }
    znlast = zn;
  }
}

double my_arccos(double x){ // fixed
  return ((M_PI/2) - my_arcsin(x));
}

double my_arctan(double x){
  return (my_arcsin(x / Sqrt(Exponent(x,2) + 1)));
}

double my_log(double x){
  double curr = 1.0; // starting point for x_k
  double y = x;
  while (1 == 1){
    double next = curr + ((y- Exp(curr))/Exp(curr));
    if (Abs((Exp(curr)-y)) < Epsilon){
      return curr;
    }
    curr = next;
  }
}
