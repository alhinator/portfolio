
`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA1
* README.md
* Readme file
*********************************************************************************`

### Included Files:

*List.c* contains an implementation of a doubly-linked integer list and various access, manipulation, and miscellaneous operations.
*List.h* provides an interface for external files to interact with *List.c*
*ListTest.c* contains tests for the functions contained within *List.c*
*Lex.c* uses the List implementation and insertion sort to alphabetically sort a text file, line by line.
*Makefile* provides various options for compiling the *.c* and *.h* files.
