#include "node.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <inttypes.h>

struct Stack {
  uint32_t capacity;
  uint32_t c_key;
  Node **stack;
};

struct Stack *stack_create(uint32_t capacity){
  struct Stack *new_stack = (struct Stack*) malloc(sizeof(struct Stack));
  if (new_stack == NULL) {
    printf("Stack create malloc failed.\n");
    return NULL;
  }
  new_stack->capacity = capacity;
  new_stack->c_key = 0;
  new_stack->stack = (Node **) calloc(capacity, sizeof(Node *));
  if (new_stack->stack == NULL) {
    printf("Stack create calloc failed.\n");
    return NULL;
  }
  return new_stack;
}

void stack_delete(struct Stack **s){
  for (size_t i = 0; i < (*s)->capacity; i++) {
    if ((*s)->stack[i] != NULL) {
      node_delete(&(*s)->stack[i]);
    }
  }
  free((*s)->stack);
  (*s)->stack = NULL;
  free(*s);
  *s = NULL;
  return;
}

bool stack_empty(struct Stack *s){
  return s->c_key == 0;
}

bool stack_full(struct Stack *s){
  return (s->c_key) == s->capacity;
}

uint32_t stack_size(struct Stack *s){
  return s->c_key;
}

bool stack_push(struct Stack *s, Node *n){
  if (stack_full(s)) { //if stack is full we can't add another.
    return false;
  }
  //current position to insert at is c_key
  s->stack[s->c_key] = n; // insert at spot
  s->c_key ++; //increment position by one.
  return true;
}

bool stack_pop(struct Stack *s, Node **n){
  if (stack_empty(s)) { //if stack is empty we can't grab anything.
    return false;
  }
  s->c_key --; //drop it down to the position that was last grabbed from
  *n = s->stack[s->c_key]; //grab the most recent thing into the return value
  s->stack[s->c_key] = NULL; //null out the position so its available to put smth into
  return true;
}

void stack_print(struct Stack *s){
  if (s == NULL || stack_empty(s)) {
    printf("This stack is empty.\n");
    return;
  }
  for (size_t i = 0; i < s->c_key; i++) {
    node_print(s->stack[i]);
  }
}
