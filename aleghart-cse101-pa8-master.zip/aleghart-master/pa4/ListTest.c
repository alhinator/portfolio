/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA4
* ListTest.c
* List ADT test harness
*********************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <stdbool.h>

//#include "Matrix.h"
#include "List.h"

//#include "List.c"
typedef struct CellObj* Cell;

typedef struct CellObj{ //changing this to cell bc the list is called entries. easier to remember.
  int column;
  double value;
} CellObj;

Cell newCell(int column, double value){
  Cell C = malloc(sizeof(CellObj));
  C->column = column;
  C->value = value;
  return C;
}




int main(int argc, char* argv[]) {



  List L = newList();

  //Cell C = newCell(5, 6);

  //freeCell(&C);
  append(L, newCell(5, 6));
  moveFront(L);
  //Cell C2 = *(Cell*)get(L);
  //freeCell(&*(Cell*)get(L));

  freeList(&L);

  return 0;
}
