/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA2
* GraphTest.c
* Test harness for Graph ADT functions
*********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>

#include "Graph.h"



int main(int argc, char const *argv[]) {

  Graph G = newGraph(7);
  fprintf(stderr, "made new graph \n");
  // addArc(G, 1, 2);
  // addArc(G, 1, 3);
  // addArc(G, 1, 4);
  // assert(getOrder(G) == 4);
  // assert(getSize(G) == 3);
  //fprintf(stderr, "added arc \n");
  // addEdge(G, 2, 3);
  // addEdge(G, 1, 1);

  printGraph(stdout, G);
  // assert(getSize(G) == 5);

  //makeNull(G);
  addEdge(G, 1, 4);
  addEdge(G, 1, 5);
  addEdge(G, 5, 5);
  addEdge(G, 2, 3);
  addEdge(G, 2, 6);
  addEdge(G, 3, 7);
  addEdge(G, 6, 7);



  BFS(G, 2);
  List L = newList();
  fprintf(stderr, "%i\n", getDist(G, 7));
  assert(getDist(G, 7) == 2);
  getPath(L, G, 7);
  printList(stdout, L);

  printGraph(stdout, G);
  freeGraph(&G);
  return 0;
}
