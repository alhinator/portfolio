#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

struct BitVector {
  uint32_t length;
  uint64_t *vector;
};

void bv_print(struct BitVector *bv) {
  //fprintf(stderr, "%" PRIu32 "\n", bv->length);
  for (size_t i = 0; i < (bv->length/64+(!!(bv->length%64))); i++) {
    uint64_t current_vector = bv->vector[i];
    //this shit is really confusing so im expanding it out so i get it
    //ok so like what we need to do is print each bit of the current_vector
    //going from least significant to most significant
    for (int i = 0; i < 64; i++) {
      //i is going from 0 to 63. we are looping thru a 64 bit int.
      //basically the gist is we print '1' if the farthest right bit is 1 after
      //a right shift. the shift is determined by i since we are starting at
      //the right side, aka the least significant bit.
    fprintf(stderr, "%lu", (current_vector>>i) & 0x01);
    }
    fprintf(stderr, "\n");
    //after we finish printing the current vector we print a newline
    //and go to the next vector
  }
  return;
}

struct BitVector *bv_create(uint32_t length) {
  struct BitVector *new_bv = malloc(sizeof(struct BitVector));
  if (new_bv == NULL) {
    fprintf(stderr, "malloc bv_create failed\n");
    return NULL;
  }
  new_bv->length = length;
  new_bv->vector = calloc((length/64)+1, sizeof(uint64_t));
  if (new_bv->vector == NULL) {
    fprintf(stderr, "calloc bv_create vector failed\n");
    return NULL;
  }
  //bv_print(new_bv);
  return new_bv;
}


void bv_delete(struct BitVector **bv) {
  free((*bv)->vector);
  (*bv)->vector = NULL;
  free(*bv);
  bv = NULL;
  return;
}

uint32_t bv_length(struct BitVector *bv) { return bv->length; }

void bv_set_bit(struct BitVector *bv, uint32_t i) {
  //bv_print(bv);
  bv->vector[(i / 64)] |= (1UL << (i % 64));
  //bv_print(bv);
  return;
}

void bv_clear_bit(struct BitVector *bv, uint32_t i) {
  bv->vector[(i / 64)] &= ~(1UL << (i % 64));
  return;
}

uint8_t bv_get_bit(struct BitVector *bv, uint32_t i) {
  return (bv->vector[(i / 64)] & (1UL << (i % 64))) >> (i % 64);
}
