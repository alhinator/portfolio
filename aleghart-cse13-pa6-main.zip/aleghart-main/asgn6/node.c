#include <stdio.h>
#include <stdlib.h>

struct Node {
  char *oldspeak;
  char *newspeak;
  struct Node *next;
  struct Node *prev;
};
void node_print(struct Node *n){
  if (n->newspeak != NULL) {
    printf("%s -> %s\n", n->oldspeak, n->newspeak);
  }else{
    printf("%s\n", n->oldspeak);
  }
  return;
}

struct Node *node_create(char *oldspeak, char *newspeak){
  struct Node *new_node = (struct Node *)malloc(sizeof(struct Node));
  if (oldspeak != NULL) { //this occurs at a sentinel node
    size_t oldlen = 1;
    for (size_t i = 0; oldspeak[i] != '\0'; i++){
      oldlen++; // account for \0 that we miss
    }
    new_node->oldspeak = (char*)calloc(oldlen, sizeof(char));
    for (size_t i = 0; i < oldlen; i++) {
      new_node->oldspeak[i] = oldspeak[i];
    }
  }else{
    new_node->oldspeak = NULL;
  }
  if (newspeak != NULL) { // this occurs on a badspeak node
    size_t newlen = 1;
    for (size_t i = 0; newspeak[i] != '\0'; i++){
      newlen++; // account for \0 that we miss
    }
    new_node->newspeak = (char*)calloc(newlen, sizeof(char));
    for (size_t i = 0; i < newlen; i++) {
      new_node->newspeak[i] = newspeak[i];
      //printf("%c now = %c\n", new_node->newspeak[i], newspeak[i]);
    }
  }else{
    new_node->newspeak = NULL;
  }
  //node_print(new_node);
  return new_node;
}


void node_delete(struct Node **n){
  //printf("in node delete\n");
  if ((*n)->next != NULL) {//this will occur when deleting the tail of the list
    (*n)->next->prev = (*n)->prev;
  }
  if ((*n)->prev != NULL) {//this will occur when deleting the head of the list
    (*n)->prev->next = (*n)->next;
  }
  if ((*n)->oldspeak != NULL) {
    free((*n)->oldspeak);
    (*n)->oldspeak = NULL;
  }  if ((*n)->newspeak != NULL) {
    free((*n)->newspeak);
    (*n)->newspeak = NULL;
  }
  free(*n);
  n = NULL;
  return;
}
