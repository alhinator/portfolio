/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* BigInteger.cpp
* BigInteger ADT implementation C++
*********************************************************************************/

#include "List.h"

#include "BigInteger.h"

#include <iostream>
#include <string>

#include <regex>

#define POWER 9
#define BASE 1000000000

BigInteger::BigInteger(){ //zero-state constructor
  signum = 0;
  digits = List();
}

BigInteger::BigInteger(long x){ //zero-state constructor
  if (x == 0) {
    signum = 0;
  } else if (x > 0 ) {
    signum = 1;
  } else {
    signum = -1;
    x *= -1;
  }

  digits = List();

  std::string val = std::to_string(x);
  //std::cout << val << '\n';
  std::string buffer = "";
  int LEN = val.length();
  for (int i = LEN; i >= 0; i--) { //start at the end of the string and work towards the left.

    buffer.insert(0, 1, val[i]); //prepend the current digit to buffer
    //std::cout << val[i] << '\n';

    if ((i != LEN && (LEN - i) % POWER == 0) || i == 0) {
      //if we have passed over POWER digits, or hit the beginning of the string,
      //  longify the string, and add it to the list.
      //std::cout << "adding: " << buffer << '\n';
      if (!buffer.empty()) {
        digits.insertAfter(std::stol(buffer));
      }
      buffer = "";
    }
  }

}

BigInteger::BigInteger(std::string s){
  if (s.empty()) {
    throw std::invalid_argument("BigInteger: Constructor: empty string");
  }
  if (!std::regex_match(s, std::regex("^[\\+-]?[0-9]+"))) { //baby's first regex
    throw std::invalid_argument("BigInteger: Constructor: non-numeric string");
  }
  //now we've confirmed it's a valid string, time to parse.

  if (std::regex_match(s, std::regex("^[\\+-]?[0]+"))) {
    //if the string is just a bunch of friggin zeroes
    signum = 0;
  } else if (s[0] == '-' ) {
    signum = -1;
  } else {
    signum = 1;
  }

  std::string buffer = "";
  int LEN = s.length();
  for (int i = LEN; i >= 0; i--) { //start at the end of the string and work towards the left.
    if (isdigit(s[i])) { //if number
      buffer.insert(0, 1, s[i]); //prepend the current digit to buffer
    }

    //std::cout << val[i] << '\n';

    if ((i != LEN && (LEN - i) % POWER == 0) || i == 0) {
      //if we have passed over POWER digits, or hit the beginning of the string,
      //  longify the string, and add it to the list.
      //std::cout << "adding: " << buffer << '\n';
      if (!buffer.empty()) {
        digits.insertAfter(std::stol(buffer));
      }
      buffer = "";
    }
  }
  normalizeList(digits); //just throwing this in here to get rid of extra zeroes at the front.
}

BigInteger::BigInteger(const BigInteger &N){
  signum = N.signum;
  digits = N.digits;
}

//access Functions

int BigInteger::sign() const{
  return signum;
}

int BigInteger::compare(const BigInteger& N) const{ //god this is so messy
  //start with simple:
  if ((this->signum == 0 && N.signum == 0) || this->digits.equals(N.digits)) { //lists are both zero or both equal.
    return 0;
  }
  if (this->signum > N.signum) { //larger based on polarity alone
    return 1;
  }
  if (this->signum < N.signum) { // smaller based on polarity alone
    return -1;
  }
  if (this->signum == N.signum) { //same polarity.
    int ret = this->digits.compare(N.digits);
    //std::cout << "ret: "<< ret << '\n';
    if (this->signum == -1) { // if a negative number is "smaller" than another negative number, it is actually larger - and vice versa.
      ret *= -1;
    }
    return ret;
  }
  std::cout << "how did we get here?" << '\n';
  return -2;
}

// Manipulation procedures
void BigInteger::makeZero(){
  signum = 0;
  digits.clear();
}

void BigInteger::negate(){
  signum *= -1;
}



//other functions

BigInteger BigInteger::add(const BigInteger&N) const{
  //std::cout << "A: " << *this << '\n';
  //std::cout << "B: " << N << '\n';
  BigInteger B;
  List L;
  if (this->signum == 1 && N.signum == 1) { //adding two positives.
    sumList(L, this->digits, N.digits, 1);
    //std::cout << "pre normalize: " << L << '\n';
    B.signum = normalizeList(L); //should always end  up being 1 or zero.
  }
  else if (this->signum == 1 && N.signum == -1){ //subtract list two from list one.
    sumList(L, this->digits, N.digits, -1);
    B.signum = normalizeList(L); //could be one, could be negative one, could be zero.
  }
  else if (this->signum == -1 && N.signum == 1) { //adding pos to neg is same as subtracting list one from list two.
    sumList(L, N.digits, this->digits, -1);
    B.signum = normalizeList(L); // same as abobe
  }
  else if (this->signum == -1 && N.signum == -1){ //negative to negative
    sumList(L, this->digits, N.digits, 1);
    B.signum = normalizeList(L) * -1; //when the list goes in, it should evaluate to positive or zero. the resulting signum should always be zero or -1.
  }
  B.digits = L;
  //std::cout << "rsult: " << B << '\n';
  return B;
}

BigInteger BigInteger::sub(const BigInteger&N) const{
  BigInteger B;
  List L;

  if (this->signum == 1 && N.signum == 1) { //subtracting two positives.
    fprintf(stderr, "subtracting pos and pos normally\n");
    sumList(L, this->digits, N.digits, -1);
    std::cout << "before normalize:" << L << '\n';
    B.signum = normalizeList(L); //can be 1, -1, or 0.
  }
  else if (this->signum == 1 && N.signum == -1){ //add list two to list one.
    sumList(L, this->digits, N.digits, 1);
    B.signum = normalizeList(L); //should always be zero or one.
  }
  else if (this->signum == -1 && N.signum == 1) { //negative to negative.
    sumList(L, this->digits, N.digits, 1);
    B.signum = normalizeList(L) * -1; //when the list goes in, it should evaluate to negative or zero. the resulting signum should always be zero or 1.
}
  else if (this->signum == -1 && N.signum == -1){ //adding a positive list to a negative list.
    sumList(L, N.digits, this->digits, -1);
    B.signum = normalizeList(L); //can be any three.
  }
  B.digits = L;
  return B;
}

BigInteger BigInteger::mult(const BigInteger&N) const{
  BigInteger R;
  //zero-case checks.
  if (this->signum == 0 || N.signum == 0) {
    return R; //0 times anything is 0
  }
  List cumSum; //cumulative sum of the multiplication.
  List A = this->digits;
  List B = N.digits;
  B.moveBack();
  int iters = 0;
  List multy;
  try {
    while (true) { //loop through all indices of list 2 from right to left.
      ListElement grah = B.movePrev();
      //std::cout << "grah on B: " << grah << '\n';
      //std::cout << "before operation, cumsum is: " << cumSum << '\n';

      multy = A;
      scalarMultList(multy, grah);// multiply a copy of A by the current index of B.
      shiftList(multy, iters);
      //std::cout << "multy, after shift, is: " << multy << '\n';
      normalizeList(multy);
      //std::cout << "multy, after normalize, is: " << multy << '\n';

      sumList(cumSum, multy, cumSum, 1);
      //std::cout << "after operation, cumsum is: " << cumSum << '\n';
      iters++;
    }
  } catch (std::range_error const&){ //done looping
    normalizeList(cumSum);
    R.digits = cumSum;
    if (this->signum == 1 && N.signum == 1) { //adding two positives.
      R.signum = 1; //should always end  up being 1.
    }
    else if (this->signum == 1 && N.signum == -1){ //subtract list two from list one.
      R.signum = -1; //should always be -1
    }
    else if (this->signum == -1 && N.signum == 1) { //adding pos to neg is same as subtracting list one from list two.
      R.signum = -1; // same as abobe
    }
    else if (this->signum == -1 && N.signum == -1){ //negative to negative
      R.signum = 1; //should always be 1.
    }
  }

  return R;
}

std::string BigInteger::to_string() {
  std::string retVal;
  if (this->signum == 0) {
    return "0";
  } else if (this->signum == -1) {
    retVal = "-";
  } else {
    //retVal = "+";
  }
  retVal += this->digits.to_string();
  return retVal;
}


//overloaded ops

std::ostream& operator<<( std::ostream& stream, BigInteger N ){
  return stream << N.BigInteger::to_string();
}

bool operator==( const BigInteger& A, const BigInteger& B ){
   return (A.digits.equals(B.digits) && A.signum == B.signum);
 }

bool operator<( const BigInteger& A, const BigInteger& B ){
   return (A.compare(B) == -1);
 }

bool operator>( const BigInteger& A, const BigInteger& B ){
   return (A.compare(B) == 1);
 }

bool operator<=( const BigInteger& A, const BigInteger& B ){
   int r = A.compare(B);
   return (r == 0 || r == -1);
 }

bool operator>=( const BigInteger& A, const BigInteger& B ){
   int r = A.compare(B);
   return (r == 0 || r == 1);
 }

BigInteger operator+( const BigInteger& A, const BigInteger& B ){
   return A.add(B);
 }

BigInteger operator+=( BigInteger& A, const BigInteger& B ){
   A = A.add(B);
   return A;
}

BigInteger operator-( const BigInteger& A, const BigInteger& B ){
   return A.sub(B);
}

BigInteger operator-=( BigInteger& A, const BigInteger& B ){
   A = A.sub(B);
   return A;
}

BigInteger operator*( const BigInteger& A, const BigInteger& B ){
   return A.mult(B);
}

BigInteger operator*=( BigInteger& A, const BigInteger& B ){
   A = A.mult(B);
   return A;
}
