#include "stdio.h"
#include "unistd.h"
#include "stdlib.h"
#include <stdint.h>
#include "stdbool.h"
#include <inttypes.h>
#include "stats.h"

uint32_t l_child(uint32_t n){ //that's an L. Left. left child.
  return (2 * n) + 1;
}

uint32_t r_child(uint32_t n){//right child
  return (2 * n) + 2;
}

uint32_t parent(uint32_t n){//parent element
  return (n - 1) / 2;
}

void up_heap(uint32_t *a, uint32_t n, Stats *stats){
  uint32_t par = parent(n);
  while(n > 0 && cmp(stats, a[n], a[par]) < 0 ){
    swap(stats, &a[n], &a[par]);
    n = par;
    par = parent(n);
  }
}

void down_heap(uint32_t *a, uint32_t heap_size, Stats *stats){
  uint32_t n = 0;
  uint32_t smaller;
  while (l_child(n) < heap_size) {
    if ( r_child(n) == heap_size) {
      smaller = l_child(n);
    } else if (cmp(stats, a[l_child(n)], a[r_child(n)]) < 0){
      smaller = l_child(n);
    } else {
      smaller = r_child(n);
    }
    if (cmp(stats, a[n], a[smaller]) < 0) {
      break;
    }
    swap(stats, &a[n], &a[smaller]);
    n = smaller;
  }
}

uint32_t *build_heap(uint32_t *a, uint32_t n_elements, Stats *stats){
  uint32_t *heap = (uint32_t*) calloc(n_elements, sizeof(uint32_t));
  for (uint32_t n = 0; n < n_elements; n++) {
    heap[n] = move(stats, a[n]);
    heap[n] = move(stats, a[n]);
    up_heap(heap, n, stats);
  }
  return heap;
}

void heap_sort(Stats *stats, uint32_t *arr, uint32_t n_elements){
  uint32_t *heap = build_heap(arr, n_elements, stats);
  //printf("heapsort built heap:\n");
  // for (size_t i = 0; i < n_elements; i++) {
  //   printf("%u,  child is %u and %u \n", heap[i], l_child(i), r_child(i));
  // }
  for (uint32_t n = 0; n < n_elements; n++) {
    arr[n] = move(stats, heap[0]);
    arr[n] = move(stats, heap[0]);

    heap[0] = move(stats, heap[n_elements - n -1]);
    heap[0] = move(stats, heap[n_elements - n -1]);
    down_heap(heap, n_elements - n, stats);
  }
  free(heap);
  return;
}
