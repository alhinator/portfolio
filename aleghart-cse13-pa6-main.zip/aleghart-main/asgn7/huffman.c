#include "node.h"
#include "code.h"
#include "defines.h"
#include "pq.h"
#include "io.h"
#include "stack.h"
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>


Code c;

uint8_t ell = 'L';
uint8_t eye = 'I';

Node *build_tree(uint64_t hist[static ALPHABET]){
  struct PriorityQueue *pq = pq_create(ALPHABET);
  for (int i = 0; i < ALPHABET; i++) {
    if (hist[i] != 0) {
      //printf("Character %c appears %"PRIu64" times.\n", (uint8_t)i, frequencies[i]);
      enqueue(pq, node_create((unsigned char)i, hist[i])); //insert this into prio queue.
    }
  }
  //printf("printing original pq.\n");

  //pq_print(pq);
  //now we have a prio queue and need to turn it into a tree.
  struct Node *dqL = NULL;
  struct Node *dqR = NULL;
  struct Node *par = NULL;

  while(pq_size(pq) >= 2){
    dequeue(pq, &dqL);
    dequeue(pq, &dqR);
    par = node_join(dqL, dqR);
    enqueue(pq, par); //node_join them, and insert the new parent into the queue.
  }

  //now we have reached our root.
    struct Node *retRoot = NULL;
    dequeue(pq, &retRoot);
    //pq_print(pq);
    pq_delete(&pq);
    return retRoot;
}



void build_codes(Node *root, Code table[static ALPHABET]){
  //effectively, we want build_codes to be a POST-ORDER traversal of our tree.
  //post order: recurse left, recurse right, operate on current.
  if (root) {
    //printf("current node is: %c\n", root->symbol);
    uint8_t faux = '\0';
    code_push_bit(&c, 0);
    build_codes(root->left, table);
    code_pop_bit(&c, &faux);
    code_push_bit(&c, 1);
    build_codes(root->right, table);
    code_pop_bit(&c, &faux);
    if (!root->left && !root->right) { //better to check if no children than to check if symbol == '$'
      //printf("%c has no children:\n", root->symbol);
      //node_print(root);
      table[root->symbol] = c;
      //code_print(&c);
      return;
    }
  }
  return;
}


void dump_tree(int outfile, Node *root){
  if (root) {
    dump_tree(outfile, root->left);
    dump_tree(outfile, root->right);
    if (!root->left && !root->right) { //better to check if no children than to check if symbol == '$'
      write_bytes(outfile, &ell, 1);
      write_bytes(outfile, &root->symbol, 1);
      return;
    } else {
      write_bytes(outfile, &eye, 1);
      return;
    }
  }
}


Node *rebuild_tree(uint16_t nbytes, uint8_t tree[static nbytes]){
  struct Stack *st = stack_create(nbytes);
  struct Node *spR = NULL; //stack pop, right child
  struct Node *spL = NULL; //stack pop, left child
  for (uint16_t i = 0; i < nbytes; i++) { // loop thru array
    if (tree[i] == ell) { //if we encounter a leaf
      //fprintf(stderr, "encountered a leaf in rb tree: %c | ", tree[i]);
      i++; //we go to the next one, the actual symbol of the leaf.
      //fprintf(stderr, "%c\n", tree[i]);
      stack_push(st, node_create(tree[i], 0));
    } else if (tree [i] == eye) {
      stack_pop(st, &spR); //get new right child first
      stack_pop(st, &spL); //and left
      stack_push(st, node_join(spL, spR)); //join and push
      spR = NULL; // just for safety.
      spL = NULL;
    } else {
      fprintf(stderr, "How did we get here?\n");
    }
  }

  //done looping. return the root.
  struct Node* retRoot = NULL;
  stack_pop(st, &retRoot);
  stack_delete(&st);
  return retRoot;

}
