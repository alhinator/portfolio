# PURPOSE
This program uses the file *collatz.c* to generate a series of Collatz sequences with seed 2 to 10,000. It then plots four different graphs with relevant data to those sequences, using GNUPLOT. 

# DEPENDENCIES
plot.sh requires GNUPLOT, which can be installed via `$ apt install gnuplot`

plot.sh requires build-essential, which can be installed via `$ apt install build-essential`

plot.sh requires clang, which can be installed via `$ apt install clang`

# OPTIONAL MODULES
clang-format is required for some arguments of Makefile, but is not used by default. It can be installed via `$apt install clang-format` 

# I/O & USAGE
plot.sh must be in the same directory as the provided files *collatz.c* and *Makefile* as it compiles the c program during runtime.

This bash script takes no user inputs, and creates one output PDF named *collatzGraphs.pdf*. If a PDF by that name already exists, it overwrites it. It also creates the *collatz.o* file, a compiled form of *collatz.c*.

plot.sh can be run by executing `$ ./plot.sh` in the same directory as plot.sh. 

**due to the nature of the command** `make clean`**and other commands used,** ***plot.sh*** **removes all previously created compiled programs and all PDF files in the current directory.**

# Makefile
*Makefile*, which is by default executed by *plot.sh*, can be run by itself to compile *collatz.c*. 

*Makefile* can be run via `$ make` assuming build-essential is installed. It accepts the following arguments:

`all`, `collatz`
---
All, which is also the default none argument, redirects to the `collatz` argument. This compiles *collatz.c* into *collatz.o*, provided that a *collatz.c* file exists in the working directory.

`clean`
---
Removes all compiled executables and PDFs from the directory Makefile is in.

`format`
--- 
Formats all .c and .h files in the working directory in accordance with a .clang-format file. File not provided.
