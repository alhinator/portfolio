`*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA6
* README.md
* Readme file

*********************************************************************************`

### Included Files:

*List.cpp* contains an implementation of a doubly-linked long list and various access, manipulation, and miscellaneous operations. This version is C++, as compared to previous assignments.

*List.h* provides an interface for external files to interact with *List.cpp*

*ListTest.cpp* contains tests for the functions contained within *List.cpp*

*BigInteger.cpp* uses the List implementation to create a "big integer" that consists of a normalized list of longs, where each long represents a base 10^9 number in that big integer.

*BigInteger.h* provides an interface for external files to interact with *BigInteger.cpp*

*BigIntegerTest.cpp* contains tests for the functions contained within *BigInteger.cpp*

*Arithmetic.cpp* uses the BigInteger implementation to read in two strings from a text file, convert them into BigInteger objects, and perform a series of mathematical operations to be outputted into another file.

*Makefile* provides various options for compiling the *.cpp* and *.h* files.
