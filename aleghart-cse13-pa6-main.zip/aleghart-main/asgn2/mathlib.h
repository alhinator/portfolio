#pragma once

double my_arcsin(double x);

double my_arccos(double x);

double my_arctan(double x);

double my_log(double x);

double my_sin(double x);

double my_cos(double x);
