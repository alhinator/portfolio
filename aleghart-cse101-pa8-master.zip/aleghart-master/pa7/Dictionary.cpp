/*********************************************************************************
* Alex Leghart, aleghart
* 2023 Spring CSE101 PA7
* Dictionary.cpp
* Dictionary ADT
*********************************************************************************/

#include "Dictionary.h"

#include <iostream>
#include <string>

#define NILVAL -69420

//REMINDER: KEYS ARE UNIQUE, VALUES ARE NOT.

// --------------  helpers ----------------------------------

// Appends a string representation of the tree rooted at R to string s. The
  // string appended consists of: "key : value \n" for each key-value pair in
  // tree R, arranged in order by keys.
void Dictionary::inOrderString(std::string& s, Node* R) const{
  if (R != nil) {
    inOrderString(s, R->left);
    s += ("" + R->key + " : " + std::to_string(R->val) + " \n");
    inOrderString(s, R->right);
  }
}

void Dictionary::preOrderString(std::string& s, Node* R) const{
  //std::cout << "in pre string with r= " << R->key << '\n';
  if (R != nil) {
    s += ("" + R->key + "\n");
    preOrderString(s, R->left);
    preOrderString(s, R->right);
  }
}

// Recursively inserts a deep copy of the subtree rooted at R into this
// Dictionary. Recursion terminates at N.
void Dictionary::preOrderCopy(Node* R, Node* N){
  if (R != nil && R->key != N->key && R->val != N->val) {
    this->setValue(R->key, R->val);
    preOrderCopy(R->left, N);
    preOrderCopy(R->right, N);
  }
}

//Recursively deletes all nodes in subtree rooted by R
void Dictionary::postOrderDelete(Node* R){
  if (R != nil) {
    postOrderDelete(R->left);
    postOrderDelete(R->right);
    remove(R->key);
  }
}

Dictionary::Node::Node(keyType k, valType v){
  key = k;
  val = v;
}

Dictionary::Node* Dictionary::search(Node* R, keyType k) const {
  //binary searches for the value k in the subtree rooted at R
  //returns the node found or nil.
  Node* temp = R;
  while (temp != nil && temp->key != k) {
    if (temp->key > k) {
      temp = temp->left;
    } else if(temp->key < k){
      temp = temp->right;
    }
  }
  return temp;
}

Dictionary::Node* Dictionary::findMin(Node* R){
  //returns the smallest node in subtree rooted at r.
  //in my code this includes R. a subtree can be one node.
  Node* temp = R;

  while (temp->left != nil) {
    temp = temp->left;
  }
  return temp;
}

Dictionary::Node* Dictionary::findMax(Node* R){
  //returns the smallest node in subtree rooted at r.
  //in my code this includes R. a subtree can be one node.

  Node* temp = R;

  while (temp->right != nil) {
    temp = temp->right;
  }
  return temp;
}

Dictionary::Node* Dictionary::findNext(Node* N){
  // If N does not point to the rightmost Node, returns a pointer to the
   // Node after N in an in-order tree walk.  If N points to the rightmost
   // Node, or is nil, returns nil.

   //1. check if N is the rightmost.
   if (N == nil || N->key == findMax(root)->key) {
     return nil;
   }

   //case 1: N has a right node.
    //return the smallest in that node's subtree.
   if (N->right != nil) {
     return findMin(N->right);
   }

   //case 2: N has no right node.
   //we will return the node who we must travel upwards and to the right to get to;
   //we will keep traversing upwards until the "current" node is the LEFT child of the "next" node
   //then return next node.
   Node* curr = N;
   Node* dad = curr->parent;

   while (curr != dad->left) {
     curr = dad;
     dad = curr->parent;
   }

   return dad;
}

Dictionary::Node* Dictionary::findPrev(Node* N){
  // If N does not point to the leftmose Node, returns a pointer to the
   // Node before N in an in-order tree walk.  If N points to the leftmost
   // Node, or is nil, returns nil.

   //1. check if N is the leftmost.
   if (N == nil || N->key == findMin(root)->key) {
     return nil;
   }

   //case 1: N has a left node.
    //return the largest in that node's subtree.
   if (N->left != nil) {
     return findMax(N->left);
   }

   //case 2: N has no left node.
   //we will return the node who we must travel upwards and to the left to get to;
   //we will keep traversing upwards until the "current" node is the RIGHT child of the "next" node
   //then return next node.
   Node* curr = N;
   Node* dad = curr->parent;

   while (curr != dad->right) {
     curr = dad;
     dad = curr->parent;
   }

   return dad;
}

void Dictionary::transplant(Node* U, Node* V){
  if (U->parent == nil) { //node U is the root of the tree.
    root = V;
  } else if (U == U->parent->left) {
    U->parent->left = V;
  } else {
    U->parent->right = V;
  }
  if (V != nil) {
    V->parent = U->parent;
  }
}

// -------------- constructors / destructors ----------------------


Dictionary::Dictionary(){ //empty state constructor.
  nil = new Node("NIL", NILVAL);
  nil->left = nil;
  nil->right = nil;
  nil->parent = nil;
  root = nil;
  current = nil;
  num_pairs = 0;
}

Dictionary::Dictionary(const Dictionary& D){ // copy constructor
  nil = new Node("NIL", NILVAL);
  nil->left = nil;
  nil->right = nil;
  nil->parent = nil;
  root = nil;
  current = nil;
  num_pairs = 0;
  this->preOrderCopy(D.root, nil);
}

Dictionary::~Dictionary(){
  //std::cerr << "in deconstructor" << '\n';
  clear();

  root = nullptr; // should be pointing to nil;
  delete nil;
}

// -------------- PUBLIC access --------------------------
int Dictionary::size() const{
  return num_pairs;
}

bool Dictionary::contains(keyType k) const{
  return search(root, k) != nil;
}

valType& Dictionary::getValue(keyType k) const{
  Node* N = search(root, k);
  if (N == nil) {
    throw std::invalid_argument("Dictionary: getValue: key not found");
  }
  return N->val;
}

bool Dictionary::hasCurrent() const{
  return current != nil && current != nullptr;
}

keyType Dictionary::currentKey() const{
  if (!hasCurrent()) {
    throw std::logic_error("Dictionary: currentKey: no current key");
  }
  return current->key;
}

valType& Dictionary::currentVal() const{
  if (!hasCurrent()) {
    throw std::logic_error("Dictionary: currentVal: no current value");
  }
  return current->val;
}


//manips

void Dictionary::clear(){
  while (num_pairs > 0) {
    remove(root->key);
  }
}

// If a pair with key==k exists, overwrites the corresponding value with v,
// otherwise inserts the new pair (k, v).
void Dictionary::setValue(keyType k, valType v){
  //std::cout << "in set val" << '\n';
  //case: empty tree
  if (root == nil) {
    root = new Node(k, v);
    root->left = nil;
    root->right = nil;
    root->parent = nil;
    num_pairs++;
    //std::cout << "inserting at root" << '\n';
    return;
  }

  Node* temp = root;

  while (true) {
    //std::cout << "temp = " << temp->key << '\n';
    if (temp->key > k) { //k goes into left subtree
      if (temp->left == nil) { //there is no left subtree
        Node* ins =  new Node(k, v);
        temp->left = ins;
        ins->parent = temp;
        ins->left = nil;
        ins->right = nil;
        num_pairs++;
        return;
      } else { //go next
        temp = temp->left;
        continue;
      }
    }
    else if (temp->key < k) { //k goes into right subtree
      if (temp->right == nil) { //there is no right subtree
        Node* ins =  new Node(k, v);
        temp->right = ins;
        ins->parent = temp;
        ins->left = nil;
        ins->right = nil;
        num_pairs++;

        return;
      } else { // go next
        temp = temp->right;
        continue;
      }
    }
    else if (temp->key == k){ //overwrite
      temp->val = v;
      //do not increase num_pairs
      return;
    }
  }
}

void Dictionary::remove(keyType k){
  // remove()
   // Deletes the pair for which key==k. If that pair is current, then current
   // becomes undefined.
   // Pre: contains(k).
   Node* found = search(root, k);
   if (found == nil) {
     throw std::runtime_error("Dictionary: remove: key does not exist");
   }
   if (found == current) {
     current = nil;
   }

   //case 1: right child only
   if (found->left == nil) {
     transplant(found, found->right);
   }
   //case 2: left only
   else if (found->right == nil) {
     transplant(found, found->left);
   }
   //case 3: both children
   else {
     Node* y = findMin(found->right);
     if (y->parent != found) {
       transplant(y, y->right);
       y->right = found->right;
       y->right->parent = y;
     }
     transplant(found, y);
     y->left = found->left;
     y->left->parent = y;
   }
   num_pairs--;
   found->parent = nullptr;
   found->left = nullptr;
   found->right = nullptr;
   delete found;
}

void Dictionary::begin(){
  Node* grah = findMin(root);
  if (grah != nil) {
    current = grah;
  }
}

void Dictionary::end(){
  Node* grah = findMax(root);
  if (grah != nil) {
    current = grah;
  }
}

// next()
  // If the current iterator is not at the last pair, advances current
  // to the next pair (as defined by the order operator < on keys). If
  // the current iterator is at the last pair, makes current undefined.
  // Pre: hasCurrent()
void Dictionary::next() {
  if (!hasCurrent()) {
    throw std::runtime_error("Dictionary: next: no current key");
  }
  Node* grah = findNext(current);
  current = grah == nil ? nil : grah;
}

// prev()
// If the current iterator is not at the first pair, moves current to
// the previous pair (as defined by the order operator < on keys). If
// the current iterator is at the first pair, makes current undefined.
// Pre: hasCurrent()
void Dictionary::prev() {
  if (!hasCurrent()) {
    throw std::runtime_error("Dictionary: prev: no current key");
  }
  Node* grah = findPrev(current);
  current = grah == nil ? nullptr : grah;
}

//other funcs

std::string Dictionary::to_string() const{
  std::string s;
  inOrderString(s, root);
  return s;
}

std::string Dictionary::pre_string() const{
  std::string s;
  preOrderString(s, root);
  return s;
}

// equals()
// Returns true if and only if this Dictionary contains the same (key, value)
// pairs as Dictionary D.
bool Dictionary::equals(const Dictionary &D) const{
  if (num_pairs != D.num_pairs) {
    return false;
  }
  std::string io1, po1, io2, po2;
  inOrderString(io1, root);
  preOrderString(po1, root);
  inOrderString(io2, D.root);
  preOrderString(po2, D.root);
  if (io1 == io2 && po1 == po2) {
    return true;
  }
  return false;
}

//overloaded ops

std::ostream& operator<<( std::ostream& stream, Dictionary& D ){
  return stream << D.to_string();
}

bool operator==( const Dictionary& A, const Dictionary& B ){
  return A.equals(B);
}

Dictionary& Dictionary::operator=( const Dictionary& D ){
  if (this != &D) { //not self assignment;
    Dictionary temp = D;
    std::swap(nil, temp.nil);
    std::swap(root, temp.root);
    std::swap(current, temp.current);
    std::swap(num_pairs, temp.num_pairs);
  }
  return *this;
}
