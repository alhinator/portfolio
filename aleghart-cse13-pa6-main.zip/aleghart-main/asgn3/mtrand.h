#include <stdint.h>

extern uint64_t mtrand_rand64 (void);
extern void     mtrand_seed (uint64_t seed);

